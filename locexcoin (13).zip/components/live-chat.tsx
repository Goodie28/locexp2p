"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MessageCircle, Send, X, Paperclip, ImageIcon } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"

interface Message {
  id: number
  content: string
  sender: "user" | "admin"
  timestamp: Date
  status: "sent" | "delivered" | "read"
}

export default function LiveChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      content: "Hello! How can I help you today?",
      sender: "admin",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      status: "read",
    },
  ])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    if (isOpen) {
      scrollToBottom()
    }
  }, [messages, isOpen])

  const handleSendMessage = () => {
    if (message.trim() === "") return

    const newMessage: Message = {
      id: Date.now(),
      content: message,
      sender: "user",
      timestamp: new Date(),
      status: "sent",
    }

    setMessages([...messages, newMessage])
    setMessage("")

    // Simulate admin response after 1-3 seconds
    setTimeout(
      () => {
        const adminResponse: Message = {
          id: Date.now() + 1,
          content: "Thank you for your message. An admin will respond to you shortly.",
          sender: "admin",
          timestamp: new Date(),
          status: "delivered",
        }
        setMessages((prev) => [...prev, adminResponse])
      },
      Math.random() * 2000 + 1000,
    )
  }

  const formatMessageTime = (date: Date) => {
    return format(date, "h:mm a")
  }

  return (
    <>
      {/* Chat button */}
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className={`rounded-full w-14 h-14 shadow-lg ${
            isOpen ? "bg-red-500 hover:bg-red-600" : "bg-blue-600 hover:bg-blue-700"
          }`}
        >
          {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
        </Button>
      </div>

      {/* Chat window */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 z-50 w-80 sm:w-96">
          <Card className="shadow-xl border-gray-200">
            <CardHeader className="bg-blue-600 text-white py-3 px-4 rounded-t-lg">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8 border-2 border-white">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Admin" />
                    <AvatarFallback className="bg-blue-700">AD</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-sm font-medium">Live Support</CardTitle>
                    <p className="text-xs text-blue-100">Online</p>
                  </div>
                </div>
                <Badge variant="outline" className="bg-green-500 text-white border-0 text-xs">
                  Online
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-80 overflow-y-auto p-4 space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"} items-end space-x-2`}
                  >
                    {msg.sender === "admin" && (
                      <Avatar className="h-8 w-8 flex-shrink-0">
                        <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Admin" />
                        <AvatarFallback className="bg-blue-600 text-white">AD</AvatarFallback>
                      </Avatar>
                    )}
                    <div
                      className={`max-w-[80%] rounded-lg px-3 py-2 ${
                        msg.sender === "user"
                          ? "bg-blue-600 text-white rounded-br-none"
                          : "bg-gray-100 text-gray-800 rounded-bl-none"
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <p
                        className={`text-xs mt-1 ${
                          msg.sender === "user" ? "text-blue-100" : "text-gray-500"
                        } text-right`}
                      >
                        {formatMessageTime(msg.timestamp)}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </CardContent>
            <CardFooter className="p-2 border-t">
              <div className="flex items-center w-full space-x-2">
                <Button variant="ghost" size="icon" className="text-gray-500 hover:text-blue-600">
                  <Paperclip className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-gray-500 hover:text-blue-600">
                  <ImageIcon className="h-5 w-5" />
                </Button>
                <Input
                  placeholder="Type a message..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleSendMessage()
                    }
                  }}
                  className="flex-1"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={message.trim() === ""}
                  className="bg-blue-600 hover:bg-blue-700"
                  size="icon"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      )}
    </>
  )
}
