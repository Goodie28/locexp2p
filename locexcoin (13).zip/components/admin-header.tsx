"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell, Search, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

export default function AdminHeader() {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: "New message from user",
      message: "John Doe sent a message regarding payment issues.",
      time: "Just now",
      read: false,
    },
    {
      id: 2,
      title: "Coin approval pending",
      message: "5 new coin approvals are waiting for your review.",
      time: "2 hours ago",
      read: false,
    },
    {
      id: 3,
      title: "System update",
      message: "The system has been updated to version 2.1.0",
      time: "Yesterday",
      read: true,
    },
  ])

  const [searchResults, setSearchResults] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showSearchDialog, setShowSearchDialog] = useState(false)

  const unreadCount = notifications.filter((n) => !n.read).length

  const handleSearch = (term: string) => {
    setSearchTerm(term)
    if (term.length < 2) {
      setSearchResults([])
      return
    }

    // Mock search results - in a real app, this would be an API call
    const mockResults = [
      {
        id: 1,
        name: "John Doe",
        email: "john@example.com",
        status: "active",
      },
      {
        id: 2,
        name: "Jane Smith",
        email: "jane@example.com",
        status: "pending",
      },
      {
        id: 3,
        name: "Robert Johnson",
        email: "robert@example.com",
        status: "suspended",
      },
    ].filter(
      (user) =>
        user.name.toLowerCase().includes(term.toLowerCase()) || user.email.toLowerCase().includes(term.toLowerCase()),
    )

    setSearchResults(mockResults)
  }

  return (
    <header className="bg-white border-b border-gray-200 py-4 px-6">
      <div className="flex items-center justify-between">
        <div className="flex-1 max-w-md hidden md:block">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search members..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
            />
            {searchResults.length > 0 && (
              <div className="absolute mt-1 w-full bg-white rounded-md shadow-lg border z-10">
                <ul className="py-1">
                  {searchResults.map((result) => (
                    <li key={result.id} className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{result.name}</p>
                          <p className="text-sm text-gray-500">{result.email}</p>
                        </div>
                        <Badge
                          variant="outline"
                          className={
                            result.status === "active"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : result.status === "pending"
                                ? "bg-amber-50 text-amber-700 border-amber-200"
                                : "bg-red-50 text-red-700 border-red-200"
                          }
                        >
                          {result.status}
                        </Badge>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Mobile search button */}
        <div className="md:hidden">
          <Dialog open={showSearchDialog} onOpenChange={setShowSearchDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="icon">
                <Search className="h-5 w-5" />
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <div className="space-y-4">
                <h2 className="font-semibold text-lg">Search Members</h2>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name or email..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => handleSearch(e.target.value)}
                    autoFocus
                  />
                </div>
                {searchResults.length > 0 ? (
                  <ul className="space-y-2 max-h-[300px] overflow-y-auto">
                    {searchResults.map((result) => (
                      <li key={result.id} className="p-2 hover:bg-gray-100 rounded-md cursor-pointer">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{result.name}</p>
                            <p className="text-sm text-gray-500">{result.email}</p>
                          </div>
                          <Badge
                            variant="outline"
                            className={
                              result.status === "active"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : result.status === "pending"
                                  ? "bg-amber-50 text-amber-700 border-amber-200"
                                  : "bg-red-50 text-red-700 border-red-200"
                            }
                          >
                            {result.status}
                          </Badge>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : searchTerm.length > 1 ? (
                  <p className="text-center py-4 text-gray-500">No members found</p>
                ) : null}
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex items-center space-x-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {notifications.length > 0 ? (
                notifications.map((notification) => (
                  <DropdownMenuItem key={notification.id} className="cursor-pointer p-4">
                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center justify-between">
                        <p className={`font-medium ${notification.read ? "text-gray-700" : "text-blue-600"}`}>
                          {notification.title}
                        </p>
                        <span className="text-xs text-gray-500">{notification.time}</span>
                      </div>
                      <p className="text-sm text-gray-600">{notification.message}</p>
                    </div>
                  </DropdownMenuItem>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">No notifications</div>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link
                  href="/admin/notifications"
                  className="w-full text-center text-sm text-blue-600 hover:text-blue-700"
                >
                  View all notifications
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Admin Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/admin/settings">Settings</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600 cursor-pointer">Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
