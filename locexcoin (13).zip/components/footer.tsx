import Link from "next/link"
import { Facebook, Instagram, Twitter, PhoneIcon as WhatsApp } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-4">
              LOCEX<span className="text-orange">COIN</span>
            </h3>
            <p className="text-gray-400 mb-4">
              P2P auction platform for buying and selling coins with guaranteed profits.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <WhatsApp className="h-5 w-5" />
              </Link>
            </div>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/how-it-works" className="text-gray-400 hover:text-white">
                  How It Works
                </Link>
              </li>
              <li>
                <Link href="/plans" className="text-gray-400 hover:text-white">
                  Plans
                </Link>
              </li>
              <li>
                <Link href="/referrals" className="text-gray-400 hover:text-white">
                  Referrals
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Legal</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/terms" className="text-gray-400 hover:text-white">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-400 hover:text-white">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/refund" className="text-gray-400 hover:text-white">
                  Refund Policy
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-gray-400 hover:text-white">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Admin</h4>
            <ul className="space-y-2">
              <li className="flex items-center">
                <WhatsApp className="h-5 w-5 mr-2 text-green-500" />
                <a href="https://wa.me/2348107043578" className="text-gray-400 hover:text-white">
                  +234 810 704 3578
                </a>
              </li>
              <li className="flex items-center">
                <WhatsApp className="h-5 w-5 mr-2 text-green-500" />
                <a href="https://wa.me/2348120069314" className="text-gray-400 hover:text-white">
                  +234 812 006 9314
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} LOCEXCOIN. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
