/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    domains: ['placeholder.svg'], // Add any domains you're loading images from
    unoptimized: false, // Better for production
  },
  // Ensure output is configured for Vercel
  output: 'standalone',
  // Increase serverless function timeout for auction operations
  experimental: {
    serverComponentsExternalPackages: ['@prisma/client'],
    serverActions: {
      bodySizeLimit: '2mb',
    },
  },
}

export default nextConfig
