import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Simplified rate limiting for Vercel's serverless environment
// In production, consider using Upstash Redis or similar for distributed rate limiting
const RATE_LIMIT_WINDOW = 60 * 1000 // 1 minute in milliseconds
const MAX_REQUESTS_PER_WINDOW = 100 // Maximum requests per window

// In-memory store for rate limiting (will reset on each deployment/cold start)
const rateLimitStore = new Map<string, { count: number; timestamp: number }>()

export function middleware(request: NextRequest) {
  const response = NextResponse.next()

  const path = request.nextUrl.pathname

  // Define public paths that don't require authentication
  const isPublicPath =
    path === "/login" ||
    path === "/register" ||
    path === "/" ||
    path.startsWith("/_next") ||
    path.startsWith("/api/public") ||
    path.startsWith("/favicon.ico") ||
    path.startsWith("/images/")

  // Get the authentication token from the cookies
  const token = request.cookies.get("auth_token")?.value || ""

  // Get the user role from the cookies
  const userRole = request.cookies.get("user_role")?.value || "user"

  // Check if the path is for admin routes
  const isAdminPath = path.startsWith("/admin")

  // Redirect to login if trying to access protected routes without authentication
  if (!isPublicPath && !token) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // Redirect to dashboard if trying to access login/register while already authenticated
  if ((path === "/login" || path === "/register") && token) {
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  // Prevent regular users from accessing admin routes
  if (isAdminPath && userRole !== "admin") {
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  // Get client IP address - Vercel specific headers
  const ip = request.headers.get("x-real-ip") || request.headers.get("x-forwarded-for") || request.ip || "unknown"

  // Implement rate limiting - simplified for serverless
  if (!rateLimitStore.has(ip)) {
    rateLimitStore.set(ip, { count: 1, timestamp: Date.now() })
  } else {
    const current = rateLimitStore.get(ip)!

    // Reset count if window has passed
    if (Date.now() - current.timestamp > RATE_LIMIT_WINDOW) {
      rateLimitStore.set(ip, { count: 1, timestamp: Date.now() })
    } else {
      // Increment count
      current.count++

      // Check if rate limit exceeded
      if (current.count > MAX_REQUESTS_PER_WINDOW) {
        return new NextResponse("Too Many Requests", {
          status: 429,
          headers: {
            "Retry-After": "60",
            "Content-Type": "text/plain",
          },
        })
      }
    }
  }

  // Add security headers
  response.headers.set("X-XSS-Protection", "1; mode=block")
  response.headers.set("X-Content-Type-Options", "nosniff")
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin")
  response.headers.set("X-Frame-Options", "DENY")

  return response
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
}
