"use client"

export async function logoutUser() {
  try {
    const response = await fetch("/api/auth", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (response.ok) {
      // Clear any client-side state if needed
      localStorage.removeItem("user_data")
      sessionStorage.clear()

      // Redirect to home page
      window.location.href = "/"
    } else {
      console.error("Logout failed")
    }
  } catch (error) {
    console.error("Logout error:", error)
  }
}
