"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Search, Send, MoreVertical, Phone, Video, Archive, AlertCircle } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface Message {
  id: string
  content: string
  sender: "user" | "admin"
  timestamp: Date
  read: boolean
}

interface Conversation {
  id: string
  user: {
    id: string
    name: string
    email: string
    avatar?: string
  }
  lastMessage: string
  lastMessageTime: Date
  unread: number
  status: "active" | "resolved" | "pending"
  messages: Message[]
}

export default function MessagesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)
  const [newMessage, setNewMessage] = useState("")

  // Sample conversation data
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: "1",
      user: {
        id: "user1",
        name: "John Doe",
        email: "john.doe@example.com",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      lastMessage: "I need help with my coin purchase",
      lastMessageTime: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      unread: 2,
      status: "active",
      messages: [
        {
          id: "msg1",
          content: "Hello, I need help with my coin purchase",
          sender: "user",
          timestamp: new Date(Date.now() - 1000 * 60 * 10), // 10 minutes ago
          read: true,
        },
        {
          id: "msg2",
          content: "What seems to be the issue?",
          sender: "admin",
          timestamp: new Date(Date.now() - 1000 * 60 * 8), // 8 minutes ago
          read: true,
        },
        {
          id: "msg3",
          content: "I made a payment but the coins haven't been credited to my account yet",
          sender: "user",
          timestamp: new Date(Date.now() - 1000 * 60 * 6), // 6 minutes ago
          read: true,
        },
        {
          id: "msg4",
          content: "Can you please provide your transaction reference?",
          sender: "admin",
          timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
          read: false,
        },
      ],
    },
    {
      id: "2",
      user: {
        id: "user2",
        name: "Jane Smith",
        email: "jane.smith@example.com",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      lastMessage: "When will the next auction start?",
      lastMessageTime: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      unread: 0,
      status: "resolved",
      messages: [
        {
          id: "msg5",
          content: "When will the next auction start?",
          sender: "user",
          timestamp: new Date(Date.now() - 1000 * 60 * 35), // 35 minutes ago
          read: true,
        },
        {
          id: "msg6",
          content: "The next auction is scheduled for tomorrow at 2 PM WAT",
          sender: "admin",
          timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
          read: true,
        },
      ],
    },
    {
      id: "3",
      user: {
        id: "user3",
        name: "Robert Williams",
        email: "robert.williams@example.com",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      lastMessage: "I'm having trouble with my withdrawal",
      lastMessageTime: new Date(Date.now() - 1000 * 60 * 120), // 2 hours ago
      unread: 1,
      status: "pending",
      messages: [
        {
          id: "msg7",
          content: "I'm having trouble with my withdrawal",
          sender: "user",
          timestamp: new Date(Date.now() - 1000 * 60 * 125), // 2 hours 5 minutes ago
          read: true,
        },
        {
          id: "msg8",
          content: "What error message are you seeing?",
          sender: "admin",
          timestamp: new Date(Date.now() - 1000 * 60 * 120), // 2 hours ago
          read: false,
        },
      ],
    },
  ])

  const filteredConversations = conversations.filter((conversation) => {
    // Filter by search query
    const matchesSearch =
      conversation.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conversation.user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conversation.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())

    // Filter by tab
    if (activeTab === "all") return matchesSearch
    if (activeTab === "unread") return matchesSearch && conversation.unread > 0
    if (activeTab === "active") return matchesSearch && conversation.status === "active"
    if (activeTab === "resolved") return matchesSearch && conversation.status === "resolved"
    if (activeTab === "pending") return matchesSearch && conversation.status === "pending"

    return matchesSearch
  })

  const currentConversation = conversations.find((c) => c.id === selectedConversation)

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedConversation) return

    const updatedConversations = conversations.map((conversation) => {
      if (conversation.id === selectedConversation) {
        const newMsg: Message = {
          id: `msg${Date.now()}`,
          content: newMessage,
          sender: "admin",
          timestamp: new Date(),
          read: true,
        }

        return {
          ...conversation,
          lastMessage: newMessage,
          lastMessageTime: new Date(),
          messages: [...conversation.messages, newMsg],
        }
      }
      return conversation
    })

    setConversations(updatedConversations)
    setNewMessage("")
  }

  const markAsRead = (conversationId: string) => {
    setConversations(
      conversations.map((conversation) => {
        if (conversation.id === conversationId) {
          return {
            ...conversation,
            unread: 0,
            messages: conversation.messages.map((message) => ({
              ...message,
              read: true,
            })),
          }
        }
        return conversation
      }),
    )
  }

  const handleConversationSelect = (conversationId: string) => {
    setSelectedConversation(conversationId)
    markAsRead(conversationId)
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (diffInHours < 48) {
      return "Yesterday"
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" })
    }
  }

  const resolveConversation = (conversationId: string) => {
    setConversations(
      conversations.map((conversation) => {
        if (conversation.id === conversationId) {
          return {
            ...conversation,
            status: "resolved",
          }
        }
        return conversation
      }),
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Messages</h1>
        <p className="text-muted-foreground">Manage and respond to member conversations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
        {/* Conversations List */}
        <Card className="md:col-span-1 flex flex-col">
          <CardHeader className="px-4 py-3 space-y-2">
            <div className="flex items-center gap-2">
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-9"
                prefix={<Search className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-5 h-9">
                <TabsTrigger value="all" className="text-xs">
                  All
                </TabsTrigger>
                <TabsTrigger value="unread" className="text-xs">
                  Unread
                </TabsTrigger>
                <TabsTrigger value="active" className="text-xs">
                  Active
                </TabsTrigger>
                <TabsTrigger value="pending" className="text-xs">
                  Pending
                </TabsTrigger>
                <TabsTrigger value="resolved" className="text-xs">
                  Resolved
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto p-0">
            <div className="divide-y">
              {filteredConversations.length > 0 ? (
                filteredConversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className={`flex items-center gap-3 p-3 cursor-pointer hover:bg-muted transition-colors ${
                      selectedConversation === conversation.id ? "bg-muted" : ""
                    }`}
                    onClick={() => handleConversationSelect(conversation.id)}
                  >
                    <div className="relative">
                      <Avatar className="h-10 w-10">
                        <AvatarImage
                          src={conversation.user.avatar || "/placeholder.svg"}
                          alt={conversation.user.name}
                        />
                        <AvatarFallback>
                          {conversation.user.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      {conversation.status === "active" && (
                        <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-background"></span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <p className="font-medium truncate">{conversation.user.name}</p>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {formatTime(conversation.lastMessageTime)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <p className="text-sm text-muted-foreground truncate">{conversation.lastMessage}</p>
                        {conversation.unread > 0 && (
                          <Badge variant="default" className="ml-2 bg-blue-600">
                            {conversation.unread}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-muted-foreground">No conversations found</div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="md:col-span-2 flex flex-col">
          {selectedConversation && currentConversation ? (
            <>
              <CardHeader className="px-4 py-3 border-b flex flex-row items-center justify-between space-y-0">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage
                      src={currentConversation.user.avatar || "/placeholder.svg"}
                      alt={currentConversation.user.name}
                    />
                    <AvatarFallback>
                      {currentConversation.user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-base">{currentConversation.user.name}</CardTitle>
                    <CardDescription className="text-xs">{currentConversation.user.email}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="text-muted-foreground">
                    <Phone className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-muted-foreground">
                    <Video className="h-4 w-4" />
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-muted-foreground">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Options</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => resolveConversation(currentConversation.id)}>
                        <Archive className="h-4 w-4 mr-2" />
                        Mark as Resolved
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <AlertCircle className="h-4 w-4 mr-2" />
                        Report Issue
                      </DropdownMenuItem>
                      <DropdownMenuItem>View Member Profile</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-auto p-4 space-y-4">
                {currentConversation.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === "admin" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.sender === "admin"
                          ? "bg-blue-600 text-white rounded-br-none"
                          : "bg-gray-100 rounded-bl-none"
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                      <p
                        className={`text-xs mt-1 text-right ${
                          message.sender === "admin" ? "text-blue-100" : "text-gray-500"
                        }`}
                      >
                        {formatTime(message.timestamp)}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
              <div className="p-3 border-t">
                <div className="flex items-center gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                    className="flex-1"
                  />
                  <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                    <Send className="h-4 w-4 mr-2" />
                    Send
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-6 text-center">
              <div className="rounded-full bg-blue-100 p-3 mb-4">
                <MessageIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">Select a conversation</h3>
              <p className="text-muted-foreground max-w-md">
                Choose a conversation from the list to view messages and respond to members
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}

function MessageIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  )
}
