"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Search,
  Filter,
  MoreHorizontal,
  Download,
  UserPlus,
  Mail,
  Eye,
  Lock,
  AlertTriangle,
  CheckCircle,
  XCircle,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface User {
  id: string
  name: string
  email: string
  phone: string
  status: "active" | "inactive" | "suspended" | "pending"
  joinDate: Date
  lastActive: Date
  transactions: number
  balance: number
  avatar?: string
}

export default function UsersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")

  // Sample user data
  const [users, setUsers] = useState<User[]>([
    {
      id: "1",
      name: "John Doe",
      email: "john.doe@example.com",
      phone: "+234 801 234 5678",
      status: "active",
      joinDate: new Date(2023, 0, 15),
      lastActive: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      transactions: 12,
      balance: 250000,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "2",
      name: "Jane Smith",
      email: "jane.smith@example.com",
      phone: "+234 802 345 6789",
      status: "active",
      joinDate: new Date(2023, 1, 20),
      lastActive: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      transactions: 8,
      balance: 180000,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "3",
      name: "Robert Williams",
      email: "robert.williams@example.com",
      phone: "+234 803 456 7890",
      status: "inactive",
      joinDate: new Date(2023, 2, 10),
      lastActive: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10), // 10 days ago
      transactions: 5,
      balance: 75000,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "4",
      name: "Mary Johnson",
      email: "mary.johnson@example.com",
      phone: "+234 804 567 8901",
      status: "suspended",
      joinDate: new Date(2023, 3, 5),
      lastActive: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30), // 30 days ago
      transactions: 3,
      balance: 0,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "5",
      name: "David Miller",
      email: "david.miller@example.com",
      phone: "+234 805 678 9012",
      status: "active",
      joinDate: new Date(2023, 4, 18),
      lastActive: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5 hours ago
      transactions: 15,
      balance: 320000,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "6",
      name: "Patricia Moore",
      email: "patricia.moore@example.com",
      phone: "+234 806 789 0123",
      status: "active",
      joinDate: new Date(2023, 5, 22),
      lastActive: new Date(Date.now() - 1000 * 60 * 120), // 2 hours ago
      transactions: 7,
      balance: 150000,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "7",
      name: "James Wilson",
      email: "james.wilson@example.com",
      phone: "+234 807 890 1234",
      status: "pending",
      joinDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
      lastActive: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
      transactions: 0,
      balance: 0,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "8",
      name: "Jennifer Taylor",
      email: "jennifer.taylor@example.com",
      phone: "+234 808 901 2345",
      status: "active",
      joinDate: new Date(2023, 6, 30),
      lastActive: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      transactions: 10,
      balance: 200000,
      avatar: "/placeholder.svg?height=40&width=40",
    },
  ])

  const filteredUsers = users.filter((user) => {
    // Filter by search query
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.phone.toLowerCase().includes(searchQuery.toLowerCase())

    // Filter by tab
    if (activeTab === "all") {
      // Filter by status dropdown if selected
      if (selectedStatus === "all") return matchesSearch
      return matchesSearch && user.status === selectedStatus
    }

    if (activeTab === "active") return matchesSearch && user.status === "active"
    if (activeTab === "inactive") return matchesSearch && user.status === "inactive"
    if (activeTab === "suspended") return matchesSearch && user.status === "suspended"
    if (activeTab === "pending") return matchesSearch && user.status === "pending"

    return matchesSearch
  })

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const formatLastActive = (date: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))

    if (diffInMinutes < 60) return `${diffInMinutes}m ago`

    const diffInHours = Math.floor(diffInMinutes / 60)
    if (diffInHours < 24) return `${diffInHours}h ago`

    const diffInDays = Math.floor(diffInHours / 24)
    if (diffInDays === 1) return "Yesterday"
    if (diffInDays < 7) return `${diffInDays}d ago`

    return formatDate(date)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-600">Active</Badge>
      case "inactive":
        return (
          <Badge variant="outline" className="text-amber-600 border-amber-300 bg-amber-50">
            Inactive
          </Badge>
        )
      case "suspended":
        return <Badge variant="destructive">Suspended</Badge>
      case "pending":
        return (
          <Badge variant="outline" className="text-blue-600 border-blue-300 bg-blue-50">
            Pending
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Users</h1>
          <p className="text-muted-foreground">Manage and monitor user accounts</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button>
            <UserPlus className="h-4 w-4 mr-2" />
            Add User
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex-1 max-w-md">
          <Input
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-9"
            prefix={<Search className="h-4 w-4 text-muted-foreground" />}
          />
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="suspended">Suspended</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Users</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="inactive">Inactive</TabsTrigger>
          <TabsTrigger value="suspended">Suspended</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
        </TabsList>
        <TabsContent value={activeTab} className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>User Management</CardTitle>
              <CardDescription>
                {filteredUsers.length} {activeTab !== "all" ? activeTab : ""} user
                {filteredUsers.length !== 1 ? "s" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Join Date</TableHead>
                    <TableHead>Last Active</TableHead>
                    <TableHead>Transactions</TableHead>
                    <TableHead>Balance</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                              <AvatarFallback>
                                {user.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{user.name}</p>
                              <p className="text-xs text-muted-foreground">{user.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(user.status)}</TableCell>
                        <TableCell>{formatDate(user.joinDate)}</TableCell>
                        <TableCell>{formatLastActive(user.lastActive)}</TableCell>
                        <TableCell>{user.transactions}</TableCell>
                        <TableCell>₦{user.balance.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                View Profile
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Mail className="h-4 w-4 mr-2" />
                                Send Email
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Lock className="h-4 w-4 mr-2" />
                                Reset Password
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {user.status === "active" ? (
                                <DropdownMenuItem className="text-amber-600">
                                  <AlertTriangle className="h-4 w-4 mr-2" />
                                  Suspend Account
                                </DropdownMenuItem>
                              ) : user.status === "suspended" ? (
                                <DropdownMenuItem className="text-green-600">
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Reactivate Account
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem className="text-green-600">
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Activate Account
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem className="text-red-600">
                                <XCircle className="h-4 w-4 mr-2" />
                                Delete Account
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-6">
                        <div className="flex flex-col items-center justify-center">
                          <div className="rounded-full bg-muted p-3 mb-4">
                            <Search className="h-6 w-6 text-muted-foreground" />
                          </div>
                          <h3 className="text-lg font-medium mb-2">No users found</h3>
                          <p className="text-muted-foreground max-w-md">
                            No users match your current search criteria. Try adjusting your filters or search query.
                          </p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
