"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { Search, User, ArrowRight, Shield, AlertTriangle, CheckCircle, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function MemberAccessPage() {
  const { toast } = useToast()
  const [searchEmail, setSearchEmail] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [memberFound, setMemberFound] = useState<any>(null)
  const [recentlyAccessed, setRecentlyAccessed] = useState([
    {
      id: 1,
      name: "John Smith",
      email: "john@example.com",
      lastAccessed: "2 hours ago",
      status: "active",
    },
    {
      id: 2,
      name: "Mary Johnson",
      email: "mary@example.com",
      lastAccessed: "Yesterday",
      status: "active",
    },
    {
      id: 3,
      name: "Robert Williams",
      email: "robert@example.com",
      lastAccessed: "3 days ago",
      status: "suspended",
    },
  ])

  // Mock member data
  const mockMembers = [
    {
      id: 1,
      name: "John Smith",
      email: "john@example.com",
      phone: "+2348012345678",
      joinDate: "Apr 15, 2025",
      status: "active",
      totalInvestments: 3,
      totalValue: 250000,
      referrals: 12,
    },
    {
      id: 2,
      name: "Mary Johnson",
      email: "mary@example.com",
      phone: "+2348023456789",
      joinDate: "Apr 10, 2025",
      status: "active",
      totalInvestments: 2,
      totalValue: 150000,
      referrals: 5,
    },
    {
      id: 3,
      name: "Robert Williams",
      email: "robert@example.com",
      phone: "+2348034567890",
      joinDate: "Apr 5, 2025",
      status: "suspended",
      totalInvestments: 1,
      totalValue: 50000,
      referrals: 0,
    },
  ]

  const handleSearch = () => {
    if (!searchEmail.trim()) {
      toast({
        title: "Error",
        description: "Please enter a valid email address",
        variant: "destructive",
      })
      return
    }

    setIsSearching(true)

    // Simulate API call
    setTimeout(() => {
      const foundMember = mockMembers.find((member) => member.email.toLowerCase() === searchEmail.toLowerCase())

      if (foundMember) {
        setMemberFound(foundMember)

        // Add to recently accessed if not already there
        if (!recentlyAccessed.some((member) => member.email.toLowerCase() === searchEmail.toLowerCase())) {
          setRecentlyAccessed([
            {
              id: foundMember.id,
              name: foundMember.name,
              email: foundMember.email,
              lastAccessed: "Just now",
              status: foundMember.status,
            },
            ...recentlyAccessed.slice(0, 4), // Keep only the 5 most recent
          ])
        }

        toast({
          title: "Member Found",
          description: `Found ${foundMember.name} with email ${foundMember.email}`,
        })
      } else {
        setMemberFound(null)
        toast({
          title: "Member Not Found",
          description: "No member found with the provided email address",
          variant: "destructive",
        })
      }

      setIsSearching(false)
    }, 1500)
  }

  const accessMemberDashboard = (member: any) => {
    toast({
      title: "Accessing Member Dashboard",
      description: `You are now viewing ${member.name}'s dashboard`,
    })

    // In a real application, this would redirect to the member's dashboard
    // or open it in a new tab with admin privileges
    window.open(`/admin/member-view/${member.id}`, "_blank")
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Member Access</h1>
        <p className="text-muted-foreground">Access member dashboards to provide support and assistance</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="h-5 w-5 text-blue-600 mr-2" />
            Find Member by Email
          </CardTitle>
          <CardDescription>Enter a member's email address to access their dashboard</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="Enter member email address..."
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
            </div>
            <Button onClick={handleSearch} disabled={isSearching} className="bg-blue-600 hover:bg-blue-700">
              {isSearching ? "Searching..." : "Search"}
            </Button>
          </div>

          {memberFound && (
            <div className="mt-6 border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <User className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">{memberFound.name}</h3>
                    <p className="text-sm text-muted-foreground">{memberFound.email}</p>
                    <div className="flex items-center mt-1">
                      <Badge
                        variant="outline"
                        className={
                          memberFound.status === "active"
                            ? "bg-green-50 text-green-700 border-green-200"
                            : "bg-red-50 text-red-700 border-red-200"
                        }
                      >
                        {memberFound.status === "active" ? (
                          <CheckCircle className="h-3 w-3 mr-1" />
                        ) : (
                          <AlertTriangle className="h-3 w-3 mr-1" />
                        )}
                        {memberFound.status.charAt(0).toUpperCase() + memberFound.status.slice(1)}
                      </Badge>
                      <span className="text-xs text-muted-foreground ml-2">Joined: {memberFound.joinDate}</span>
                    </div>
                  </div>
                </div>
                <Button onClick={() => accessMemberDashboard(memberFound)} className="bg-blue-600 hover:bg-blue-700">
                  Access Dashboard
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
                <div>
                  <p className="text-sm text-muted-foreground">Total Investments</p>
                  <p className="font-medium">{memberFound.totalInvestments}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Value</p>
                  <p className="font-medium">₦{memberFound.totalValue.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Referrals</p>
                  <p className="font-medium">{memberFound.referrals}</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="h-5 w-5 text-blue-600 mr-2" />
            Recently Accessed Members
          </CardTitle>
          <CardDescription>Members whose dashboards you've recently accessed</CardDescription>
        </CardHeader>
        <CardContent>
          {recentlyAccessed.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-4 gap-4 p-4 font-medium border-b">
                <div>Name</div>
                <div>Email</div>
                <div>Last Accessed</div>
                <div>Actions</div>
              </div>
              <div className="divide-y">
                {recentlyAccessed.map((member) => (
                  <div key={member.id} className="grid grid-cols-4 gap-4 p-4">
                    <div className="flex items-center">
                      <span
                        className={`h-2 w-2 rounded-full mr-2 ${
                          member.status === "active" ? "bg-green-500" : "bg-red-500"
                        }`}
                      ></span>
                      {member.name}
                    </div>
                    <div className="text-muted-foreground">{member.email}</div>
                    <div>{member.lastAccessed}</div>
                    <div>
                      <Button
                        size="sm"
                        onClick={() => {
                          const foundMember = mockMembers.find((m) => m.id === member.id)
                          if (foundMember) {
                            accessMemberDashboard(foundMember)
                          }
                        }}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Access
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <div className="rounded-full bg-gray-100 p-3 mb-4">
                <User className="h-6 w-6 text-gray-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">No Recent Access</h3>
              <p className="text-muted-foreground mb-4">You haven't accessed any member dashboards recently</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="h-5 w-5 text-blue-600 mr-2" />
            Admin Access Guidelines
          </CardTitle>
          <CardDescription>Important information about accessing member dashboards</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 mr-2 flex-shrink-0" />
                <div>
                  <h3 className="font-medium text-amber-800">Important Notice</h3>
                  <p className="text-sm text-amber-700 mt-1">
                    When accessing member dashboards, all actions are logged for security purposes. Only access member
                    accounts for legitimate support reasons.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Access Guidelines</h3>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Only access member dashboards when providing support or resolving issues</li>
                <li>• Do not make changes to member accounts without their knowledge or consent</li>
                <li>• All actions performed while accessing member dashboards are logged</li>
                <li>• Respect member privacy and confidentiality at all times</li>
                <li>• Log out immediately after completing your support tasks</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Support Actions</h3>
              <p className="text-sm text-muted-foreground">
                While accessing member dashboards, you can help with the following:
              </p>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Troubleshooting investment issues</li>
                <li>• Verifying transaction details</li>
                <li>• Updating account information when requested</li>
                <li>• Resolving payment or withdrawal problems</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
