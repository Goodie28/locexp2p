"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Search, Filter, Eye, CheckCircle, AlertTriangle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

export default function TransactionsPage() {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  const [showDialog, setShowDialog] = useState(false)
  const [dialogAction, setDialogAction] = useState<"release" | "cancel" | null>(null)

  interface Transaction {
    id: number
    buyer: string
    seller: string
    amount: number
    plan: string
    status: string
    paymentProof?: string
    timeRemaining?: string
    date: string
  }

  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([
    {
      id: 1,
      buyer: "Sarah Brown",
      seller: "Michael Davis",
      amount: 100000,
      plan: "7-Day Plan",
      status: "Payment Proof Submitted",
      paymentProof: "/placeholder.svg?height=300&width=500",
      timeRemaining: "5 hours",
      date: "Apr 20, 2025",
    },
    {
      id: 2,
      buyer: "James Wilson",
      seller: "Jennifer Taylor",
      amount: 50000,
      plan: "14-Day Plan",
      status: "Seller Not Responding",
      paymentProof: "/placeholder.svg?height=300&width=500",
      timeRemaining: "Expired",
      date: "Apr 19, 2025",
    },
    {
      id: 3,
      buyer: "David Miller",
      seller: "Patricia Moore",
      amount: 75000,
      plan: "7-Day Plan",
      status: "Payment Overdue",
      timeRemaining: "Expired",
      date: "Apr 18, 2025",
    },
  ])

  const [completedTransactions, setCompletedTransactions] = useState<Transaction[]>([
    {
      id: 101,
      buyer: "Robert Johnson",
      seller: "Lisa Anderson",
      amount: 135000,
      plan: "7-Day Plan",
      status: "Completed",
      date: "Apr 15, 2025",
    },
    {
      id: 102,
      buyer: "Thomas Wilson",
      seller: "Emily Clark",
      amount: 200000,
      plan: "21-Day Plan",
      status: "Completed",
      date: "Apr 14, 2025",
    },
  ])

  const [cancelledTransactions, setCancelledTransactions] = useState<Transaction[]>([
    {
      id: 201,
      buyer: "Kevin Brown",
      seller: "Nancy White",
      amount: 50000,
      plan: "7-Day Plan",
      status: "Cancelled",
      date: "Apr 13, 2025",
    },
    {
      id: 202,
      buyer: "Daniel Lee",
      seller: "Susan Martin",
      amount: 75000,
      plan: "14-Day Plan",
      status: "Cancelled",
      date: "Apr 12, 2025",
    },
  ])

  const filteredPending = pendingTransactions.filter(
    (item) =>
      item.buyer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.seller.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredCompleted = completedTransactions.filter(
    (item) =>
      item.buyer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.seller.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredCancelled = cancelledTransactions.filter(
    (item) =>
      item.buyer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.seller.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleViewTransaction = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setShowDialog(true)
    setDialogAction(null)
  }

  const handleReleaseToUser = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setShowDialog(true)
    setDialogAction("release")
  }

  const handleCancelTransaction = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setShowDialog(true)
    setDialogAction("cancel")
  }

  const confirmAction = () => {
    if (!selectedTransaction) return

    if (dialogAction === "release") {
      // Move from pending to completed
      setPendingTransactions(pendingTransactions.filter((t) => t.id !== selectedTransaction.id))
      setCompletedTransactions([
        {
          ...selectedTransaction,
          status: "Completed (Admin Released)",
          date: "Apr 21, 2025", // Today's date for demo
        },
        ...completedTransactions,
      ])

      toast({
        title: "Coins Released",
        description: `Coins have been released to ${selectedTransaction.buyer}`,
      })
    } else if (dialogAction === "cancel") {
      // Move from pending to cancelled
      setPendingTransactions(pendingTransactions.filter((t) => t.id !== selectedTransaction.id))
      setCancelledTransactions([
        {
          ...selectedTransaction,
          status: "Cancelled (Admin Action)",
          date: "Apr 21, 2025", // Today's date for demo
        },
        ...cancelledTransactions,
      ])

      toast({
        title: "Transaction Cancelled",
        description: `Transaction has been cancelled and coins returned to auction pool`,
      })
    }

    setShowDialog(false)
    setSelectedTransaction(null)
    setDialogAction(null)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Manage Transactions</h1>
        <p className="text-muted-foreground">Review and manage transactions between buyers and sellers</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by buyer or seller name..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          Filter
        </Button>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending">Pending ({filteredPending.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({filteredCompleted.length})</TabsTrigger>
          <TabsTrigger value="cancelled">Cancelled ({filteredCancelled.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          {filteredPending.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-7 gap-4 p-4 font-medium border-b">
                <div>Buyer</div>
                <div>Seller</div>
                <div>Amount</div>
                <div>Plan</div>
                <div>Status</div>
                <div>Time Remaining</div>
                <div>Actions</div>
              </div>
              <div className="divide-y">
                {filteredPending.map((item) => (
                  <div key={item.id} className="grid grid-cols-7 gap-4 p-4">
                    <div>{item.buyer}</div>
                    <div>{item.seller}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>
                      <Badge
                        variant="outline"
                        className={
                          item.status === "Payment Proof Submitted"
                            ? "bg-amber-50 text-amber-700 border-amber-200"
                            : item.status === "Seller Not Responding"
                              ? "bg-red-50 text-red-700 border-red-200"
                              : "bg-red-50 text-red-700 border-red-200"
                        }
                      >
                        {item.status}
                      </Badge>
                    </div>
                    <div className={item.timeRemaining === "Expired" ? "text-red-600 font-medium" : ""}>
                      {item.timeRemaining}
                    </div>
                    <div className="flex space-x-2">
                      {(item.status === "Seller Not Responding" || item.timeRemaining === "Expired") && (
                        <Button
                          size="sm"
                          className="bg-blue-600 hover:bg-blue-700"
                          onClick={() => handleReleaseToUser(item)}
                        >
                          Release
                        </Button>
                      )}
                      {item.status === "Payment Overdue" && (
                        <Button size="sm" variant="destructive" onClick={() => handleCancelTransaction(item)}>
                          Cancel
                        </Button>
                      )}
                      <Button size="sm" variant="outline" onClick={() => handleViewTransaction(item)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-green-100 p-3 mb-4">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No pending transactions</h3>
                  <p className="text-muted-foreground mb-4">All transactions are proceeding smoothly</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          {filteredCompleted.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-6 gap-4 p-4 font-medium border-b">
                <div>Buyer</div>
                <div>Seller</div>
                <div>Amount</div>
                <div>Plan</div>
                <div>Status</div>
                <div>Date</div>
              </div>
              <div className="divide-y">
                {filteredCompleted.map((item) => (
                  <div key={item.id} className="grid grid-cols-6 gap-4 p-4">
                    <div>{item.buyer}</div>
                    <div>{item.seller}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {item.status}
                      </Badge>
                    </div>
                    <div>{item.date}</div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-gray-100 p-3 mb-4">
                    <AlertTriangle className="h-6 w-6 text-gray-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No completed transactions found</h3>
                  <p className="text-muted-foreground mb-4">No transactions match your search criteria</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="cancelled" className="space-y-4">
          {filteredCancelled.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-6 gap-4 p-4 font-medium border-b">
                <div>Buyer</div>
                <div>Seller</div>
                <div>Amount</div>
                <div>Plan</div>
                <div>Status</div>
                <div>Date</div>
              </div>
              <div className="divide-y">
                {filteredCancelled.map((item) => (
                  <div key={item.id} className="grid grid-cols-6 gap-4 p-4">
                    <div>{item.buyer}</div>
                    <div>{item.seller}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>
                      <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                        {item.status}
                      </Badge>
                    </div>
                    <div>{item.date}</div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-gray-100 p-3 mb-4">
                    <AlertTriangle className="h-6 w-6 text-gray-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No cancelled transactions found</h3>
                  <p className="text-muted-foreground mb-4">No transactions match your search criteria</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Transaction Detail Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {dialogAction === "release"
                ? "Release Coins to Buyer"
                : dialogAction === "cancel"
                  ? "Cancel Transaction"
                  : "Transaction Details"}
            </DialogTitle>
            <DialogDescription>
              {dialogAction === "release"
                ? "You are about to release coins to the buyer. This action cannot be undone."
                : dialogAction === "cancel"
                  ? "You are about to cancel this transaction and return coins to the auction pool."
                  : "Review transaction details below."}
            </DialogDescription>
          </DialogHeader>

          {selectedTransaction && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <p className="font-medium">Buyer:</p>
                <p>{selectedTransaction.buyer}</p>

                <p className="font-medium">Seller:</p>
                <p>{selectedTransaction.seller}</p>

                <p className="font-medium">Amount:</p>
                <p>₦{selectedTransaction.amount.toLocaleString()}</p>

                <p className="font-medium">Plan:</p>
                <p>{selectedTransaction.plan}</p>

                <p className="font-medium">Status:</p>
                <p>{selectedTransaction.status}</p>

                <p className="font-medium">Date:</p>
                <p>{selectedTransaction.date}</p>

                {selectedTransaction.timeRemaining && (
                  <>
                    <p className="font-medium">Time Remaining:</p>
                    <p className={selectedTransaction.timeRemaining === "Expired" ? "text-red-600" : ""}>
                      {selectedTransaction.timeRemaining}
                    </p>
                  </>
                )}
              </div>

              {selectedTransaction.paymentProof && (
                <div className="space-y-2">
                  <p className="font-medium text-sm">Payment Proof:</p>
                  <div className="border rounded-md overflow-hidden">
                    <img
                      src={selectedTransaction.paymentProof || "/placeholder.svg"}
                      alt="Payment Proof"
                      className="w-full h-auto"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="flex flex-row gap-2 sm:justify-end">
            {dialogAction ? (
              <>
                <Button variant="outline" onClick={() => setShowDialog(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={confirmAction}
                  className={
                    dialogAction === "release" ? "bg-blue-600 hover:bg-blue-700" : "bg-red-600 hover:bg-red-700"
                  }
                >
                  {dialogAction === "release" ? "Release Coins" : "Cancel Transaction"}
                </Button>
              </>
            ) : (
              <Button onClick={() => setShowDialog(false)}>Close</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
