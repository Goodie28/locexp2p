"use client"

import { useState } from "react"
import {
  User,
  Bell,
  Shield,
  Palette,
  Globe,
  Key,
  Save,
  Upload,
  Lock,
  Eye,
  EyeOff,
  RefreshCw,
  CheckCircle,
} from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { toast } from "@/components/ui/use-toast"

export default function AdminSettingsPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSave = (section: string) => {
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      toast({
        title: "Settings saved",
        description: `Your ${section} settings have been updated successfully.`,
      })
    }, 1000)
  }

  return (
    <div className="container mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Admin Settings</h1>
        <p className="text-muted-foreground">Manage your admin profile and platform settings</p>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-6">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden md:inline">Profile</span>
          </TabsTrigger>
          <TabsTrigger value="site" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            <span className="hidden md:inline">Site</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden md:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden md:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="appearance" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="hidden md:inline">Appearance</span>
          </TabsTrigger>
          <TabsTrigger value="api" className="flex items-center gap-2">
            <Key className="h-4 w-4" />
            <span className="hidden md:inline">API</span>
          </TabsTrigger>
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Admin Profile</CardTitle>
              <CardDescription>Update your admin profile information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex flex-col items-center gap-4">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Admin" />
                    <AvatarFallback>AD</AvatarFallback>
                  </Avatar>
                  <Button variant="outline" size="sm" className="flex gap-2">
                    <Upload className="h-4 w-4" />
                    Change Photo
                  </Button>
                </div>
                <div className="flex-1 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" defaultValue="Admin" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" defaultValue="User" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" defaultValue="admin@locexcoin.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" type="tel" defaultValue="+234 800 123 4567" />
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-2">
                <Label htmlFor="bio">Admin Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Write a short bio about yourself"
                  defaultValue="Platform administrator responsible for managing LocexCoin operations and user support."
                  className="min-h-[100px]"
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSave("profile")} disabled={loading} className="flex gap-2">
                {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Site Settings */}
        <TabsContent value="site" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Site Configuration</CardTitle>
              <CardDescription>Manage platform-wide settings and configurations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="siteName">Platform Name</Label>
                <Input id="siteName" defaultValue="LocexCoin" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="siteDescription">Platform Description</Label>
                <Textarea
                  id="siteDescription"
                  defaultValue="Nigerian coin auction platform for secure investments and trading."
                  className="min-h-[80px]"
                />
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Contact Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="supportEmail">Support Email</Label>
                    <Input id="supportEmail" type="email" defaultValue="support@locexcoin.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supportPhone">Support Phone</Label>
                    <Input id="supportPhone" type="tel" defaultValue="+234 800 456 7890" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Office Address</Label>
                  <Textarea id="address" defaultValue="123 Business Avenue, Lagos, Nigeria" className="min-h-[60px]" />
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Platform Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="maintenance">Maintenance Mode</Label>
                      <p className="text-sm text-muted-foreground">Put the site in maintenance mode</p>
                    </div>
                    <Switch id="maintenance" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="registration">User Registration</Label>
                      <p className="text-sm text-muted-foreground">Allow new user registrations</p>
                    </div>
                    <Switch id="registration" defaultChecked />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="minWithdrawal">Minimum Withdrawal (NGN)</Label>
                    <Input id="minWithdrawal" type="number" defaultValue="10000" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="referralBonus">Referral Bonus (%)</Label>
                    <Input id="referralBonus" type="number" defaultValue="5" />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSave("site")} disabled={loading} className="flex gap-2">
                {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure how and when you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Email Notifications</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="emailNewUser">New User Registration</Label>
                      <p className="text-sm text-muted-foreground">Receive email when a new user registers</p>
                    </div>
                    <Switch id="emailNewUser" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="emailNewTransaction">New Transactions</Label>
                      <p className="text-sm text-muted-foreground">Receive email for new transactions</p>
                    </div>
                    <Switch id="emailNewTransaction" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="emailCoinApproval">Coin Approval Requests</Label>
                      <p className="text-sm text-muted-foreground">Receive email for coin approval requests</p>
                    </div>
                    <Switch id="emailCoinApproval" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="emailWithdrawal">Withdrawal Requests</Label>
                      <p className="text-sm text-muted-foreground">Receive email for withdrawal requests</p>
                    </div>
                    <Switch id="emailWithdrawal" defaultChecked />
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">System Notifications</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="sysNewMessage">New Messages</Label>
                      <p className="text-sm text-muted-foreground">Show notifications for new messages</p>
                    </div>
                    <Switch id="sysNewMessage" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="sysLoginAttempt">Login Attempts</Label>
                      <p className="text-sm text-muted-foreground">Show notifications for login attempts</p>
                    </div>
                    <Switch id="sysLoginAttempt" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="sysCriticalAlert">Critical System Alerts</Label>
                      <p className="text-sm text-muted-foreground">Show notifications for critical system alerts</p>
                    </div>
                    <Switch id="sysCriticalAlert" defaultChecked />
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-2">
                <Label htmlFor="notificationDigest">Notification Digest</Label>
                <Select defaultValue="realtime">
                  <SelectTrigger id="notificationDigest">
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="realtime">Real-time</SelectItem>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSave("notifications")} disabled={loading} className="flex gap-2">
                {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Manage your account security and authentication options</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Change Password</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <div className="relative">
                      <Input
                        id="currentPassword"
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter your current password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input
                      id="newPassword"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your new password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <Input
                      id="confirmPassword"
                      type={showPassword ? "text" : "password"}
                      placeholder="Confirm your new password"
                    />
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Two-Factor Authentication</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="twoFactor">Enable Two-Factor Authentication</Label>
                    <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                  </div>
                  <Switch id="twoFactor" />
                </div>
                <Button variant="outline" className="flex gap-2">
                  <Lock className="h-4 w-4" />
                  Setup Two-Factor Authentication
                </Button>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Login Sessions</h3>
                <div className="rounded-md border">
                  <div className="p-4 flex items-start justify-between">
                    <div>
                      <p className="font-medium">Current Session</p>
                      <p className="text-sm text-muted-foreground">Lagos, Nigeria • Chrome on Windows</p>
                      <p className="text-xs text-muted-foreground mt-1">Started 2 hours ago</p>
                    </div>
                    <div className="flex items-center gap-1 rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700">
                      <CheckCircle className="h-3 w-3" />
                      Active
                    </div>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  View All Sessions
                </Button>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Security Log</h3>
                <Button variant="outline" className="w-full">
                  View Security Log
                </Button>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSave("security")} disabled={loading} className="flex gap-2">
                {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Appearance Settings */}
        <TabsContent value="appearance" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>Customize the look and feel of the admin dashboard</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Theme</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <div className="border-2 border-primary rounded-md p-1 cursor-pointer">
                      <div className="h-20 bg-white rounded"></div>
                    </div>
                    <p className="text-sm text-center">Light</p>
                  </div>
                  <div className="space-y-2">
                    <div className="border-2 border-muted rounded-md p-1 cursor-pointer">
                      <div className="h-20 bg-slate-900 rounded"></div>
                    </div>
                    <p className="text-sm text-center">Dark</p>
                  </div>
                  <div className="space-y-2">
                    <div className="border-2 border-muted rounded-md p-1 cursor-pointer">
                      <div className="h-20 bg-gradient-to-b from-white to-slate-900 rounded"></div>
                    </div>
                    <p className="text-sm text-center">System</p>
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Primary Color</h3>
                <div className="grid grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <div className="h-10 bg-blue-600 rounded-md cursor-pointer border-2 border-primary"></div>
                    <p className="text-sm text-center">Blue</p>
                  </div>
                  <div className="space-y-2">
                    <div className="h-10 bg-green-600 rounded-md cursor-pointer"></div>
                    <p className="text-sm text-center">Green</p>
                  </div>
                  <div className="space-y-2">
                    <div className="h-10 bg-purple-600 rounded-md cursor-pointer"></div>
                    <p className="text-sm text-center">Purple</p>
                  </div>
                  <div className="space-y-2">
                    <div className="h-10 bg-orange-600 rounded-md cursor-pointer"></div>
                    <p className="text-sm text-center">Orange</p>
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Layout</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="compactSidebar">Compact Sidebar</Label>
                      <p className="text-sm text-muted-foreground">Use a more compact sidebar layout</p>
                    </div>
                    <Switch id="compactSidebar" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="stickyHeader">Sticky Header</Label>
                      <p className="text-sm text-muted-foreground">Keep the header visible when scrolling</p>
                    </div>
                    <Switch id="stickyHeader" defaultChecked />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contentWidth">Content Width</Label>
                    <Select defaultValue="contained">
                      <SelectTrigger id="contentWidth">
                        <SelectValue placeholder="Select width" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contained">Contained</SelectItem>
                        <SelectItem value="full">Full Width</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Dashboard Widgets</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="showStats">Statistics Cards</Label>
                      <p className="text-sm text-muted-foreground">Show statistics cards on dashboard</p>
                    </div>
                    <Switch id="showStats" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="showCharts">Charts</Label>
                      <p className="text-sm text-muted-foreground">Show charts on dashboard</p>
                    </div>
                    <Switch id="showCharts" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="showActivity">Recent Activity</Label>
                      <p className="text-sm text-muted-foreground">Show recent activity on dashboard</p>
                    </div>
                    <Switch id="showActivity" defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSave("appearance")} disabled={loading} className="flex gap-2">
                {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* API Settings */}
        <TabsContent value="api" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>API Settings</CardTitle>
              <CardDescription>Manage API keys and external integrations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">API Keys</h3>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <p className="font-medium">Production API Key</p>
                        <p className="text-sm text-muted-foreground">For live environment</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input
                          value="••••••••••••••••••••••••••••••"
                          readOnly
                          className="font-mono text-sm w-full md:w-64"
                        />
                        <Button variant="outline" size="sm">
                          Copy
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <p className="font-medium">Test API Key</p>
                        <p className="text-sm text-muted-foreground">For testing environment</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input
                          value="••••••••••••••••••••••••••••••"
                          readOnly
                          className="font-mono text-sm w-full md:w-64"
                        />
                        <Button variant="outline" size="sm">
                          Copy
                        </Button>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" className="flex gap-2">
                    <RefreshCw className="h-4 w-4" />
                    Regenerate API Keys
                  </Button>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Webhook Settings</h3>
                <div className="space-y-2">
                  <Label htmlFor="webhookUrl">Webhook URL</Label>
                  <Input id="webhookUrl" placeholder="https://your-server.com/webhook" />
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="webhookTransactions">Transaction Events</Label>
                      <p className="text-sm text-muted-foreground">Send webhook for transaction events</p>
                    </div>
                    <Switch id="webhookTransactions" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="webhookUsers">User Events</Label>
                      <p className="text-sm text-muted-foreground">Send webhook for user events</p>
                    </div>
                    <Switch id="webhookUsers" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="webhookCoins">Coin Events</Label>
                      <p className="text-sm text-muted-foreground">Send webhook for coin events</p>
                    </div>
                    <Switch id="webhookCoins" defaultChecked />
                  </div>
                </div>
              </div>
              <Separator />
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Payment Integrations</h3>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 flex items-center justify-center rounded-md bg-muted">
                          <svg
                            viewBox="0 0 24 24"
                            className="h-6 w-6"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <rect x="1" y="4" width="22" height="16" rx="2" />
                            <line x1="1" y1="10" x2="23" y2="10" />
                          </svg>
                        </div>
                        <div>
                          <p className="font-medium">Payment Gateway</p>
                          <p className="text-sm text-muted-foreground">Integrated</p>
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 flex items-center justify-center rounded-md bg-muted">
                          <svg
                            viewBox="0 0 24 24"
                            className="h-6 w-6"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                            <line x1="12" y1="17" x2="12.01" y2="17" />
                          </svg>
                        </div>
                        <div>
                          <p className="font-medium">Bank Verification API</p>
                          <p className="text-sm text-muted-foreground">Not configured</p>
                        </div>
                      </div>
                      <Switch />
                    </div>
                  </div>
                  <Button variant="outline" className="w-full">
                    Configure Payment Integrations
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSave("api")} disabled={loading} className="flex gap-2">
                {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
