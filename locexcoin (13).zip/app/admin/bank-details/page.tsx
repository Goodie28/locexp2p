"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"
import { BanknoteIcon as Bank, Plus, Pencil, Trash2, CheckCircle, Copy } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function BankDetailsPage() {
  const { toast } = useToast()
  const [isEditing, setIsEditing] = useState(false)
  const [currentBankId, setCurrentBankId] = useState<number | null>(null)

  const [formData, setFormData] = useState({
    bankName: "",
    accountNumber: "",
    accountName: "",
    additionalInfo: "",
  })

  const [bankAccounts, setBankAccounts] = useState([
    {
      id: 1,
      bankName: "First Bank",
      accountNumber: "3089745612",
      accountName: "LOCEXCOIN LTD",
      additionalInfo: "Please use your registered email as reference when making payment.",
      isActive: true,
    },
    {
      id: 2,
      bankName: "GTBank",
      accountNumber: "0234567890",
      accountName: "LOCEXCOIN LTD",
      additionalInfo: "For faster processing, include your username in the transfer description.",
      isActive: false,
    },
  ])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (isEditing && currentBankId) {
      // Update existing bank account
      setBankAccounts(
        bankAccounts.map((account) => (account.id === currentBankId ? { ...account, ...formData } : account)),
      )

      toast({
        title: "Bank Details Updated",
        description: "The bank account details have been updated successfully.",
      })
    } else {
      // Add new bank account
      setBankAccounts([
        ...bankAccounts,
        {
          id: Date.now(),
          ...formData,
          isActive: bankAccounts.length === 0, // Make active if it's the first account
        },
      ])

      toast({
        title: "Bank Account Added",
        description: "New bank account has been added successfully.",
      })
    }

    // Reset form
    setFormData({
      bankName: "",
      accountNumber: "",
      accountName: "",
      additionalInfo: "",
    })
    setIsEditing(false)
    setCurrentBankId(null)
  }

  const handleEdit = (account: (typeof bankAccounts)[0]) => {
    setFormData({
      bankName: account.bankName,
      accountNumber: account.accountNumber,
      accountName: account.accountName,
      additionalInfo: account.additionalInfo,
    })
    setIsEditing(true)
    setCurrentBankId(account.id)
  }

  const handleDelete = (id: number) => {
    setBankAccounts(bankAccounts.filter((account) => account.id !== id))

    toast({
      title: "Bank Account Removed",
      description: "The bank account has been removed successfully.",
    })
  }

  const toggleActive = (id: number) => {
    setBankAccounts(
      bankAccounts.map((account) =>
        account.id === id ? { ...account, isActive: true } : { ...account, isActive: false },
      ),
    )

    toast({
      title: "Default Bank Updated",
      description: "The default bank account for payments has been updated.",
    })
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "The information has been copied to your clipboard.",
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Bank Details Management</h1>
        <p className="text-muted-foreground">Manage bank accounts where members can make payments for coins</p>
      </div>

      <Tabs defaultValue="manage" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="manage">Manage Bank Accounts</TabsTrigger>
          <TabsTrigger value="preview">Member Preview</TabsTrigger>
        </TabsList>

        <TabsContent value="manage" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Bank Details Form */}
            <Card>
              <CardHeader>
                <CardTitle>{isEditing ? "Edit Bank Account" : "Add Bank Account"}</CardTitle>
                <CardDescription>
                  {isEditing
                    ? "Update the bank account details below"
                    : "Add a new bank account where members can make payments"}
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name</Label>
                    <Input
                      id="bankName"
                      name="bankName"
                      placeholder="Enter bank name"
                      value={formData.bankName}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number</Label>
                    <Input
                      id="accountNumber"
                      name="accountNumber"
                      placeholder="Enter account number"
                      value={formData.accountNumber}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="accountName">Account Name</Label>
                    <Input
                      id="accountName"
                      name="accountName"
                      placeholder="Enter account name"
                      value={formData.accountName}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="additionalInfo">Additional Information (Optional)</Label>
                    <Textarea
                      id="additionalInfo"
                      name="additionalInfo"
                      placeholder="Enter any additional payment instructions"
                      value={formData.additionalInfo}
                      onChange={handleChange}
                      rows={3}
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  {isEditing && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsEditing(false)
                        setCurrentBankId(null)
                        setFormData({
                          bankName: "",
                          accountNumber: "",
                          accountName: "",
                          additionalInfo: "",
                        })
                      }}
                    >
                      Cancel
                    </Button>
                  )}
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700 ml-auto">
                    {isEditing ? "Update Bank Account" : "Add Bank Account"}
                  </Button>
                </CardFooter>
              </form>
            </Card>

            {/* Bank Accounts List */}
            <Card>
              <CardHeader>
                <CardTitle>Bank Accounts</CardTitle>
                <CardDescription>Manage existing bank accounts for payments</CardDescription>
              </CardHeader>
              <CardContent>
                {bankAccounts.length > 0 ? (
                  <div className="space-y-4">
                    {bankAccounts.map((account) => (
                      <div key={account.id} className="border rounded-lg p-4 relative">
                        <div className="absolute top-4 right-4 flex space-x-2">
                          <Button size="icon" variant="ghost" onClick={() => handleEdit(account)} className="h-8 w-8">
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => handleDelete(account.id)}
                            className="h-8 w-8 text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>

                        <div className="flex items-center mb-2">
                          <Bank className="h-5 w-5 text-blue-600 mr-2" />
                          <h3 className="font-medium">{account.bankName}</h3>
                          {account.isActive && (
                            <Badge className="ml-2 bg-green-100 text-green-800 border-green-200">Default</Badge>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                          <div className="text-muted-foreground">Account Number:</div>
                          <div className="font-medium flex items-center">
                            {account.accountNumber}
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => copyToClipboard(account.accountNumber)}
                              className="h-6 w-6 ml-1"
                            >
                              <Copy className="h-3 w-3" />
                              <span className="sr-only">Copy</span>
                            </Button>
                          </div>

                          <div className="text-muted-foreground">Account Name:</div>
                          <div className="font-medium flex items-center">
                            {account.accountName}
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => copyToClipboard(account.accountName)}
                              className="h-6 w-6 ml-1"
                            >
                              <Copy className="h-3 w-3" />
                              <span className="sr-only">Copy</span>
                            </Button>
                          </div>
                        </div>

                        {account.additionalInfo && (
                          <div className="text-sm mt-2 text-muted-foreground">
                            <p>{account.additionalInfo}</p>
                          </div>
                        )}

                        {!account.isActive && (
                          <Button size="sm" variant="outline" onClick={() => toggleActive(account.id)} className="mt-3">
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Set as Default
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-6 text-center">
                    <div className="rounded-full bg-blue-100 p-3 mb-4">
                      <Bank className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No bank accounts added</h3>
                    <p className="text-muted-foreground mb-4">Add a bank account where members can make payments</p>
                    <Button variant="outline" onClick={() => document.getElementById("bankName")?.focus()}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Bank Account
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <CardTitle>Member View</CardTitle>
              <CardDescription>This is how members will see your bank details</CardDescription>
            </CardHeader>
            <CardContent>
              {bankAccounts.filter((account) => account.isActive).length > 0 ? (
                <div className="space-y-4">
                  {bankAccounts
                    .filter((account) => account.isActive)
                    .map((account) => (
                      <div key={account.id} className="border rounded-lg p-4">
                        <div className="flex items-center mb-3">
                          <Bank className="h-5 w-5 text-blue-600 mr-2" />
                          <h3 className="font-medium text-lg">{account.bankName}</h3>
                        </div>

                        <div className="space-y-3">
                          <div className="grid grid-cols-2 gap-2">
                            <div className="text-muted-foreground">Account Number:</div>
                            <div className="font-medium">{account.accountNumber}</div>

                            <div className="text-muted-foreground">Account Name:</div>
                            <div className="font-medium">{account.accountName}</div>
                          </div>

                          {account.additionalInfo && (
                            <div className="bg-blue-50 p-3 rounded-md border border-blue-100 mt-3">
                              <p className="text-sm text-blue-700">{account.additionalInfo}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}

                  <div className="bg-amber-50 p-4 rounded-md border border-amber-100">
                    <h4 className="font-medium text-amber-800 mb-2 flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Payment Instructions
                    </h4>
                    <ol className="list-decimal list-inside text-sm text-amber-700 space-y-1">
                      <li>Make payment to the bank account details above</li>
                      <li>Use your registered email as payment reference</li>
                      <li>Upload proof of payment when submitting your coin purchase</li>
                      <li>Your coins will be approved once payment is confirmed</li>
                    </ol>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-amber-100 p-3 mb-4">
                    <Bank className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No default bank account set</h3>
                  <p className="text-muted-foreground mb-4">
                    Add a bank account and set it as default to see the member preview
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
