"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  Coins,
  Users,
  BarChart3,
  Settings,
  LogOut,
  CheckCircle,
  AlertTriangle,
  BanknoteIcon as Bank,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Sidebar({ className }: SidebarProps) {
  const pathname = usePathname()

  const routes = [
    {
      label: "Dashboard",
      icon: LayoutDashboard,
      href: "/admin",
      active: pathname === "/admin",
    },
    {
      label: "Create Coins",
      icon: Coins,
      href: "/admin/create-coins",
      active: pathname === "/admin/create-coins",
    },
    {
      label: "Bank Details",
      icon: Bank,
      href: "/admin/bank-details",
      active: pathname === "/admin/bank-details",
    },
    {
      label: "Approve Coins",
      icon: CheckCircle,
      href: "/admin/approve-coins",
      active: pathname === "/admin/approve-coins",
    },
    {
      label: "Transactions",
      icon: AlertTriangle,
      href: "/admin/transactions",
      active: pathname === "/admin/transactions",
    },
    {
      label: "Users",
      icon: Users,
      href: "/admin/users",
      active: pathname === "/admin/users",
    },
    {
      label: "Reports",
      icon: BarChart3,
      href: "/admin/reports",
      active: pathname === "/admin/reports",
    },
    {
      label: "Settings",
      icon: Settings,
      href: "/admin/settings",
      active: pathname === "/admin/settings",
    },
  ]

  return (
    <div className={cn("flex h-full w-full flex-col bg-white border-r", className)}>
      <div className="px-3 py-4">
        <Link href="/admin" className="flex items-center pl-3 mb-6">
          <div className="relative h-8 w-8 mr-2">
            <Coins className="h-8 w-8 text-blue-600" />
          </div>
          <h1 className="text-xl font-bold">LOCEXCOIN</h1>
        </Link>
        <div className="space-y-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-blue-100 hover:text-blue-600",
                route.active ? "bg-blue-100 text-blue-600" : "text-gray-500",
              )}
            >
              <route.icon className={cn("h-5 w-5 mr-3", route.active ? "text-blue-600" : "text-gray-400")} />
              {route.label}
            </Link>
          ))}
        </div>
      </div>
      <div className="mt-auto px-3 py-4">
        <Button variant="outline" className="w-full justify-start" asChild>
          <Link href="/api/auth/logout">
            <LogOut className="h-5 w-5 mr-3 text-gray-400" />
            Logout
          </Link>
        </Button>
      </div>
    </div>
  )
}
