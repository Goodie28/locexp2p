"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Bell, MessageSquare, AlertTriangle, CheckCircle, Clock, Filter, RefreshCw, CheckCheck } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Notification {
  id: string
  title: string
  description: string
  type: "message" | "alert" | "system" | "transaction"
  timestamp: Date
  read: boolean
  user?: {
    name: string
    avatar?: string
  }
  actionUrl?: string
}

export default function NotificationsPage() {
  const [activeTab, setActiveTab] = useState("all")

  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: "New message from John Doe",
      description: "I need help with my coin purchase",
      type: "message",
      timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      read: false,
      user: {
        name: "John Doe",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      actionUrl: "/admin/messages",
    },
    {
      id: "2",
      title: "New message from Jane Smith",
      description: "When will the next auction start?",
      type: "message",
      timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      read: true,
      user: {
        name: "Jane Smith",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      actionUrl: "/admin/messages",
    },
    {
      id: "3",
      title: "Transaction dispute",
      description: "A transaction between Robert Williams and Mary Johnson requires your attention",
      type: "alert",
      timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      read: false,
      actionUrl: "/admin/transactions",
    },
    {
      id: "4",
      title: "System maintenance completed",
      description: "The scheduled system maintenance has been completed successfully",
      type: "system",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
      read: true,
    },
    {
      id: "5",
      title: "New coin approval request",
      description: "A new coin approval request has been submitted by David Miller",
      type: "transaction",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5 hours ago
      read: false,
      user: {
        name: "David Miller",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      actionUrl: "/admin/approve-coins",
    },
    {
      id: "6",
      title: "Weekly report available",
      description: "The weekly transaction report is now available for review",
      type: "system",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
      read: true,
      actionUrl: "/admin/analytics",
    },
    {
      id: "7",
      title: "New message from Robert Williams",
      description: "I'm having trouble with my withdrawal",
      type: "message",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 25), // 25 hours ago
      read: false,
      user: {
        name: "Robert Williams",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      actionUrl: "/admin/messages",
    },
  ])

  const filteredNotifications = notifications.filter((notification) => {
    if (activeTab === "all") return true
    if (activeTab === "unread") return !notification.read
    if (activeTab === "messages") return notification.type === "message"
    if (activeTab === "alerts") return notification.type === "alert"
    if (activeTab === "system") return notification.type === "system" || notification.type === "transaction"
    return true
  })

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications(
      notifications.map((notification) => {
        if (notification.id === id) {
          return { ...notification, read: true }
        }
        return notification
      }),
    )
  }

  const markAllAsRead = () => {
    setNotifications(
      notifications.map((notification) => ({
        ...notification,
        read: true,
      })),
    )
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`

    const diffInHours = Math.floor(diffInMinutes / 60)
    if (diffInHours < 24) return `${diffInHours}h ago`

    const diffInDays = Math.floor(diffInHours / 24)
    if (diffInDays === 1) return "Yesterday"
    if (diffInDays < 7) return `${diffInDays}d ago`

    return date.toLocaleDateString()
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "message":
        return <MessageSquare className="h-5 w-5 text-blue-600" />
      case "alert":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case "transaction":
        return <Clock className="h-5 w-5 text-purple-600" />
      case "system":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      default:
        return <Bell className="h-5 w-5 text-gray-600" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Notifications</h1>
          <p className="text-muted-foreground">Stay updated with platform activities and member interactions</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={markAllAsRead} disabled={unreadCount === 0}>
            <CheckCheck className="h-4 w-4 mr-2" />
            Mark all as read
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setActiveTab("all")}>All notifications</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveTab("unread")}>Unread</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveTab("messages")}>Messages</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveTab("alerts")}>Alerts</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveTab("system")}>System</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-5 w-full sm:w-auto">
          <TabsTrigger value="all" className="text-xs sm:text-sm">
            All
            {unreadCount > 0 && (
              <Badge variant="default" className="ml-2 bg-blue-600">
                {unreadCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="unread" className="text-xs sm:text-sm">
            Unread
          </TabsTrigger>
          <TabsTrigger value="messages" className="text-xs sm:text-sm">
            Messages
          </TabsTrigger>
          <TabsTrigger value="alerts" className="text-xs sm:text-sm">
            Alerts
          </TabsTrigger>
          <TabsTrigger value="system" className="text-xs sm:text-sm">
            System
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Notifications</CardTitle>
              <CardDescription>
                {filteredNotifications.length} {activeTab !== "all" ? activeTab : ""} notification
                {filteredNotifications.length !== 1 ? "s" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {filteredNotifications.length > 0 ? (
                <div className="divide-y">
                  {filteredNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`flex items-start gap-4 p-4 hover:bg-muted/50 transition-colors ${
                        !notification.read ? "bg-blue-50/50" : ""
                      }`}
                    >
                      <div className="mt-1">{getNotificationIcon(notification.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium">{notification.title}</p>
                            <p className="text-sm text-muted-foreground mt-1">{notification.description}</p>
                            {notification.user && (
                              <div className="flex items-center gap-2 mt-2">
                                <Avatar className="h-6 w-6">
                                  <AvatarImage
                                    src={notification.user.avatar || "/placeholder.svg"}
                                    alt={notification.user.name}
                                  />
                                  <AvatarFallback>
                                    {notification.user.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-sm">{notification.user.name}</span>
                              </div>
                            )}
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                              {formatTime(notification.timestamp)}
                            </span>
                            {!notification.read && (
                              <Badge variant="default" className="bg-blue-600">
                                New
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex justify-between items-center mt-3">
                          {notification.actionUrl && (
                            <Button variant="link" size="sm" className="px-0 h-auto" asChild>
                              <a href={notification.actionUrl}>View details</a>
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => markAsRead(notification.id)}
                            disabled={notification.read}
                          >
                            {notification.read ? "Read" : "Mark as read"}
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <div className="rounded-full bg-blue-100 p-3 mb-4">
                    <Bell className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No notifications</h3>
                  <p className="text-muted-foreground max-w-md">
                    You're all caught up! There are no {activeTab !== "all" ? activeTab : ""} notifications at the
                    moment.
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter className="border-t p-4 flex justify-between">
              <p className="text-sm text-muted-foreground">
                Showing {filteredNotifications.length} of {notifications.length} notifications
              </p>
              <Button variant="outline" size="sm">
                View all
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
