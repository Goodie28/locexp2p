"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Coins, Plus, Trash2, Clock, Calendar } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// Mock data for auction pool coins
const mockAuctionPool = [
  {
    id: "coin-001",
    amount: 5000,
    addedDate: "2023-04-20",
    status: "scheduled",
    auctionDate: "2023-04-28",
    source: "System Generated",
  },
  {
    id: "coin-002",
    amount: 2500,
    addedDate: "2023-04-21",
    status: "scheduled",
    auctionDate: "2023-04-28",
    source: "Member Withdrawal",
  },
  {
    id: "coin-003",
    amount: 7500,
    addedDate: "2023-04-22",
    status: "scheduled",
    auctionDate: "2023-04-28",
    source: "System Generated",
  },
  {
    id: "coin-004",
    amount: 3000,
    addedDate: "2023-04-23",
    status: "pending",
    auctionDate: "2023-05-05",
    source: "Member Withdrawal",
  },
  {
    id: "coin-005",
    amount: 10000,
    addedDate: "2023-04-24",
    status: "pending",
    auctionDate: "2023-05-05",
    source: "System Generated",
  },
]

// Mock data for upcoming auctions
const upcomingAuctions = [
  {
    id: "auction-001",
    date: "2023-04-28",
    time: "12:00 PM",
    totalCoins: 15000,
    status: "scheduled",
  },
  {
    id: "auction-002",
    date: "2023-05-05",
    time: "12:00 PM",
    totalCoins: 13000,
    status: "pending",
  },
]

export default function AuctionPoolPage() {
  const { toast } = useToast()
  const [auctionPool, setAuctionPool] = useState(mockAuctionPool)
  const [newCoinAmount, setNewCoinAmount] = useState("")
  const [selectedAuction, setSelectedAuction] = useState(upcomingAuctions[0].id)

  // Calculate totals
  const totalCoinsInPool = auctionPool.reduce((sum, coin) => sum + coin.amount, 0)
  const nextAuctionCoins = auctionPool
    .filter((coin) => coin.status === "scheduled")
    .reduce((sum, coin) => sum + coin.amount, 0)

  const handleAddCoins = () => {
    if (!newCoinAmount || isNaN(Number(newCoinAmount)) || Number(newCoinAmount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid coin amount",
        variant: "destructive",
      })
      return
    }

    const selectedAuctionData = upcomingAuctions.find((auction) => auction.id === selectedAuction)

    const newCoin = {
      id: `coin-${Date.now()}`,
      amount: Number(newCoinAmount),
      addedDate: new Date().toISOString().split("T")[0],
      status: selectedAuctionData?.status || "pending",
      auctionDate: selectedAuctionData?.date || "Not assigned",
      source: "Admin Added",
    }

    setAuctionPool([...auctionPool, newCoin])
    setNewCoinAmount("")

    toast({
      title: "Coins added to pool",
      description: `${newCoinAmount} coins added to the auction pool`,
    })
  }

  const handleRemoveCoin = (coinId: string) => {
    setAuctionPool(auctionPool.filter((coin) => coin.id !== coinId))
    toast({
      title: "Coins removed",
      description: "Coins have been removed from the auction pool",
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "scheduled":
        return <Badge className="bg-green-500">Scheduled</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>
      default:
        return <Badge className="bg-gray-500">Unknown</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold tracking-tight">Auction Pool Management</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Coins to Pool
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Coins to Auction Pool</DialogTitle>
              <DialogDescription>Enter the amount of coins to add to the auction pool.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="coin-amount">Coin Amount</label>
                <Input
                  id="coin-amount"
                  type="number"
                  placeholder="Enter coin amount"
                  value={newCoinAmount}
                  onChange={(e) => setNewCoinAmount(e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="auction-select">Select Auction</label>
                <select
                  id="auction-select"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={selectedAuction}
                  onChange={(e) => setSelectedAuction(e.target.value)}
                >
                  {upcomingAuctions.map((auction) => (
                    <option key={auction.id} value={auction.id}>
                      {auction.date} - {auction.time} ({auction.totalCoins} coins)
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleAddCoins}>Add to Pool</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Coins in Pool</CardTitle>
            <Coins className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCoinsInPool.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Coins available for auctions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Auction Coins</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{nextAuctionCoins.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Scheduled for next auction</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Auction Date</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingAuctions[0].date}</div>
            <p className="text-xs text-muted-foreground">{upcomingAuctions[0].time}</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="scheduled">
        <TabsList>
          <TabsTrigger value="scheduled">Scheduled Coins</TabsTrigger>
          <TabsTrigger value="pending">Pending Coins</TabsTrigger>
          <TabsTrigger value="all">All Coins</TabsTrigger>
        </TabsList>

        <TabsContent value="scheduled" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Coins Scheduled for Next Auction</CardTitle>
              <CardDescription>
                These coins are scheduled for the next auction on {upcomingAuctions[0].date} at{" "}
                {upcomingAuctions[0].time}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Added Date</TableHead>
                    <TableHead>Auction Date</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auctionPool
                    .filter((coin) => coin.status === "scheduled")
                    .map((coin) => (
                      <TableRow key={coin.id}>
                        <TableCell className="font-medium">{coin.id}</TableCell>
                        <TableCell>{coin.amount.toLocaleString()}</TableCell>
                        <TableCell>{coin.addedDate}</TableCell>
                        <TableCell>{coin.auctionDate}</TableCell>
                        <TableCell>{coin.source}</TableCell>
                        <TableCell>{getStatusBadge(coin.status)}</TableCell>
                        <TableCell>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" size="sm">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Remove from Auction Pool?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will remove {coin.amount.toLocaleString()} coins from the auction pool. This
                                  action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleRemoveCoin(coin.id)}>Remove</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Coins</CardTitle>
              <CardDescription>These coins are pending assignment to future auctions</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Added Date</TableHead>
                    <TableHead>Auction Date</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auctionPool
                    .filter((coin) => coin.status === "pending")
                    .map((coin) => (
                      <TableRow key={coin.id}>
                        <TableCell className="font-medium">{coin.id}</TableCell>
                        <TableCell>{coin.amount.toLocaleString()}</TableCell>
                        <TableCell>{coin.addedDate}</TableCell>
                        <TableCell>{coin.auctionDate}</TableCell>
                        <TableCell>{coin.source}</TableCell>
                        <TableCell>{getStatusBadge(coin.status)}</TableCell>
                        <TableCell>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" size="sm">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Remove from Auction Pool?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will remove {coin.amount.toLocaleString()} coins from the auction pool. This
                                  action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleRemoveCoin(coin.id)}>Remove</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Auction Pool Coins</CardTitle>
              <CardDescription>Complete list of all coins in the auction pool</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Added Date</TableHead>
                    <TableHead>Auction Date</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auctionPool.map((coin) => (
                    <TableRow key={coin.id}>
                      <TableCell className="font-medium">{coin.id}</TableCell>
                      <TableCell>{coin.amount.toLocaleString()}</TableCell>
                      <TableCell>{coin.addedDate}</TableCell>
                      <TableCell>{coin.auctionDate}</TableCell>
                      <TableCell>{coin.source}</TableCell>
                      <TableCell>{getStatusBadge(coin.status)}</TableCell>
                      <TableCell>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Remove from Auction Pool?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will remove {coin.amount.toLocaleString()} coins from the auction pool. This action
                                cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleRemoveCoin(coin.id)}>Remove</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Upcoming Auctions</CardTitle>
          <CardDescription>Schedule of upcoming auctions and their coin allocations</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Auction ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Total Coins</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {upcomingAuctions.map((auction) => (
                <TableRow key={auction.id}>
                  <TableCell className="font-medium">{auction.id}</TableCell>
                  <TableCell>{auction.date}</TableCell>
                  <TableCell>{auction.time}</TableCell>
                  <TableCell>{auction.totalCoins.toLocaleString()}</TableCell>
                  <TableCell>{getStatusBadge(auction.status)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Schedule New Auction</Button>
          <Button>Manage Auction Schedule</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
