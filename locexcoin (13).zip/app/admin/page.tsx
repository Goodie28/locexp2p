"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Coins, DollarSign, Clock, AlertTriangle, CheckCircle, XCircle, ArrowRight } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function AdminDashboardPage() {
  const { toast } = useToast()
  const [pendingApprovals, setPendingApprovals] = useState([
    {
      id: 1,
      user: "John Doe",
      amount: 100000,
      profit: 35000,
      total: 135000,
      plan: "7-Day Plan",
      submittedDate: "Apr 20, 2025",
    },
    {
      id: 2,
      user: "Mary Johnson",
      amount: 50000,
      profit: 53500,
      total: 103500,
      plan: "14-Day Plan",
      submittedDate: "Apr 19, 2025",
    },
    {
      id: 3,
      user: "Robert Williams",
      amount: 50000,
      profit: 17500,
      total: 67500,
      plan: "7-Day Plan",
      submittedDate: "Apr 19, 2025",
    },
  ])

  const [pendingCoinSales, setPendingCoinSales] = useState([
    {
      id: 101,
      user: "Sarah Brown",
      coinId: "COIN-006",
      amount: 75000,
      profit: 26250,
      total: 101250,
      salePrice: 110000,
      plan: "7-Day Plan",
      submittedDate: "Apr 22, 2025",
    },
    {
      id: 102,
      user: "Michael Davis",
      coinId: "COIN-008",
      amount: 50000,
      profit: 17500,
      total: 67500,
      salePrice: 70000,
      plan: "7-Day Plan",
      submittedDate: "Apr 21, 2025",
    },
  ])

  const [pendingTransactions, setPendingTransactions] = useState([
    {
      id: 1,
      buyer: "Sarah Brown",
      seller: "Michael Davis",
      amount: 100000,
      status: "Payment Proof Submitted",
      timeRemaining: "5 hours",
      date: "Apr 20, 2025",
    },
    {
      id: 2,
      buyer: "James Wilson",
      seller: "Jennifer Taylor",
      amount: 50000,
      status: "Seller Not Responding",
      timeRemaining: "Expired",
      date: "Apr 19, 2025",
    },
    {
      id: 3,
      buyer: "David Miller",
      seller: "Patricia Moore",
      amount: 75000,
      status: "Payment Overdue",
      timeRemaining: "Expired",
      date: "Apr 18, 2025",
    },
  ])

  const handleApprove = (id: number) => {
    setPendingApprovals(pendingApprovals.filter((item) => item.id !== id))
    toast({
      title: "Coin Approved",
      description: "The coin has been approved successfully.",
      variant: "success",
    })
  }

  const handleReject = (id: number) => {
    setPendingApprovals(pendingApprovals.filter((item) => item.id !== id))
    toast({
      title: "Coin Rejected",
      description: "The coin has been rejected.",
      variant: "destructive",
    })
  }

  const handleApproveSale = (id: number) => {
    setPendingCoinSales(pendingCoinSales.filter((item) => item.id !== id))
    toast({
      title: "Coin Sale Approved",
      description: "The coin has been approved for sale and listed in the marketplace.",
      variant: "success",
    })
  }

  const handleRejectSale = (id: number) => {
    setPendingCoinSales(pendingCoinSales.filter((item) => item.id !== id))
    toast({
      title: "Coin Sale Rejected",
      description: "The coin sale has been rejected.",
      variant: "destructive",
    })
  }

  const handleReleaseToUser = (id: number) => {
    setPendingTransactions(pendingTransactions.filter((item) => item.id !== id))
  }

  const handleCancelTransaction = (id: number) => {
    setPendingTransactions(pendingTransactions.filter((item) => item.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, Admin! Here&apos;s an overview of the platform.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/admin/create-coins">
              Create Fresh Coins
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,248</div>
            <p className="text-xs text-muted-foreground">+24 new users today</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Auctions</CardTitle>
            <Coins className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">Next auction in 3 hours</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₦24.5M</div>
            <p className="text-xs text-muted-foreground">+₦1.2M from yesterday</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingApprovals.length + pendingCoinSales.length}</div>
            <p className="text-xs text-muted-foreground">Requires your attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Pending Coin Sale Approvals */}
      <Card>
        <CardHeader>
          <CardTitle>Pending Coin Sale Approvals</CardTitle>
          <CardDescription>Approve or reject coins submitted for sale in the marketplace</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingCoinSales.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-7 gap-4 p-4 font-medium border-b">
                <div>User</div>
                <div>Coin ID</div>
                <div>Original Value</div>
                <div>Sale Price</div>
                <div>Plan</div>
                <div>Submitted Date</div>
                <div>Actions</div>
              </div>
              <div className="divide-y">
                {pendingCoinSales.map((item) => (
                  <div key={item.id} className="grid grid-cols-7 gap-4 p-4">
                    <div>{item.user}</div>
                    <div>{item.coinId}</div>
                    <div>₦{item.total.toLocaleString()}</div>
                    <div className="font-medium text-amber-600">₦{item.salePrice.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>{item.submittedDate}</div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleApproveSale(item.id)}
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleRejectSale(item.id)}>
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <div className="rounded-full bg-green-100 p-3 mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">No pending coin sale approvals</h3>
              <p className="text-muted-foreground mb-4">All coin sale submissions have been processed</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full">
            <Link href="/admin/coin-sales">View All Coin Sale Requests</Link>
          </Button>
        </CardFooter>
      </Card>

      {/* Pending Coin Approvals */}
      <Card>
        <CardHeader>
          <CardTitle>Pending Coin Approvals</CardTitle>
          <CardDescription>Approve or reject coins submitted for sale</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingApprovals.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-5 gap-4 p-4 font-medium border-b">
                <div>User</div>
                <div>Amount</div>
                <div>Plan</div>
                <div>Submitted Date</div>
                <div>Actions</div>
              </div>
              <div className="divide-y">
                {pendingApprovals.map((item) => (
                  <div key={item.id} className="grid grid-cols-5 gap-4 p-4">
                    <div>{item.user}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>{item.submittedDate}</div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleApprove(item.id)}
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleReject(item.id)}>
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <div className="rounded-full bg-green-100 p-3 mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">No pending approvals</h3>
              <p className="text-muted-foreground mb-4">All coin submissions have been processed</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full">
            <Link href="/admin/approve-coins">View All Approval Requests</Link>
          </Button>
        </CardFooter>
      </Card>

      {/* Pending Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-orange mr-2" />
            Pending Transactions
          </CardTitle>
          <CardDescription>Transactions that require admin intervention</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingTransactions.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-6 gap-4 p-4 font-medium border-b">
                <div>Buyer</div>
                <div>Seller</div>
                <div>Amount</div>
                <div>Status</div>
                <div>Time Remaining</div>
                <div>Actions</div>
              </div>
              <div className="divide-y">
                {pendingTransactions.map((item) => (
                  <div key={item.id} className="grid grid-cols-6 gap-4 p-4">
                    <div>{item.buyer}</div>
                    <div>{item.seller}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>
                      <Badge
                        variant="outline"
                        className={
                          item.status === "Payment Proof Submitted"
                            ? "bg-amber-50 text-amber-700 border-amber-200"
                            : item.status === "Seller Not Responding"
                              ? "bg-red-50 text-red-700 border-red-200"
                              : "bg-red-50 text-red-700 border-red-200"
                        }
                      >
                        {item.status}
                      </Badge>
                    </div>
                    <div className={item.timeRemaining === "Expired" ? "text-red-600 font-medium" : ""}>
                      {item.timeRemaining}
                    </div>
                    <div className="flex space-x-2">
                      {(item.status === "Seller Not Responding" || item.timeRemaining === "Expired") && (
                        <Button
                          size="sm"
                          className="bg-blue-600 hover:bg-blue-700"
                          onClick={() => handleReleaseToUser(item.id)}
                        >
                          Release
                        </Button>
                      )}
                      {item.status === "Payment Overdue" && (
                        <Button size="sm" variant="destructive" onClick={() => handleCancelTransaction(item.id)}>
                          Cancel
                        </Button>
                      )}
                      <Button size="sm" variant="outline">
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <div className="rounded-full bg-green-100 p-3 mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">No pending transactions</h3>
              <p className="text-muted-foreground mb-4">All transactions are proceeding smoothly</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full">
            <Link href="/admin/transactions">View All Transactions</Link>
          </Button>
        </CardFooter>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Create Fresh Coins</CardTitle>
            <CardDescription>Add new coins to the auction pool</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Create new coins for today's auction or assign directly to users
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <Link href="/admin/create-coins">Create Coins</Link>
            </Button>
          </CardFooter>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Manage Bank Details</CardTitle>
            <CardDescription>Set up payment accounts</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Manage bank accounts where members can make payments</p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <Link href="/admin/bank-details">Manage Banks</Link>
            </Button>
          </CardFooter>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Manage Users</CardTitle>
            <CardDescription>View and manage user accounts</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Review user accounts, reset passwords, or suspend accounts if needed
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <Link href="/admin/users">Manage Users</Link>
            </Button>
          </CardFooter>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>View Reports</CardTitle>
            <CardDescription>Access platform analytics and reports</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              View detailed reports on transactions, user growth, and platform performance
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <Link href="/admin/reports">View Reports</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
