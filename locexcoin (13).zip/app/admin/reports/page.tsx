"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import {
  Download,
  Calendar,
  Filter,
  RefreshCw,
  Users,
  CreditCard,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Activity,
  Shield,
  Search,
} from "lucide-react"

// Sample data for charts and tables
const userGrowthData = [
  { name: "Jan", users: 400 },
  { name: "Feb", users: 600 },
  { name: "Mar", users: 800 },
  { name: "Apr", users: 1000 },
  { name: "May", users: 1200 },
  { name: "Jun", users: 1500 },
  { name: "Jul", users: 1800 },
]

const transactionData = [
  { name: "Jan", value: 1200000 },
  { name: "Feb", value: 1900000 },
  { name: "Mar", value: 2400000 },
  { name: "Apr", value: 1800000 },
  { name: "May", value: 2800000 },
  { name: "Jun", value: 3600000 },
  { name: "Jul", value: 4200000 },
]

const auctionData = [
  { name: "Jan", completed: 12, cancelled: 2 },
  { name: "Feb", completed: 18, cancelled: 3 },
  { name: "Mar", completed: 24, cancelled: 4 },
  { name: "Apr", completed: 32, cancelled: 3 },
  { name: "May", completed: 40, cancelled: 5 },
  { name: "Jun", completed: 48, cancelled: 6 },
  { name: "Jul", completed: 56, cancelled: 4 },
]

const referralData = [
  { name: "Jan", signups: 45, commissions: 15 },
  { name: "Feb", signups: 65, commissions: 22 },
  { name: "Mar", signups: 85, commissions: 30 },
  { name: "Apr", signups: 105, commissions: 42 },
  { name: "May", signups: 125, commissions: 55 },
  { name: "Jun", signups: 145, commissions: 68 },
  { name: "Jul", signups: 165, commissions: 75 },
]

const adminActivityData = [
  { name: "Jan", approvals: 35, rejections: 5, edits: 20 },
  { name: "Feb", approvals: 42, rejections: 8, edits: 25 },
  { name: "Mar", approvals: 50, rejections: 10, edits: 30 },
  { name: "Apr", approvals: 65, rejections: 12, edits: 35 },
  { name: "May", approvals: 75, rejections: 15, edits: 40 },
  { name: "Jun", approvals: 85, rejections: 18, edits: 45 },
  { name: "Jul", approvals: 95, rejections: 20, edits: 50 },
]

const userTypeData = [
  { name: "Active Buyers", value: 540 },
  { name: "Active Sellers", value: 320 },
  { name: "Inactive", value: 210 },
  { name: "New Users", value: 180 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

// Sample data for admin activity log
const adminActivityLog = [
  {
    id: "ACT-001",
    admin: "Admin",
    action: "Approved coin",
    details: "Approved coin submission from John Doe (₦135,000)",
    timestamp: "2025-04-23T09:30:00",
    category: "Coin Approval",
  },
  {
    id: "ACT-002",
    admin: "Admin",
    action: "Released coins",
    details: "Released coins to buyer Sarah Brown in transaction #TX-123",
    timestamp: "2025-04-23T10:15:00",
    category: "Transaction",
  },
  {
    id: "ACT-003",
    admin: "Admin",
    action: "Created coins",
    details: "Created 5 new coins worth ₦500,000 total",
    timestamp: "2025-04-23T11:45:00",
    category: "Coin Creation",
  },
  {
    id: "ACT-004",
    admin: "Admin",
    action: "Updated bank details",
    details: "Added new bank account for payments",
    timestamp: "2025-04-22T14:20:00",
    category: "Settings",
  },
  {
    id: "ACT-005",
    admin: "Admin",
    action: "Approved withdrawal",
    details: "Approved referral withdrawal for Michael Brown (₦10,000)",
    timestamp: "2025-04-22T16:05:00",
    category: "Referral",
  },
  {
    id: "ACT-006",
    admin: "Admin",
    action: "Rejected coin",
    details: "Rejected coin submission from David Miller (₦25,000)",
    timestamp: "2025-04-21T09:10:00",
    category: "Coin Approval",
  },
  {
    id: "ACT-007",
    admin: "Admin",
    action: "Suspended user",
    details: "Suspended user account for Mary Johnson due to suspicious activity",
    timestamp: "2025-04-21T13:40:00",
    category: "User Management",
  },
  {
    id: "ACT-008",
    admin: "Admin",
    action: "Cancelled transaction",
    details: "Cancelled transaction #TX-456 due to payment timeout",
    timestamp: "2025-04-20T15:30:00",
    category: "Transaction",
  },
  {
    id: "ACT-009",
    admin: "Admin",
    action: "Reset password",
    details: "Reset password for user James Wilson",
    timestamp: "2025-04-20T16:45:00",
    category: "User Management",
  },
  {
    id: "ACT-010",
    admin: "Admin",
    action: "Responded to message",
    details: "Responded to support message from Jennifer Taylor",
    timestamp: "2025-04-19T10:20:00",
    category: "Support",
  },
]

// Sample data for system events
const systemEvents = [
  {
    id: "SYS-001",
    event: "Auction started",
    details: "Daily auction #AUC-789 started with 5 coins",
    timestamp: "2025-04-23T09:00:00",
    severity: "info",
  },
  {
    id: "SYS-002",
    event: "Auction completed",
    details: "Daily auction #AUC-789 completed with 5/5 coins sold",
    timestamp: "2025-04-23T09:10:00",
    severity: "info",
  },
  {
    id: "SYS-003",
    event: "Payment gateway error",
    details: "Temporary connection issue with payment processor",
    timestamp: "2025-04-22T14:35:00",
    severity: "warning",
  },
  {
    id: "SYS-004",
    event: "System maintenance",
    details: "Scheduled system maintenance completed",
    timestamp: "2025-04-21T02:00:00",
    severity: "info",
  },
  {
    id: "SYS-005",
    event: "Database backup",
    details: "Automatic database backup completed successfully",
    timestamp: "2025-04-21T01:00:00",
    severity: "info",
  },
  {
    id: "SYS-006",
    event: "Login attempts exceeded",
    details: "Multiple failed login attempts for user account robert.williams@example.com",
    timestamp: "2025-04-20T18:25:00",
    severity: "warning",
  },
  {
    id: "SYS-007",
    event: "API rate limit exceeded",
    details: "Rate limit exceeded for IP 192.168.1.1",
    timestamp: "2025-04-19T16:40:00",
    severity: "warning",
  },
  {
    id: "SYS-008",
    event: "New version deployed",
    details: "Platform updated to version 2.3.0",
    timestamp: "2025-04-18T03:15:00",
    severity: "info",
  },
]

// Sample data for transaction log
const transactionLog = [
  {
    id: "TX-001",
    buyer: "Sarah Brown",
    seller: "Michael Davis",
    amount: 100000,
    type: "Coin Purchase",
    status: "Completed",
    timestamp: "2025-04-23T08:45:00",
  },
  {
    id: "TX-002",
    buyer: "James Wilson",
    seller: "Jennifer Taylor",
    amount: 50000,
    type: "Coin Purchase",
    status: "Pending",
    timestamp: "2025-04-23T09:30:00",
  },
  {
    id: "TX-003",
    buyer: "System",
    seller: "John Doe",
    amount: 135000,
    type: "Coin Creation",
    status: "Completed",
    timestamp: "2025-04-22T14:15:00",
  },
  {
    id: "TX-004",
    buyer: "System",
    seller: "Michael Brown",
    amount: 10000,
    type: "Referral Withdrawal",
    status: "Approved",
    timestamp: "2025-04-22T16:05:00",
  },
  {
    id: "TX-005",
    buyer: "David Miller",
    seller: "Patricia Moore",
    amount: 75000,
    type: "Coin Purchase",
    status: "Cancelled",
    timestamp: "2025-04-21T11:20:00",
  },
  {
    id: "TX-006",
    buyer: "System",
    seller: "Robert Johnson",
    amount: 1000,
    type: "Signup Bonus",
    status: "Completed",
    timestamp: "2025-04-21T09:45:00",
  },
  {
    id: "TX-007",
    buyer: "Thomas Wilson",
    seller: "Emily Clark",
    amount: 200000,
    type: "Coin Purchase",
    status: "Completed",
    timestamp: "2025-04-20T15:30:00",
  },
  {
    id: "TX-008",
    buyer: "System",
    seller: "Lisa Anderson",
    amount: 20000,
    type: "Commission",
    status: "Completed",
    timestamp: "2025-04-20T10:15:00",
  },
]

export default function ReportsPage() {
  const [timeRange, setTimeRange] = useState("7d")
  const [activitySearchQuery, setActivitySearchQuery] = useState("")
  const [transactionSearchQuery, setTransactionSearchQuery] = useState("")
  const [systemEventSearchQuery, setSystemEventSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [severityFilter, setSeverityFilter] = useState("all")
  const [transactionTypeFilter, setTransactionTypeFilter] = useState("all")
  const [transactionStatusFilter, setTransactionStatusFilter] = useState("all")

  // Filter admin activity log
  const filteredActivityLog = adminActivityLog.filter((activity) => {
    const matchesSearch =
      activity.action.toLowerCase().includes(activitySearchQuery.toLowerCase()) ||
      activity.details.toLowerCase().includes(activitySearchQuery.toLowerCase()) ||
      activity.admin.toLowerCase().includes(activitySearchQuery.toLowerCase()) ||
      activity.id.toLowerCase().includes(activitySearchQuery.toLowerCase())

    const matchesCategory = categoryFilter === "all" || activity.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  // Filter system events
  const filteredSystemEvents = systemEvents.filter((event) => {
    const matchesSearch =
      event.event.toLowerCase().includes(systemEventSearchQuery.toLowerCase()) ||
      event.details.toLowerCase().includes(systemEventSearchQuery.toLowerCase()) ||
      event.id.toLowerCase().includes(systemEventSearchQuery.toLowerCase())

    const matchesSeverity = severityFilter === "all" || event.severity === severityFilter

    return matchesSearch && matchesSeverity
  })

  // Filter transactions
  const filteredTransactions = transactionLog.filter((transaction) => {
    const matchesSearch =
      transaction.buyer.toLowerCase().includes(transactionSearchQuery.toLowerCase()) ||
      transaction.seller.toLowerCase().includes(transactionSearchQuery.toLowerCase()) ||
      transaction.id.toLowerCase().includes(transactionSearchQuery.toLowerCase())

    const matchesType = transactionTypeFilter === "all" || transaction.type === transactionTypeFilter
    const matchesStatus = transactionStatusFilter === "all" || transaction.status === transactionStatusFilter

    return matchesSearch && matchesType && matchesStatus
  })

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleString("en-NG", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getSeverityBadge = (severity) => {
    switch (severity) {
      case "info":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Info
          </Badge>
        )
      case "warning":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Warning
          </Badge>
        )
      case "error":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Error
          </Badge>
        )
      default:
        return <Badge variant="outline">{severity}</Badge>
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "Completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Completed
          </Badge>
        )
      case "Pending":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Pending
          </Badge>
        )
      case "Approved":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Approved
          </Badge>
        )
      case "Cancelled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">Comprehensive platform activity and performance reports</p>
        </div>
        <div className="flex items-center gap-2">
          <Select defaultValue="7d" onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24 hours</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Custom Range
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,248</div>
            <div className="flex items-center pt-1 text-xs text-green-600">
              <ArrowUpRight className="h-4 w-4 mr-1" />
              <span>+12.5% from last month</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,345</div>
            <div className="flex items-center pt-1 text-xs text-green-600">
              <ArrowUpRight className="h-4 w-4 mr-1" />
              <span>+18.2% from last month</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transaction Volume</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₦24.5M</div>
            <div className="flex items-center pt-1 text-xs text-green-600">
              <ArrowUpRight className="h-4 w-4 mr-1" />
              <span>+24.3% from last month</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Auctions</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <div className="flex items-center pt-1 text-xs text-red-600">
              <ArrowDownRight className="h-4 w-4 mr-1" />
              <span>-1 from yesterday</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="grid grid-cols-6 w-full">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="auctions">Auctions</TabsTrigger>
          <TabsTrigger value="referrals">Referrals</TabsTrigger>
          <TabsTrigger value="admin">Admin Activity</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Platform Activity Overview</CardTitle>
                <CardDescription>Key metrics across all platform areas</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { name: "Jan", users: 400, transactions: 300, auctions: 20, referrals: 45 },
                        { name: "Feb", users: 600, transactions: 400, auctions: 25, referrals: 65 },
                        { name: "Mar", users: 800, transactions: 500, auctions: 30, referrals: 85 },
                        { name: "Apr", users: 1000, transactions: 600, auctions: 35, referrals: 105 },
                        { name: "May", users: 1200, transactions: 700, auctions: 40, referrals: 125 },
                        { name: "Jun", users: 1500, transactions: 800, auctions: 45, referrals: 145 },
                        { name: "Jul", users: 1800, transactions: 900, auctions: 50, referrals: 165 },
                      ]}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="users" stroke="#0070f3" activeDot={{ r: 8 }} />
                      <Line type="monotone" dataKey="transactions" stroke="#00C49F" />
                      <Line type="monotone" dataKey="auctions" stroke="#FFBB28" />
                      <Line type="monotone" dataKey="referrals" stroke="#FF8042" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Activity Distribution</CardTitle>
                <CardDescription>Breakdown of platform activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: "User Registrations", value: 1248 },
                          { name: "Transactions", value: 2345 },
                          { name: "Auctions", value: 210 },
                          { name: "Referrals", value: 450 },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {userTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Transaction Volume</CardTitle>
                <CardDescription>Total transaction amount over time</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={transactionData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`₦${(value / 1000000).toFixed(2)}M`, "Transaction Volume"]} />
                      <Legend />
                      <Bar dataKey="value" fill="#0070f3" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest platform events</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="rounded-full bg-blue-100 p-2">
                      <Activity className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Auction completed</p>
                      <p className="text-sm text-muted-foreground">
                        Daily auction #AUC-789 completed with 5/5 coins sold
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="rounded-full bg-green-100 p-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Large transaction completed</p>
                      <p className="text-sm text-muted-foreground">
                        ₦200,000 transaction between Thomas Wilson and Emily Clark
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">5 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="rounded-full bg-amber-100 p-2">
                      <Shield className="h-4 w-4 text-amber-600" />
                    </div>
                    <div>
                      <p className="font-medium">Admin action</p>
                      <p className="text-sm text-muted-foreground">
                        Admin approved referral withdrawal for Michael Brown
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Yesterday</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>User Growth</CardTitle>
                <CardDescription>New user registrations over time</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={userGrowthData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`${value} users`, "Total Users"]} />
                      <Legend />
                      <Line type="monotone" dataKey="users" stroke="#0070f3" activeDot={{ r: 8 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>User Distribution</CardTitle>
                <CardDescription>Breakdown of user types</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={userTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {userTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} users`, ""]} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>User Activity Metrics</CardTitle>
              <CardDescription>Detailed user engagement statistics</CardDescription>
            </CardHeader>
            <CardContent className="px-2">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { name: "Jan", newUsers: 45, activeUsers: 350, transactions: 300 },
                      { name: "Feb", newUsers: 65, activeUsers: 420, transactions: 380 },
                      { name: "Mar", newUsers: 85, activeUsers: 500, transactions: 450 },
                      { name: "Apr", newUsers: 105, activeUsers: 580, transactions: 520 },
                      { name: "May", newUsers: 125, activeUsers: 650, transactions: 600 },
                      { name: "Jun", newUsers: 145, activeUsers: 750, transactions: 680 },
                      { name: "Jul", newUsers: 165, activeUsers: 850, transactions: 750 },
                    ]}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="newUsers" fill="#0070f3" />
                    <Bar dataKey="activeUsers" fill="#00C49F" />
                    <Bar dataKey="transactions" fill="#FFBB28" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Transactions Tab */}
        <TabsContent value="transactions" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Transaction Volume</CardTitle>
                <CardDescription>Total transaction amount over time</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={transactionData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`₦${(value / 1000000).toFixed(2)}M`, "Transaction Volume"]} />
                      <Legend />
                      <Bar dataKey="value" fill="#0070f3" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Transaction Types</CardTitle>
                <CardDescription>Breakdown of transaction categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Coin Purchases", value: 1500 },
                          { name: "Coin Creation", value: 350 },
                          { name: "Referral Withdrawals", value: 200 },
                          { name: "Commissions", value: 295 },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {userTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Transaction Log</CardTitle>
                <CardDescription>Recent platform transactions</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative w-[250px]">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search transactions..."
                    className="pl-8"
                    value={transactionSearchQuery}
                    onChange={(e) => setTransactionSearchQuery(e.target.value)}
                  />
                </div>
                <Select defaultValue="all" onValueChange={setTransactionTypeFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Coin Purchase">Coin Purchase</SelectItem>
                    <SelectItem value="Coin Creation">Coin Creation</SelectItem>
                    <SelectItem value="Referral Withdrawal">Referral Withdrawal</SelectItem>
                    <SelectItem value="Commission">Commission</SelectItem>
                    <SelectItem value="Signup Bonus">Signup Bonus</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="all" onValueChange={setTransactionStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>From</TableHead>
                    <TableHead>To</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.length > 0 ? (
                    filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-medium">{transaction.id}</TableCell>
                        <TableCell>{transaction.type}</TableCell>
                        <TableCell>{transaction.seller}</TableCell>
                        <TableCell>{transaction.buyer}</TableCell>
                        <TableCell>₦{transaction.amount.toLocaleString()}</TableCell>
                        <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                        <TableCell>{formatDate(transaction.timestamp)}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-6">
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <Search className="h-8 w-8 mb-2" />
                          <p>No transactions found</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Auctions Tab */}
        <TabsContent value="auctions" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Auction Performance</CardTitle>
                <CardDescription>Completed vs cancelled auctions</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={auctionData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="completed" fill="#0070f3" />
                      <Bar dataKey="cancelled" fill="#ff0000" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Auction Participation</CardTitle>
                <CardDescription>Average number of bids per auction</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { name: "Jan", avgBids: 8 },
                        { name: "Feb", avgBids: 10 },
                        { name: "Mar", avgBids: 12 },
                        { name: "Apr", avgBids: 15 },
                        { name: "May", avgBids: 18 },
                        { name: "Jun", avgBids: 22 },
                        { name: "Jul", avgBids: 25 },
                      ]}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`${value} bids`, "Average Bids"]} />
                      <Legend />
                      <Line type="monotone" dataKey="avgBids" stroke="#0070f3" activeDot={{ r: 8 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Auction Metrics</CardTitle>
              <CardDescription>Key performance indicators for auctions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Average Time to Sell</h3>
                  <p className="text-2xl font-bold">4.2 minutes</p>
                  <p className="text-xs text-muted-foreground mt-1">Out of 10 minute window</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Sell-Through Rate</h3>
                  <p className="text-2xl font-bold">94.5%</p>
                  <p className="text-xs text-muted-foreground mt-1">Coins sold vs. listed</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Average Participants</h3>
                  <p className="text-2xl font-bold">18.3</p>
                  <p className="text-xs text-muted-foreground mt-1">Bidders per auction</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Referrals Tab */}
        <TabsContent value="referrals" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Referral Performance</CardTitle>
                <CardDescription>Signups and commissions over time</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={referralData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="signups" fill="#0070f3" />
                      <Bar dataKey="commissions" fill="#00C49F" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Referral Metrics</CardTitle>
                <CardDescription>Key performance indicators for referrals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Conversion Rate</h3>
                    <p className="text-2xl font-bold">32.5%</p>
                    <p className="text-xs text-muted-foreground mt-1">Referred users who made investments</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Average Commission</h3>
                    <p className="text-2xl font-bold">₦12,500</p>
                    <p className="text-xs text-muted-foreground mt-1">Per successful referral</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Total Referral Earnings</h3>
                    <p className="text-2xl font-bold">₦3.2M</p>
                    <p className="text-xs text-muted-foreground mt-1">Paid to members</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Top Referrers</CardTitle>
              <CardDescription>Members with the most successful referrals</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rank</TableHead>
                    <TableHead>Member</TableHead>
                    <TableHead>Referrals</TableHead>
                    <TableHead>Conversion Rate</TableHead>
                    <TableHead>Total Earnings</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">1</TableCell>
                    <TableCell>John Doe</TableCell>
                    <TableCell>24</TableCell>
                    <TableCell>45.8%</TableCell>
                    <TableCell>₦240,000</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">2</TableCell>
                    <TableCell>Sarah Brown</TableCell>
                    <TableCell>18</TableCell>
                    <TableCell>38.9%</TableCell>
                    <TableCell>₦180,000</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">3</TableCell>
                    <TableCell>Michael Davis</TableCell>
                    <TableCell>15</TableCell>
                    <TableCell>40.0%</TableCell>
                    <TableCell>₦150,000</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">4</TableCell>
                    <TableCell>Jennifer Taylor</TableCell>
                    <TableCell>12</TableCell>
                    <TableCell>33.3%</TableCell>
                    <TableCell>₦120,000</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">5</TableCell>
                    <TableCell>Robert Johnson</TableCell>
                    <TableCell>10</TableCell>
                    <TableCell>30.0%</TableCell>
                    <TableCell>₦100,000</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Admin Activity Tab */}
        <TabsContent value="admin" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Admin Activity</CardTitle>
                <CardDescription>Actions performed by administrators</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={adminActivityData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="approvals" fill="#0070f3" />
                      <Bar dataKey="rejections" fill="#ff0000" />
                      <Bar dataKey="edits" fill="#00C49F" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>System Events</CardTitle>
                <CardDescription>Platform system events over time</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { name: "Jan", info: 45, warnings: 5, errors: 1 },
                        { name: "Feb", info: 52, warnings: 7, errors: 2 },
                        { name: "Mar", info: 58, warnings: 8, errors: 1 },
                        { name: "Apr", info: 65, warnings: 10, errors: 3 },
                        { name: "May", info: 72, warnings: 12, errors: 2 },
                        { name: "Jun", info: 80, warnings: 15, errors: 4 },
                        { name: "Jul", info: 88, warnings: 18, errors: 3 },
                      ]}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="info" stroke="#0070f3" />
                      <Line type="monotone" dataKey="warnings" stroke="#FFBB28" />
                      <Line type="monotone" dataKey="errors" stroke="#FF0000" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Admin Activity Log</CardTitle>
                <CardDescription>Recent actions performed by administrators</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative w-[250px]">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search activity..."
                    className="pl-8"
                    value={activitySearchQuery}
                    onChange={(e) => setActivitySearchQuery(e.target.value)}
                  />
                </div>
                <Select defaultValue="all" onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="Coin Approval">Coin Approval</SelectItem>
                    <SelectItem value="Transaction">Transaction</SelectItem>
                    <SelectItem value="Coin Creation">Coin Creation</SelectItem>
                    <SelectItem value="Settings">Settings</SelectItem>
                    <SelectItem value="Referral">Referral</SelectItem>
                    <SelectItem value="User Management">User Management</SelectItem>
                    <SelectItem value="Support">Support</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Admin</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Timestamp</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredActivityLog.length > 0 ? (
                    filteredActivityLog.map((activity) => (
                      <TableRow key={activity.id}>
                        <TableCell className="font-medium">{activity.id}</TableCell>
                        <TableCell>{activity.admin}</TableCell>
                        <TableCell>{activity.action}</TableCell>
                        <TableCell>{activity.category}</TableCell>
                        <TableCell className="max-w-xs truncate">{activity.details}</TableCell>
                        <TableCell>{formatDate(activity.timestamp)}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-6">
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <Search className="h-8 w-8 mb-2" />
                          <p>No activity found</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>System Events Log</CardTitle>
                <CardDescription>Platform system events and notifications</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative w-[250px]">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search events..."
                    className="pl-8"
                    value={systemEventSearchQuery}
                    onChange={(e) => setSystemEventSearchQuery(e.target.value)}
                  />
                </div>
                <Select defaultValue="all" onValueChange={setSeverityFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by severity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Severities</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Event</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Timestamp</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSystemEvents.length > 0 ? (
                    filteredSystemEvents.map((event) => (
                      <TableRow key={event.id}>
                        <TableCell className="font-medium">{event.id}</TableCell>
                        <TableCell>{event.event}</TableCell>
                        <TableCell>{getSeverityBadge(event.severity)}</TableCell>
                        <TableCell className="max-w-xs truncate">{event.details}</TableCell>
                        <TableCell>{formatDate(event.timestamp)}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-6">
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <Search className="h-8 w-8 mb-2" />
                          <p>No events found</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
