"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { CheckCircle, XCircle, Search, Filter, AlertTriangle, Eye } from "lucide-react"

export default function ApproveCoinPage() {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")

  const [pendingApprovals, setPendingApprovals] = useState([
    {
      id: 1,
      user: "John Doe",
      userId: "USER123",
      amount: 135000,
      plan: "7-Day Plan",
      submittedDate: "Apr 20, 2025",
      maturityDate: "Apr 27, 2025",
      status: "Pending",
    },
    {
      id: 2,
      user: "Mary Johnson",
      userId: "USER456",
      amount: 103500,
      plan: "14-Day Plan",
      submittedDate: "Apr 19, 2025",
      maturityDate: "May 3, 2025",
      status: "Pending",
    },
    {
      id: 3,
      user: "Robert Williams",
      userId: "USER789",
      amount: 50000,
      plan: "7-Day Plan",
      submittedDate: "Apr 19, 2025",
      maturityDate: "Apr 26, 2025",
      status: "Pending",
    },
    {
      id: 4,
      user: "Sarah Brown",
      userId: "USER101",
      amount: 315000,
      plan: "21-Day Plan",
      submittedDate: "Apr 18, 2025",
      maturityDate: "May 9, 2025",
      status: "Pending",
    },
    {
      id: 5,
      user: "Michael Davis",
      userId: "USER202",
      amount: 75000,
      plan: "7-Day Plan",
      submittedDate: "Apr 18, 2025",
      maturityDate: "Apr 25, 2025",
      status: "Pending",
    },
  ])

  const [approvedCoins, setApprovedCoins] = useState([
    {
      id: 101,
      user: "Jennifer Taylor",
      userId: "USER303",
      amount: 67500,
      plan: "7-Day Plan",
      submittedDate: "Apr 15, 2025",
      approvedDate: "Apr 16, 2025",
      status: "Approved",
    },
    {
      id: 102,
      user: "James Wilson",
      userId: "USER404",
      amount: 214000,
      plan: "21-Day Plan",
      submittedDate: "Apr 14, 2025",
      approvedDate: "Apr 15, 2025",
      status: "Approved",
    },
    {
      id: 103,
      user: "Patricia Moore",
      userId: "USER505",
      amount: 107000,
      plan: "14-Day Plan",
      submittedDate: "Apr 13, 2025",
      approvedDate: "Apr 14, 2025",
      status: "Approved",
    },
  ])

  const [rejectedCoins, setRejectedCoins] = useState([
    {
      id: 201,
      user: "Richard Miller",
      userId: "USER606",
      amount: 25000,
      plan: "7-Day Plan",
      submittedDate: "Apr 12, 2025",
      rejectedDate: "Apr 13, 2025",
      reason: "Insufficient recurring bids",
      status: "Rejected",
    },
    {
      id: 202,
      user: "Linda Garcia",
      userId: "USER707",
      amount: 45000,
      plan: "7-Day Plan",
      submittedDate: "Apr 11, 2025",
      rejectedDate: "Apr 12, 2025",
      reason: "Suspicious activity",
      status: "Rejected",
    },
  ])

  const handleApprove = (id: number) => {
    const coinToApprove = pendingApprovals.find((item) => item.id === id)
    if (coinToApprove) {
      const updatedCoin = {
        ...coinToApprove,
        status: "Approved",
        approvedDate: "Apr 21, 2025", // Today's date for demo
      }

      setPendingApprovals(pendingApprovals.filter((item) => item.id !== id))
      setApprovedCoins([updatedCoin, ...approvedCoins])

      toast({
        title: "Coin Approved",
        description: `Coin from ${coinToApprove.user} has been approved for auction.`,
      })
    }
  }

  const handleReject = (id: number) => {
    const coinToReject = pendingApprovals.find((item) => item.id === id)
    if (coinToReject) {
      const updatedCoin = {
        ...coinToReject,
        status: "Rejected",
        rejectedDate: "Apr 21, 2025", // Today's date for demo
        reason: "Admin rejection",
      }

      setPendingApprovals(pendingApprovals.filter((item) => item.id !== id))
      setRejectedCoins([updatedCoin, ...rejectedCoins])

      toast({
        title: "Coin Rejected",
        description: `Coin from ${coinToReject.user} has been rejected.`,
      })
    }
  }

  const filteredPending = pendingApprovals.filter(
    (item) =>
      item.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.userId.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredApproved = approvedCoins.filter(
    (item) =>
      item.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.userId.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredRejected = rejectedCoins.filter(
    (item) =>
      item.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.userId.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Approve Coins</h1>
        <p className="text-muted-foreground">Review and approve coins submitted for auction</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by user name or ID..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          Filter
        </Button>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending">Pending ({filteredPending.length})</TabsTrigger>
          <TabsTrigger value="approved">Approved ({filteredApproved.length})</TabsTrigger>
          <TabsTrigger value="rejected">Rejected ({filteredRejected.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          {filteredPending.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-7 gap-4 p-4 font-medium border-b">
                <div>User</div>
                <div>User ID</div>
                <div>Amount</div>
                <div>Plan</div>
                <div>Submitted</div>
                <div>Maturity</div>
                <div>Actions</div>
              </div>
              <div className="divide-y">
                {filteredPending.map((item) => (
                  <div key={item.id} className="grid grid-cols-7 gap-4 p-4">
                    <div>{item.user}</div>
                    <div className="text-muted-foreground">{item.userId}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>{item.submittedDate}</div>
                    <div>{item.maturityDate}</div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleApprove(item.id)}
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleReject(item.id)}>
                        <XCircle className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-blue-100 p-3 mb-4">
                    <CheckCircle className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No pending approvals</h3>
                  <p className="text-muted-foreground mb-4">All coin submissions have been processed</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-4">
          {filteredApproved.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-6 gap-4 p-4 font-medium border-b">
                <div>User</div>
                <div>User ID</div>
                <div>Amount</div>
                <div>Plan</div>
                <div>Submitted</div>
                <div>Approved</div>
              </div>
              <div className="divide-y">
                {filteredApproved.map((item) => (
                  <div key={item.id} className="grid grid-cols-6 gap-4 p-4">
                    <div>{item.user}</div>
                    <div className="text-muted-foreground">{item.userId}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>{item.submittedDate}</div>
                    <div>{item.approvedDate}</div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-gray-100 p-3 mb-4">
                    <AlertTriangle className="h-6 w-6 text-gray-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No approved coins found</h3>
                  <p className="text-muted-foreground mb-4">No coins match your search criteria</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="rejected" className="space-y-4">
          {filteredRejected.length > 0 ? (
            <div className="rounded-md border">
              <div className="grid grid-cols-6 gap-4 p-4 font-medium border-b">
                <div>User</div>
                <div>User ID</div>
                <div>Amount</div>
                <div>Plan</div>
                <div>Rejected</div>
                <div>Reason</div>
              </div>
              <div className="divide-y">
                {filteredRejected.map((item) => (
                  <div key={item.id} className="grid grid-cols-6 gap-4 p-4">
                    <div>{item.user}</div>
                    <div className="text-muted-foreground">{item.userId}</div>
                    <div>₦{item.amount.toLocaleString()}</div>
                    <div>{item.plan}</div>
                    <div>{item.rejectedDate}</div>
                    <div>{item.reason}</div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-gray-100 p-3 mb-4">
                    <AlertTriangle className="h-6 w-6 text-gray-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No rejected coins found</h3>
                  <p className="text-muted-foreground mb-4">No coins match your search criteria</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
