"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Search } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"

export default function CreateCoinsPage() {
  const { toast } = useToast()
  const [amount, setAmount] = useState("")
  const [isCreating, setIsCreating] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedMembers, setSelectedMembers] = useState<string[]>([])
  const [distributionMethod, setDistributionMethod] = useState("auction")

  // Mock member data
  const members = [
    { id: "1", name: "John Doe", email: "john@example.com" },
    { id: "2", name: "Jane Smith", email: "jane@example.com" },
    { id: "3", name: "Robert Johnson", email: "robert@example.com" },
    { id: "4", name: "Emily Davis", email: "emily@example.com" },
    { id: "5", name: "Michael Wilson", email: "michael@example.com" },
  ]

  const filteredMembers = members.filter(
    (member) =>
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleCreateCoins = () => {
    const coinAmount = Number(amount)

    if (!coinAmount) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      return
    }

    if (coinAmount < 10000) {
      toast({
        title: "Error",
        description: "Minimum coin amount is ₦10,000",
        variant: "destructive",
      })
      return
    }

    if (coinAmount > 5000000) {
      toast({
        title: "Error",
        description: "Maximum coin amount is ₦5,000,000",
        variant: "destructive",
      })
      return
    }

    if (distributionMethod === "direct" && selectedMembers.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one member to distribute coins to",
        variant: "destructive",
      })
      return
    }

    setIsCreating(true)

    // Simulate API call
    setTimeout(() => {
      setIsCreating(false)

      if (distributionMethod === "auction") {
        toast({
          title: "Success",
          description: `Created ₦${Number(amount).toLocaleString()} worth of coins for today's auction`,
        })
      } else {
        toast({
          title: "Success",
          description: `Distributed ₦${Number(amount).toLocaleString()} worth of coins to ${selectedMembers.length} members`,
        })
      }

      setAmount("")
      setSelectedMembers([])
    }, 1500)
  }

  const toggleMemberSelection = (memberId: string) => {
    if (selectedMembers.includes(memberId)) {
      setSelectedMembers(selectedMembers.filter((id) => id !== memberId))
    } else {
      setSelectedMembers([...selectedMembers, memberId])
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Create Coins</h1>
        <p className="text-muted-foreground">Create new coins for the platform</p>
      </div>

      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="create">Create Coins</TabsTrigger>
          <TabsTrigger value="history">Creation History</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Create New Coins</CardTitle>
              <CardDescription>Enter the amount and distribution method for the new coins</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Coin Amount (₦)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="Enter amount (₦10,000 - ₦5,000,000)"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">Min: ₦10,000 | Max: ₦5,000,000</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="distribution">Distribution Method</Label>
                <Select value={distributionMethod} onValueChange={setDistributionMethod}>
                  <SelectTrigger id="distribution">
                    <SelectValue placeholder="Select distribution method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auction">Add to Today's Auction</SelectItem>
                    <SelectItem value="direct">Distribute to Specific Members</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {distributionMethod === "direct" && (
                <div className="space-y-2 border rounded-md p-4">
                  <Label className="mb-2 block">Select Members</Label>
                  <div className="flex items-center space-x-2 mb-4">
                    <Search className="h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search members by name or email"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1"
                    />
                  </div>

                  <div className="max-h-60 overflow-y-auto border rounded-md">
                    {filteredMembers.length > 0 ? (
                      <div className="divide-y">
                        {filteredMembers.map((member) => (
                          <div key={member.id} className="flex items-center space-x-2 p-3">
                            <Checkbox
                              id={`member-${member.id}`}
                              checked={selectedMembers.includes(member.id)}
                              onCheckedChange={() => toggleMemberSelection(member.id)}
                            />
                            <Label htmlFor={`member-${member.id}`} className="flex-1 cursor-pointer">
                              <div>{member.name}</div>
                              <div className="text-sm text-muted-foreground">{member.email}</div>
                            </Label>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 text-center text-muted-foreground">No members found matching your search</div>
                    )}
                  </div>

                  <div className="mt-2 text-sm text-muted-foreground">{selectedMembers.length} members selected</div>
                </div>
              )}

              {amount && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-700 mb-2">Coin Summary</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <p className="text-muted-foreground">Amount:</p>
                    <p className="font-medium text-right">₦{Number(amount).toLocaleString()}</p>

                    <p className="text-muted-foreground">Distribution:</p>
                    <p className="font-medium text-right">
                      {distributionMethod === "auction" ? "Today's Auction" : `${selectedMembers.length} Members`}
                    </p>

                    <p className="text-muted-foreground">Profit Rate:</p>
                    <p className="font-medium text-green-600 text-right">35%</p>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button
                onClick={handleCreateCoins}
                disabled={isCreating}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {isCreating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating...
                  </>
                ) : (
                  "Create Coins"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Recent Coin Creation</CardTitle>
              <CardDescription>History of recently created coins</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-5 p-4 font-medium">
                  <div>Date</div>
                  <div>Amount</div>
                  <div>Distribution</div>
                  <div>Created By</div>
                  <div>Status</div>
                </div>
                <div className="divide-y">
                  <div className="grid grid-cols-5 p-4">
                    <div className="text-sm">2023-11-15 09:30</div>
                    <div className="text-sm">₦500,000</div>
                    <div className="text-sm">Auction</div>
                    <div className="text-sm">Admin</div>
                    <div className="text-sm">
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">Active</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 p-4">
                    <div className="text-sm">2023-11-14 16:45</div>
                    <div className="text-sm">₦1,000,000</div>
                    <div className="text-sm">Direct (3 members)</div>
                    <div className="text-sm">Admin</div>
                    <div className="text-sm">
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">Active</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 p-4">
                    <div className="text-sm">2023-11-13 11:20</div>
                    <div className="text-sm">₦750,000</div>
                    <div className="text-sm">Auction</div>
                    <div className="text-sm">Admin</div>
                    <div className="text-sm">
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">Active</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
