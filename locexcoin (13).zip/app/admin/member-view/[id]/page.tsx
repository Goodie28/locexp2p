"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import {
  User,
  ArrowLeft,
  Shield,
  Coins,
  DollarSign,
  Users,
  Clock,
  CheckCircle,
  AlertTriangle,
  Eye,
  Ban,
  Mail,
  Phone,
} from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { useRouter } from "next/navigation"

export default function MemberViewPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const memberId = params.id

  // Mock member data
  const [memberData, setMemberData] = useState({
    id: Number.parseInt(memberId),
    name: "John Smith",
    email: "john@example.com",
    phone: "+2348012345678",
    joinDate: "Apr 15, 2025",
    status: "active",
    totalInvestments: 3,
    totalValue: 250000,
    referrals: 12,
    bankName: "Guaranty Trust Bank",
    accountNumber: "0123456789",
    accountName: "John Smith",
    address: "123 Main Street, Lagos, Nigeria",
    referralCode: "JOHN123",
    referralLink: "https://locexcoin.com/register?ref=JOHN123",
  })

  // Mock active coins
  const activeCoins = [
    {
      id: "COIN-001",
      amount: 100000,
      plan: "7-Day Plan",
      purchaseDate: "Apr 15, 2025",
      maturityDate: "Apr 22, 2025",
      expectedProfit: 35000,
      progress: 71,
      daysLeft: 2,
      status: "active",
    },
    {
      id: "COIN-002",
      amount: 50000,
      plan: "14-Day Plan",
      purchaseDate: "Apr 10, 2025",
      maturityDate: "Apr 24, 2025",
      expectedProfit: 53500,
      progress: 36,
      daysLeft: 9,
      status: "active",
    },
    {
      id: "COIN-003",
      amount: 100000,
      plan: "21-Day Plan",
      purchaseDate: "Apr 5, 2025",
      maturityDate: "Apr 26, 2025",
      expectedProfit: 215000,
      progress: 24,
      daysLeft: 16,
      status: "active",
    },
  ]

  // Mock transactions
  const transactions = [
    {
      id: "TRX-001",
      type: "purchase",
      amount: 100000,
      status: "completed",
      date: "Apr 15, 2025",
      description: "Coin purchase",
      reference: "COIN-001",
    },
    {
      id: "TRX-002",
      type: "purchase",
      amount: 50000,
      status: "completed",
      date: "Apr 10, 2025",
      description: "Coin purchase",
      reference: "COIN-002",
    },
    {
      id: "TRX-003",
      type: "purchase",
      amount: 100000,
      status: "completed",
      date: "Apr 5, 2025",
      description: "Coin purchase",
      reference: "COIN-003",
    },
    {
      id: "TRX-004",
      type: "referral",
      amount: 1000,
      status: "completed",
      date: "Apr 3, 2025",
      description: "Referral bonus",
      reference: "REF-001",
    },
  ]

  // Mock referrals
  const referrals = [
    {
      id: 1,
      name: "Jane Doe",
      date: "Apr 10, 2025",
      status: "Active",
      commission: 1000,
    },
    {
      id: 2,
      name: "Mike Johnson",
      date: "Apr 8, 2025",
      status: "Active",
      commission: 1000,
    },
    {
      id: 3,
      name: "Sarah Williams",
      date: "Apr 5, 2025",
      status: "Active",
      commission: 1000,
    },
  ]

  const handleSuspendAccount = () => {
    toast({
      title: "Account Suspended",
      description: `${memberData.name}'s account has been suspended.`,
    })
    setMemberData({ ...memberData, status: "suspended" })
  }

  const handleActivateAccount = () => {
    toast({
      title: "Account Activated",
      description: `${memberData.name}'s account has been activated.`,
    })
    setMemberData({ ...memberData, status: "active" })
  }

  const handleSendEmail = () => {
    toast({
      title: "Email Sent",
      description: `An email has been sent to ${memberData.email}.`,
    })
  }

  const handleSendSMS = () => {
    toast({
      title: "SMS Sent",
      description: `An SMS has been sent to ${memberData.phone}.`,
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <Button variant="outline" size="icon" onClick={() => router.back()} className="mr-4">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Member Dashboard: {memberData.name}</h1>
            <p className="text-muted-foreground">Viewing member account as admin. All actions are logged.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleSendEmail}>
            <Mail className="h-4 w-4 mr-2" />
            Email Member
          </Button>
          <Button variant="outline" onClick={handleSendSMS}>
            <Phone className="h-4 w-4 mr-2" />
            SMS Member
          </Button>
          {memberData.status === "active" ? (
            <Button variant="destructive" onClick={handleSuspendAccount}>
              <Ban className="h-4 w-4 mr-2" />
              Suspend Account
            </Button>
          ) : (
            <Button className="bg-green-600 hover:bg-green-700" onClick={handleActivateAccount}>
              <CheckCircle className="h-4 w-4 mr-2" />
              Activate Account
            </Button>
          )}
        </div>
      </div>

      {/* Admin Notice */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-start">
          <Shield className="h-5 w-5 text-amber-600 mt-0.5 mr-2 flex-shrink-0" />
          <div>
            <h3 className="font-medium text-amber-800">Admin Access Mode</h3>
            <p className="text-sm text-amber-700 mt-1">
              You are viewing this member's dashboard in admin mode. All actions performed are logged. Please respect
              member privacy and only make changes when necessary.
            </p>
          </div>
        </div>
      </div>

      {/* Member Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Member Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center">
              <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <User className="h-12 w-12 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold">{memberData.name}</h2>
              <div className="flex items-center mt-1">
                <Badge
                  variant="outline"
                  className={
                    memberData.status === "active"
                      ? "bg-green-50 text-green-700 border-green-200"
                      : "bg-red-50 text-red-700 border-red-200"
                  }
                >
                  {memberData.status === "active" ? (
                    <CheckCircle className="h-3 w-3 mr-1" />
                  ) : (
                    <AlertTriangle className="h-3 w-3 mr-1" />
                  )}
                  {memberData.status.charAt(0).toUpperCase() + memberData.status.slice(1)}
                </Badge>
              </div>
              <p className="text-muted-foreground mt-1">Member since {memberData.joinDate}</p>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">{memberData.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Phone:</span>
                <span className="font-medium">{memberData.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Address:</span>
                <span className="font-medium">{memberData.address}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Referral Code:</span>
                <span className="font-medium">{memberData.referralCode}</span>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t">
              <h3 className="font-medium">Bank Information</h3>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bank:</span>
                  <span className="font-medium">{memberData.bankName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Account Number:</span>
                  <span className="font-medium">{memberData.accountNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Account Name:</span>
                  <span className="font-medium">{memberData.accountName}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="md:col-span-2">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="investments">Investments</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="referrals">Referrals</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Investments</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center">
                      <Coins className="h-4 w-4 text-blue-600 mr-2" />
                      <div className="text-2xl font-bold">{memberData.totalInvestments}</div>
                    </div>
                    <p className="text-xs text-muted-foreground">Active investments</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Value</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center">
                      <DollarSign className="h-4 w-4 text-green-600 mr-2" />
                      <div className="text-2xl font-bold text-green-600">₦{memberData.totalValue.toLocaleString()}</div>
                    </div>
                    <p className="text-xs text-muted-foreground">Current investment value</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Referrals</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 text-blue-600 mr-2" />
                      <div className="text-2xl font-bold">{memberData.referrals}</div>
                    </div>
                    <p className="text-xs text-muted-foreground">Total referrals</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Recent actions and transactions by this member</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {transactions.slice(0, 3).map((transaction) => (
                      <div key={transaction.id} className="flex justify-between items-center border-b pb-3">
                        <div className="flex items-center">
                          <div
                            className={`p-2 rounded-full mr-3 ${
                              transaction.type === "purchase"
                                ? "bg-blue-100"
                                : transaction.type === "referral"
                                  ? "bg-green-100"
                                  : "bg-gray-100"
                            }`}
                          >
                            {transaction.type === "purchase" ? (
                              <Coins className="h-4 w-4 text-blue-600" />
                            ) : transaction.type === "referral" ? (
                              <Users className="h-4 w-4 text-green-600" />
                            ) : (
                              <DollarSign className="h-4 w-4 text-gray-600" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium">{transaction.description}</p>
                            <p className="text-sm text-muted-foreground">{transaction.date}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p
                            className={`font-medium ${
                              transaction.type === "purchase" ? "text-red-600" : "text-green-600"
                            }`}
                          >
                            {transaction.type === "purchase" ? "-" : "+"}₦{transaction.amount.toLocaleString()}
                          </p>
                          <Badge
                            variant="outline"
                            className={
                              transaction.status === "completed"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : "bg-amber-50 text-amber-700 border-amber-200"
                            }
                          >
                            {transaction.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <a
                      href="#transactions"
                      onClick={() => document.querySelector('[data-value="transactions"]')?.click()}
                    >
                      View All Transactions
                    </a>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* Investments Tab */}
            <TabsContent value="investments" className="space-y-4">
              {activeCoins.map((coin) => (
                <Card key={coin.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center">
                          <Coins className="h-5 w-5 text-blue-600 mr-2" />
                          {coin.plan} - {coin.id}
                        </CardTitle>
                        <CardDescription>Purchased on {coin.purchaseDate}</CardDescription>
                      </div>
                      <Badge className="bg-blue-600">Active</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Investment Amount</p>
                        <p className="text-lg font-semibold">₦{coin.amount.toLocaleString()}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Expected Profit</p>
                        <p className="text-lg font-semibold text-green-600">₦{coin.expectedProfit.toLocaleString()}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Maturity Date</p>
                        <p className="text-lg font-semibold">{coin.maturityDate}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Total Return</p>
                        <p className="text-lg font-semibold text-green-600">
                          ₦{(coin.amount + coin.expectedProfit).toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 text-blue-600 mr-2" />
                          <span className="text-sm font-medium">{coin.daysLeft} days left until maturity</span>
                        </div>
                        <span className="text-sm font-medium">{coin.progress}%</span>
                      </div>
                      <Progress value={coin.progress} className="h-2" />
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 border-t px-6 py-3">
                    <Button variant="outline" className="ml-auto">
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </TabsContent>

            {/* Transactions Tab */}
            <TabsContent value="transactions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Transaction History</CardTitle>
                  <CardDescription>All transactions for this member</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <div className="grid grid-cols-5 gap-4 p-4 font-medium border-b">
                      <div>ID</div>
                      <div>Type</div>
                      <div>Description</div>
                      <div>Date</div>
                      <div>Amount</div>
                    </div>
                    <div className="divide-y">
                      {transactions.map((transaction) => (
                        <div key={transaction.id} className="grid grid-cols-5 gap-4 p-4">
                          <div className="font-mono text-xs">{transaction.id}</div>
                          <div>
                            <Badge
                              variant="outline"
                              className={
                                transaction.type === "purchase"
                                  ? "bg-blue-50 text-blue-700 border-blue-200"
                                  : "bg-green-50 text-green-700 border-green-200"
                              }
                            >
                              {transaction.type}
                            </Badge>
                          </div>
                          <div>{transaction.description}</div>
                          <div>{transaction.date}</div>
                          <div
                            className={`font-medium ${
                              transaction.type === "purchase" ? "text-red-600" : "text-green-600"
                            }`}
                          >
                            {transaction.type === "purchase" ? "-" : "+"}₦{transaction.amount.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Referrals Tab */}
            <TabsContent value="referrals" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Referrals</CardTitle>
                  <CardDescription>Members referred by this user</CardDescription>
                </CardHeader>
                <CardContent>
                  {referrals.length > 0 ? (
                    <div className="rounded-md border">
                      <div className="grid grid-cols-4 gap-4 p-4 font-medium border-b">
                        <div>Name</div>
                        <div>Date</div>
                        <div>Status</div>
                        <div>Commission</div>
                      </div>
                      <div className="divide-y">
                        {referrals.map((referral) => (
                          <div key={referral.id} className="grid grid-cols-4 gap-4 p-4">
                            <div>{referral.name}</div>
                            <div className="text-muted-foreground">{referral.date}</div>
                            <div>
                              <Badge className="bg-green-600">{referral.status}</Badge>
                            </div>
                            <div className="text-green-600 font-medium">₦{referral.commission.toLocaleString()}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-6 text-center">
                      <div className="rounded-full bg-blue-100 p-3 mb-4">
                        <Users className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-lg font-medium mb-2">No Referrals</h3>
                      <p className="text-muted-foreground mb-4">This member hasn't referred anyone yet</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
