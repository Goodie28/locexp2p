"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { CheckCircle, XCircle, Eye, Search } from "lucide-react"

// Mock data for withdrawal requests
const mockWithdrawalRequests = [
  {
    id: "WD-001",
    userId: "USER123",
    userName: "John Smith",
    email: "john@example.com",
    amount: 15000,
    requestDate: "2025-04-20T10:30:00",
    status: "pending",
    bankName: "Guaranty Trust Bank",
    accountNumber: "0123456789",
    accountName: "John Smith",
  },
  {
    id: "WD-002",
    userId: "USER456",
    userName: "Sarah Johnson",
    email: "sarah@example.com",
    amount: 25000,
    requestDate: "2025-04-19T14:45:00",
    status: "pending",
    bankName: "First Bank",
    accountNumber: "9876543210",
    accountName: "Sarah Johnson",
  },
  {
    id: "WD-003",
    userId: "USER789",
    userName: "Michael Brown",
    email: "michael@example.com",
    amount: 10000,
    requestDate: "2025-04-18T09:15:00",
    status: "approved",
    bankName: "Access Bank",
    accountNumber: "5678901234",
    accountName: "Michael Brown",
    approvedDate: "2025-04-18T11:30:00",
    auctionId: "AUC-123",
  },
  {
    id: "WD-004",
    userId: "USER321",
    userName: "Emily Wilson",
    email: "emily@example.com",
    amount: 50000,
    requestDate: "2025-04-17T16:20:00",
    status: "completed",
    bankName: "Zenith Bank",
    accountNumber: "1357924680",
    accountName: "Emily Wilson",
    approvedDate: "2025-04-17T18:45:00",
    auctionId: "AUC-120",
    completedDate: "2025-04-18T14:30:00",
  },
  {
    id: "WD-005",
    userId: "USER654",
    userName: "David Lee",
    email: "david@example.com",
    amount: 12000,
    requestDate: "2025-04-16T11:10:00",
    status: "rejected",
    bankName: "United Bank for Africa",
    accountNumber: "2468013579",
    accountName: "David Lee",
    rejectedDate: "2025-04-16T13:25:00",
    rejectionReason: "Insufficient referral balance",
  },
]

export default function ReferralWithdrawalsPage() {
  const { toast } = useToast()
  const [withdrawalRequests, setWithdrawalRequests] = useState(mockWithdrawalRequests)
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [auctionDetails, setAuctionDetails] = useState({
    auctionId: "",
    startDate: "",
    endDate: "",
  })
  const [rejectionReason, setRejectionReason] = useState("")
  const [isApproving, setIsApproving] = useState(false)
  const [isRejecting, setIsRejecting] = useState(false)
  const [activeTab, setActiveTab] = useState("pending")

  // Filter requests based on search query and active tab
  const filteredRequests = withdrawalRequests.filter((request) => {
    const matchesSearch =
      request.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.id.toLowerCase().includes(searchQuery.toLowerCase())

    if (activeTab === "all") return matchesSearch
    return matchesSearch && request.status === activeTab
  })

  const handleApprove = (requestId) => {
    setIsApproving(true)

    // Simulate API call
    setTimeout(() => {
      // Generate a random auction ID
      const auctionId = `AUC-${Math.floor(Math.random() * 1000)}`

      // Update the request status
      const updatedRequests = withdrawalRequests.map((request) => {
        if (request.id === requestId) {
          return {
            ...request,
            status: "approved",
            approvedDate: new Date().toISOString(),
            auctionId,
          }
        }
        return request
      })

      setWithdrawalRequests(updatedRequests)
      setIsApproving(false)
      setSelectedRequest(null)

      toast({
        title: "Withdrawal Approved",
        description: `Withdrawal request ${requestId} has been approved and sent for auction.`,
      })
    }, 1500)
  }

  const handleReject = (requestId) => {
    if (!rejectionReason) {
      toast({
        title: "Rejection Reason Required",
        description: "Please provide a reason for rejecting this withdrawal request.",
        variant: "destructive",
      })
      return
    }

    setIsRejecting(true)

    // Simulate API call
    setTimeout(() => {
      // Update the request status
      const updatedRequests = withdrawalRequests.map((request) => {
        if (request.id === requestId) {
          return {
            ...request,
            status: "rejected",
            rejectedDate: new Date().toISOString(),
            rejectionReason,
          }
        }
        return request
      })

      setWithdrawalRequests(updatedRequests)
      setIsRejecting(false)
      setSelectedRequest(null)
      setRejectionReason("")

      toast({
        title: "Withdrawal Rejected",
        description: `Withdrawal request ${requestId} has been rejected.`,
      })
    }, 1500)
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Pending
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Approved
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Completed
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Rejected
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleString("en-NG", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Referral Withdrawals</h1>
        <p className="text-muted-foreground">Manage and approve referral withdrawal requests</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search withdrawals..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Tabs defaultValue="pending" className="w-full md:w-auto" onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="approved">Approved</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="rejected">Rejected</TabsTrigger>
            <TabsTrigger value="all">All</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Withdrawal Requests</CardTitle>
          <CardDescription>
            {filteredRequests.length} {filteredRequests.length === 1 ? "request" : "requests"} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Request Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRequests.length > 0 ? (
                filteredRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-medium">{request.id}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{request.userName}</div>
                        <div className="text-sm text-muted-foreground">{request.email}</div>
                      </div>
                    </TableCell>
                    <TableCell>₦{request.amount.toLocaleString()}</TableCell>
                    <TableCell>{formatDate(request.requestDate)}</TableCell>
                    <TableCell>{getStatusBadge(request.status)}</TableCell>
                    <TableCell className="text-right">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => setSelectedRequest(request)}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">View details</span>
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-md">
                          <DialogHeader>
                            <DialogTitle>Withdrawal Request Details</DialogTitle>
                            <DialogDescription>Request ID: {selectedRequest?.id}</DialogDescription>
                          </DialogHeader>
                          {selectedRequest && (
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <h4 className="text-sm font-medium">User Information</h4>
                                  <div className="text-sm mt-1">
                                    <p>
                                      <span className="text-muted-foreground">Name:</span> {selectedRequest.userName}
                                    </p>
                                    <p>
                                      <span className="text-muted-foreground">Email:</span> {selectedRequest.email}
                                    </p>
                                    <p>
                                      <span className="text-muted-foreground">User ID:</span> {selectedRequest.userId}
                                    </p>
                                  </div>
                                </div>
                                <div>
                                  <h4 className="text-sm font-medium">Bank Details</h4>
                                  <div className="text-sm mt-1">
                                    <p>
                                      <span className="text-muted-foreground">Bank:</span> {selectedRequest.bankName}
                                    </p>
                                    <p>
                                      <span className="text-muted-foreground">Account:</span>{" "}
                                      {selectedRequest.accountNumber}
                                    </p>
                                    <p>
                                      <span className="text-muted-foreground">Name:</span> {selectedRequest.accountName}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              <div>
                                <h4 className="text-sm font-medium">Withdrawal Information</h4>
                                <div className="text-sm mt-1">
                                  <p>
                                    <span className="text-muted-foreground">Amount:</span> ₦
                                    {selectedRequest.amount.toLocaleString()}
                                  </p>
                                  <p>
                                    <span className="text-muted-foreground">Type:</span>{" "}
                                    {selectedRequest.withdrawalType || "All Earnings"}
                                  </p>
                                  <p>
                                    <span className="text-muted-foreground">Request Date:</span>{" "}
                                    {formatDate(selectedRequest.requestDate)}
                                  </p>
                                  <p>
                                    <span className="text-muted-foreground">Status:</span>{" "}
                                    {getStatusBadge(selectedRequest.status)}
                                  </p>

                                  {selectedRequest.approvedDate && (
                                    <p>
                                      <span className="text-muted-foreground">Approved Date:</span>{" "}
                                      {formatDate(selectedRequest.approvedDate)}
                                    </p>
                                  )}

                                  {selectedRequest.auctionId && (
                                    <p>
                                      <span className="text-muted-foreground">Auction ID:</span>{" "}
                                      {selectedRequest.auctionId}
                                    </p>
                                  )}

                                  {selectedRequest.completedDate && (
                                    <p>
                                      <span className="text-muted-foreground">Completed Date:</span>{" "}
                                      {formatDate(selectedRequest.completedDate)}
                                    </p>
                                  )}

                                  {selectedRequest.rejectedDate && (
                                    <>
                                      <p>
                                        <span className="text-muted-foreground">Rejected Date:</span>{" "}
                                        {formatDate(selectedRequest.rejectedDate)}
                                      </p>
                                      <p>
                                        <span className="text-muted-foreground">Rejection Reason:</span>{" "}
                                        {selectedRequest.rejectionReason}
                                      </p>
                                    </>
                                  )}
                                </div>
                              </div>

                              {selectedRequest.status === "pending" && (
                                <div className="space-y-4 pt-4 border-t">
                                  <div className="flex justify-between">
                                    <Button
                                      onClick={() => handleApprove(selectedRequest.id)}
                                      className="bg-green-600 hover:bg-green-700"
                                      disabled={isApproving}
                                    >
                                      <CheckCircle className="mr-2 h-4 w-4" />
                                      {isApproving ? "Approving..." : "Approve & Auction"}
                                    </Button>

                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button variant="destructive">
                                          <XCircle className="mr-2 h-4 w-4" />
                                          Reject
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent className="sm:max-w-md">
                                        <DialogHeader>
                                          <DialogTitle>Reject Withdrawal Request</DialogTitle>
                                          <DialogDescription>
                                            Please provide a reason for rejecting this withdrawal request.
                                          </DialogDescription>
                                        </DialogHeader>
                                        <div className="space-y-4 py-4">
                                          <div className="space-y-2">
                                            <Label htmlFor="rejection-reason">Rejection Reason</Label>
                                            <Input
                                              id="rejection-reason"
                                              placeholder="Enter reason for rejection"
                                              value={rejectionReason}
                                              onChange={(e) => setRejectionReason(e.target.value)}
                                            />
                                          </div>
                                        </div>
                                        <DialogFooter>
                                          <Button
                                            variant="destructive"
                                            onClick={() => handleReject(selectedRequest.id)}
                                            disabled={isRejecting}
                                          >
                                            {isRejecting ? "Rejecting..." : "Confirm Rejection"}
                                          </Button>
                                        </DialogFooter>
                                      </DialogContent>
                                    </Dialog>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-6">
                    <div className="flex flex-col items-center justify-center text-muted-foreground">
                      <Search className="h-8 w-8 mb-2" />
                      <p>No withdrawal requests found</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
