import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, Coins, Users, TrendingUp, Clock, AlertTriangle, CheckCircle2 } from "lucide-react"
import Link from "next/link"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function HowItWorksPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <section className="py-12 md:py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-3xl md:text-5xl font-bold mb-4">How LOCEXCOIN Works</h1>
              <p className="text-lg md:text-xl opacity-90">
                Learn how our P2P auction platform helps you earn guaranteed profits
              </p>
            </div>
          </div>
        </section>

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900">Simple 3-Step Process</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                LOCEXCOIN makes investing easy and profitable
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="bg-blue-50 border-blue-100">
                <CardHeader className="text-center pb-2">
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">1. Sign Up</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600">
                    Create your free account and complete your profile with your bank details for seamless transactions.
                  </p>
                  <Button asChild className="mt-4">
                    <Link href="/register">
                      Register Now <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-blue-50 border-blue-100">
                <CardHeader className="text-center pb-2">
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                    <Coins className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">2. Buy Coins</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600">
                    Participate in our daily auctions to buy coins. Invest from ₦10,000 up to ₦1,000,000 per auction.
                  </p>
                  <Button asChild className="mt-4" variant="outline">
                    <Link href="/plans">View Plans</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-blue-50 border-blue-100">
                <CardHeader className="text-center pb-2">
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">3. Earn Profits</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600">
                    Hold your coins for the selected duration and sell them with guaranteed profits of up to 215%.
                  </p>
                  <Button asChild className="mt-4" variant="outline">
                    <Link href="/login">Login to Start</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4 md:px-6">
            <Tabs defaultValue="auction" className="w-full">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Detailed Process</h2>
                <TabsList className="inline-flex">
                  <TabsTrigger value="auction">Auction Process</TabsTrigger>
                  <TabsTrigger value="investment">Investment Plans</TabsTrigger>
                  <TabsTrigger value="rules">Platform Rules</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="auction" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>How Auctions Work</CardTitle>
                    <CardDescription>
                      Our unique auction system connects buyers and sellers in a secure environment
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium flex items-center">
                          <Clock className="h-5 w-5 text-blue-600 mr-2" />
                          Auction Schedule
                        </h3>
                        <ul className="space-y-2 pl-7 list-disc text-gray-600">
                          <li>Auctions open twice daily from Monday to Saturday at 9:00 AM and 6:30 PM (WAT)</li>
                          <li>Auctions open once on Sunday at 6:30 PM (WAT) only</li>
                          <li>Each auction session lasts for 5 minutes only</li>
                          <li>First come, first served basis for matching buyers and sellers</li>
                        </ul>
                      </div>

                      <div className="space-y-4">
                        <h3 className="text-lg font-medium flex items-center">
                          <Coins className="h-5 w-5 text-blue-600 mr-2" />
                          Buying Process
                        </h3>
                        <ul className="space-y-2 pl-7 list-disc text-gray-600">
                          <li>Join the auction during the scheduled times</li>
                          <li>Select your preferred investment plan (7, 14, or 21 days)</li>
                          <li>Enter your investment amount (₦10,000 - ₦1,000,000)</li>
                          <li>Get matched with a seller instantly</li>
                          <li>Make payment to the seller&apos;s bank account within 7 hours</li>
                          <li>Upload proof of payment</li>
                          <li>Receive confirmation once payment is verified</li>
                        </ul>
                      </div>
                    </div>

                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                      <div className="flex items-start">
                        <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium text-amber-800">Important Note</h3>
                          <p className="text-sm text-amber-700 mt-1">
                            Members must make 100% recurring/recommitment bids on each coin bought before they can
                            withdraw and sell. This ensures platform sustainability and continuous profit for all
                            members.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="investment" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="overflow-hidden">
                    <div className="bg-blue-600 p-4 text-white text-center">
                      <h3 className="text-xl font-bold">7 Days Plan</h3>
                    </div>
                    <CardContent className="pt-6">
                      <div className="text-center mb-6">
                        <p className="text-4xl font-bold text-blue-600">35%</p>
                        <p className="text-gray-600 mt-1">Profit on Investment</p>
                      </div>
                      <ul className="space-y-3">
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Minimum: ₦10,000</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Maximum: ₦1,000,000</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Duration: 7 Days</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Instant Matching</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="overflow-hidden">
                    <div className="bg-orange p-4 text-white text-center">
                      <h3 className="text-xl font-bold">14 Days Plan</h3>
                    </div>
                    <CardContent className="pt-6">
                      <div className="text-center mb-6">
                        <p className="text-4xl font-bold text-orange">107%</p>
                        <p className="text-gray-600 mt-1">Profit on Investment</p>
                      </div>
                      <ul className="space-y-3">
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Minimum: ₦10,000</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Maximum: ₦1,000,000</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Duration: 14 Days</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Instant Matching</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="overflow-hidden">
                    <div className="bg-blue-600 p-4 text-white text-center">
                      <h3 className="text-xl font-bold">21 Days Plan</h3>
                    </div>
                    <CardContent className="pt-6">
                      <div className="text-center mb-6">
                        <p className="text-4xl font-bold text-blue-600">215%</p>
                        <p className="text-gray-600 mt-1">Profit on Investment</p>
                      </div>
                      <ul className="space-y-3">
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Minimum: ₦10,000</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Maximum: ₦1,000,000</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Duration: 21 Days</span>
                        </li>
                        <li className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                          <span>Instant Matching</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="rules" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Rules</CardTitle>
                    <CardDescription>
                      Important guidelines to ensure a fair and profitable experience for all members
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">General Rules</h3>
                      <ul className="space-y-2 pl-7 list-disc text-gray-600">
                        <li>Minimum investment amount is ₦10,000 and maximum is ₦1,000,000 per auction</li>
                        <li>Buyers must make payment within 7 hours of matching or face a 2% penalty</li>
                        <li>
                          Members must make 100% recurring/recommitment bids on each coin bought before they can
                          withdraw and sell
                        </li>
                        <li>All transactions are final and non-reversible</li>
                        <li>
                          Multiple accounts are allowed, and members can use one WhatsApp number for two accounts only
                        </li>
                        <li>Referral commissions are paid only on the first investment of referred members</li>
                      </ul>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Payment Rules</h3>
                      <ul className="space-y-2 pl-7 list-disc text-gray-600">
                        <li>All payments must be made via bank transfer to the provided account details</li>
                        <li>Payment proof must be uploaded within the specified timeframe</li>
                        <li>Sellers must confirm receipt of payment within 24 hours</li>
                        <li>Minimum withdrawal amount for referral earnings is ₦10,000</li>
                        <li>Withdrawal requests are processed within 24-48 hours</li>
                      </ul>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-start">
                        <AlertTriangle className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium text-blue-800">Compliance Notice</h3>
                          <p className="text-sm text-blue-700 mt-1">
                            LOCEXCOIN operates as a peer-to-peer platform connecting buyers and sellers. We are not a
                            financial institution and do not hold or manage user funds. All transactions occur directly
                            between members.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <section className="py-12 bg-blue-600 text-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold mb-4">Ready to Start?</h2>
              <p className="text-xl opacity-90 mb-8">Join LOCEXCOIN today and start your journey to financial growth</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-white/90">
                  <Link href="/register">Sign Up Free</Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="bg-transparent text-white border-white hover:bg-white/10"
                >
                  <Link href="/login">Login</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
