import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Users, Percent, Gift, Award, CheckCircle, HelpCircle } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function ReferralsPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Referral Program</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Earn additional income by referring friends and family to LOCEXCOIN
        </p>
      </div>

      {/* Main Referral Info */}
      <div className="grid gap-8 md:grid-cols-2 max-w-5xl mx-auto">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Percent className="mr-2 h-6 w-6 text-blue-600" />
              Commission Structure
            </CardTitle>
            <CardDescription>Earn generous commissions on every referral</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Users className="h-8 w-8 text-blue-600 mr-3" />
                  <div>
                    <h3 className="font-medium">One-Time Commission</h3>
                    <p className="text-sm text-muted-foreground">On first investment by referrals</p>
                  </div>
                </div>
                <div className="text-2xl font-bold text-blue-600">10%</div>
              </div>
              <p className="text-sm text-muted-foreground">
                You earn a one-time 10% commission on the first investment made by users you directly refer to the
                platform. This commission is added to your referral bonuses and can be withdrawn after admin approval.
              </p>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Gift className="h-8 w-8 text-green-600 mr-3" />
                  <div>
                    <h3 className="font-medium">First Sign up Bonus</h3>
                    <p className="text-sm text-muted-foreground">Special bonus for new users</p>
                  </div>
                </div>
                <div className="text-2xl font-bold text-green-600">₦1,000</div>
              </div>
              <p className="text-sm text-muted-foreground">
                Receive ₦1,000 bonus when someone uses your referral link to sign up for the first time. This bonus is
                added to your referral earnings.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Award className="mr-2 h-6 w-6 text-orange" />
              Weekly Bonus Tiers
            </CardTitle>
            <CardDescription>Earn extra bonuses based on your weekly referral count</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center p-4 border rounded-lg">
                <div className="bg-blue-100 p-2 rounded-full mr-4">
                  <span className="text-blue-700 font-medium">25</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">25 Weekly Referrals</h3>
                  <p className="text-sm text-muted-foreground">Starter tier bonus</p>
                </div>
                <div className="text-lg font-bold text-blue-600">₦10,000</div>
              </div>

              <div className="flex items-center p-4 border rounded-lg">
                <div className="bg-blue-100 p-2 rounded-full mr-4">
                  <span className="text-blue-700 font-medium">50</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">50 Weekly Referrals</h3>
                  <p className="text-sm text-muted-foreground">Intermediate tier bonus</p>
                </div>
                <div className="text-lg font-bold text-blue-600">₦25,000</div>
              </div>

              <div className="flex items-center p-4 border rounded-lg">
                <div className="bg-blue-100 p-2 rounded-full mr-4">
                  <span className="text-blue-700 font-medium">100</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">100 Weekly Referrals</h3>
                  <p className="text-sm text-muted-foreground">Advanced tier bonus</p>
                </div>
                <div className="text-lg font-bold text-blue-600">₦50,000</div>
              </div>

              <div className="flex items-center p-4 border rounded-lg">
                <div className="bg-blue-100 p-2 rounded-full mr-4">
                  <span className="text-blue-700 font-medium">200</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">200 Weekly Referrals</h3>
                  <p className="text-sm text-muted-foreground">Elite tier bonus</p>
                </div>
                <div className="text-lg font-bold text-blue-600">₦100,000</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* How to Refer Section */}
      <div className="mt-16 max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-center mb-8">How to Refer Others</h2>

        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center mb-2">
                <span className="text-blue-700 font-medium">1</span>
              </div>
              <CardTitle className="text-lg">Register & Login</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Create your account and log in to access your unique referral link in your dashboard.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center mb-2">
                <span className="text-blue-700 font-medium">2</span>
              </div>
              <CardTitle className="text-lg">Share Your Link</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Share your referral link with friends, family, and on social media platforms.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center mb-2">
                <span className="text-blue-700 font-medium">3</span>
              </div>
              <CardTitle className="text-lg">Earn Commissions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Earn 10% commission when your referrals invest, plus weekly bonuses based on your performance.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Withdrawal Information */}
      <div className="mt-16 max-w-4xl mx-auto">
        <Card className="border-2 border-blue-100">
          <CardHeader>
            <CardTitle className="flex items-center">
              <CheckCircle className="mr-2 h-6 w-6 text-green-600" />
              Referral Earnings Withdrawal
            </CardTitle>
            <CardDescription>How to withdraw your referral commissions and bonuses</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-medium mb-2">Withdrawal Process:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Minimum withdrawal amount: ₦10,000</li>
                <li>Withdrawal requests are sent to admin for approval</li>
                <li>Approved withdrawals are auctioned in the market</li>
                <li>Payment is sent to your registered bank account after auction</li>
              </ul>
            </div>

            <p className="text-sm text-muted-foreground">
              All your referral earnings are combined into a single balance that you can withdraw once it reaches the
              minimum threshold. When you request a withdrawal, the admin will review and approve it, then your funds
              will be auctioned in the market before the payment is sent to you.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* FAQ Section */}
      <div className="mt-16 max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>

        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger className="text-left">
              <div className="flex items-center">
                <HelpCircle className="mr-2 h-5 w-5 text-blue-600" />
                How do I find my referral link?
              </div>
            </AccordionTrigger>
            <AccordionContent>
              Your unique referral link is available in your dashboard under the "Referrals" section. You can copy it
              directly or use the share buttons to share it via social media or messaging apps.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-2">
            <AccordionTrigger className="text-left">
              <div className="flex items-center">
                <HelpCircle className="mr-2 h-5 w-5 text-blue-600" />
                When do I receive my referral commission?
              </div>
            </AccordionTrigger>
            <AccordionContent>
              You receive your 10% referral commission immediately after your referral's payment is verified. The
              commission is automatically credited to your referral earnings balance.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-3">
            <AccordionTrigger className="text-left">
              <div className="flex items-center">
                <HelpCircle className="mr-2 h-5 w-5 text-blue-600" />
                How are weekly bonuses calculated?
              </div>
            </AccordionTrigger>
            <AccordionContent>
              Weekly bonuses are calculated based on the number of new referrals you bring in during a calendar week
              (Monday to Sunday). The system automatically counts your referrals and awards the appropriate bonus tier
              at the end of each week.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-4">
            <AccordionTrigger className="text-left">
              <div className="flex items-center">
                <HelpCircle className="mr-2 h-5 w-5 text-blue-600" />
                How does the withdrawal process work?
              </div>
            </AccordionTrigger>
            <AccordionContent>
              When you request a withdrawal, your request is sent to the admin for approval. Once approved, your funds
              will be auctioned in the market, and after the auction completes, the payment will be sent to your
              registered bank account. This process typically takes 1-3 business days.
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-5">
            <AccordionTrigger className="text-left">
              <div className="flex items-center">
                <HelpCircle className="mr-2 h-5 w-5 text-blue-600" />
                Is there a limit to how many people I can refer?
              </div>
            </AccordionTrigger>
            <AccordionContent>
              No, there is no limit to the number of people you can refer. The more people you refer, the more
              commission you earn. Additionally, referring more people increases your chances of reaching higher weekly
              bonus tiers.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      {/* Call to Action */}
      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Start Earning Referral Commissions Today</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Join LOCEXCOIN now and start earning additional income through our generous referral program.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/register">
              Create Account
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/login">Login to Your Account</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
