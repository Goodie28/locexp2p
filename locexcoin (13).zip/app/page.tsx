"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Coins, Users, TrendingUp } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function Home() {
  const [countdown, setCountdown] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0,
  })
  const [isAuctionLive, setIsAuctionLive] = useState(false)

  // Function to check if auction is live based on West Central Africa Time (UTC+01:00)
  const checkIfAuctionIsLive = () => {
    // Get current time in West Central Africa Time (UTC+01:00)
    const now = new Date()
    const options = { timeZone: "Africa/Lagos" }
    const wcatTime = new Date(now.toLocaleString("en-US", options))

    const hours = wcatTime.getHours()
    const minutes = wcatTime.getMinutes()
    const day = wcatTime.getDay() // 0 is Sunday, 1 is Monday, etc.

    // Auction times: 9:00 AM and 6:30 PM on weekdays, 6:30 PM on Sunday
    const isWeekday = day >= 1 && day <= 6 // Monday to Saturday
    const isSunday = day === 0

    // Check if current time matches auction times
    const isMorningAuction = isWeekday && hours === 9 && minutes >= 0 && minutes < 30
    const isEveningAuction = (isWeekday || isSunday) && hours === 18 && minutes >= 30 && minutes < 59

    return isMorningAuction || isEveningAuction
  }

  // Function to calculate time until next auction
  const calculateTimeUntilNextAuction = () => {
    // Get current time in West Central Africa Time (UTC+01:00)
    const now = new Date()
    const options = { timeZone: "Africa/Lagos" }
    const wcatTime = new Date(now.toLocaleString("en-US", options))

    const hours = wcatTime.getHours()
    const minutes = wcatTime.getMinutes()
    const day = wcatTime.getDay() // 0 is Sunday, 1 is Monday, etc.

    const nextAuctionTime = new Date(wcatTime)

    // Set next auction time based on current time
    if (day === 0) {
      // Sunday
      if (hours < 18 || (hours === 18 && minutes < 30)) {
        // Next auction is today at 6:30 PM
        nextAuctionTime.setHours(18, 30, 0, 0)
      } else {
        // Next auction is Monday at 9:00 AM
        nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
        nextAuctionTime.setHours(9, 0, 0, 0)
      }
    } else if (day >= 1 && day <= 5) {
      // Monday to Friday
      if (hours < 9) {
        // Next auction is today at 9:00 AM
        nextAuctionTime.setHours(9, 0, 0, 0)
      } else if ((hours === 9 && minutes >= 30) || hours > 9) {
        if (hours < 18 || (hours === 18 && minutes < 30)) {
          // Next auction is today at 6:30 PM
          nextAuctionTime.setHours(18, 30, 0, 0)
        } else {
          // Next auction is tomorrow at 9:00 AM
          nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
          nextAuctionTime.setHours(9, 0, 0, 0)
        }
      }
    } else if (day === 6) {
      // Saturday
      if (hours < 9) {
        // Next auction is today at 9:00 AM
        nextAuctionTime.setHours(9, 0, 0, 0)
      } else if ((hours === 9 && minutes >= 30) || hours > 9) {
        if (hours < 18 || (hours === 18 && minutes < 30)) {
          // Next auction is today at 6:30 PM
          nextAuctionTime.setHours(18, 30, 0, 0)
        } else {
          // Next auction is Sunday at 6:30 PM
          nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
          nextAuctionTime.setHours(18, 30, 0, 0)
        }
      }
    }

    // Calculate time difference in milliseconds
    const timeDiff = nextAuctionTime.getTime() - wcatTime.getTime()

    // Convert to hours, minutes, seconds
    const hoursUntil = Math.floor(timeDiff / (1000 * 60 * 60))
    const minutesUntil = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60))
    const secondsUntil = Math.floor((timeDiff % (1000 * 60)) / 1000)

    return {
      hours: hoursUntil,
      minutes: minutesUntil,
      seconds: secondsUntil,
    }
  }

  // Simulate countdown timer
  useEffect(() => {
    // Check if auction is currently live
    const auctionLiveStatus = checkIfAuctionIsLive()
    setIsAuctionLive(auctionLiveStatus)

    // If auction is not live, start countdown to next auction
    if (!auctionLiveStatus) {
      const timeUntilNextAuction = calculateTimeUntilNextAuction()
      setCountdown(timeUntilNextAuction)
    }

    const interval = setInterval(() => {
      // Check if auction is live
      const auctionLiveStatus = checkIfAuctionIsLive()

      // If auction status changed from live to not live, immediately start the next countdown
      if (isAuctionLive && !auctionLiveStatus) {
        const timeUntilNextAuction = calculateTimeUntilNextAuction()
        setCountdown(timeUntilNextAuction)
      }

      setIsAuctionLive(auctionLiveStatus)

      // If auction is not live, update countdown to next auction
      if (!auctionLiveStatus) {
        setCountdown((prev) => {
          if (prev.seconds > 0) {
            return { ...prev, seconds: prev.seconds - 1 }
          } else if (prev.minutes > 0) {
            return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
          } else if (prev.hours > 0) {
            return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
          } else {
            // Time's up, check if auction is now live
            const isNowLive = checkIfAuctionIsLive()
            if (isNowLive) {
              setIsAuctionLive(true)
              return prev
            } else {
              // Recalculate time until next auction
              return calculateTimeUntilNextAuction()
            }
          }
        })
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [isAuctionLive])

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-6xl font-bold">LOCEXCOIN P2P Auction Platform</h1>
                <p className="text-xl md:text-2xl">
                  Buy and sell coins with guaranteed profits through our secure auction platform
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild size="lg" className="bg-orange hover:bg-orange/90">
                    <Link href="/register">
                      Sign Up Free <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button
                    asChild
                    size="lg"
                    variant="outline"
                    className="bg-white/10 text-white border-white hover:bg-white/20"
                  >
                    <Link href="/login">Login</Link>
                  </Button>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="relative">
                  <div className="absolute -top-6 -left-6 w-72 h-72 bg-orange/20 rounded-full filter blur-xl"></div>
                  <div className="relative bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20">
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Coins className="h-10 w-10 text-orange" />
                          <div className="ml-4">
                            <p className="text-sm opacity-70">Current Auction</p>
                            <p className="text-xl font-bold">₦10,000 - ₦1,000,000</p>
                          </div>
                        </div>
                        <div
                          className={`px-3 py-1 rounded-full text-sm font-medium ${isAuctionLive ? "bg-green-500/20 text-green-500" : "bg-amber-500/20 text-amber-500"}`}
                        >
                          {isAuctionLive ? "Live" : "Next"}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm opacity-70">Next Auction</p>
                        <div className="grid grid-cols-4 gap-2">
                          <div className="bg-white/10 rounded-md p-2 text-center">
                            <p className="text-xl font-bold">{String(countdown.hours).padStart(2, "0")}</p>
                            <p className="text-xs">Hours</p>
                          </div>
                          <div className="bg-white/10 rounded-md p-2 text-center">
                            <p className="text-xl font-bold">{String(countdown.minutes).padStart(2, "0")}</p>
                            <p className="text-xs">Minutes</p>
                          </div>
                          <div className="bg-white/10 rounded-md p-2 text-center">
                            <p className="text-xl font-bold">{String(countdown.seconds).padStart(2, "0")}</p>
                            <p className="text-xs">Seconds</p>
                          </div>
                          <div className="bg-orange/20 rounded-md p-2 text-center">
                            <p className="text-xl font-bold text-orange">35%</p>
                            <p className="text-xs">Profit</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900">How It Works</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                Simple steps to start earning profits with LOCEXCOIN
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-blue-50 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">1. Sign Up Free</h3>
                <p className="text-gray-600">Create your account and complete your profile with your bank details</p>
              </div>
              <div className="bg-blue-50 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <Coins className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">2. Buy Coins</h3>
                <p className="text-gray-600">Participate in auctions and buy coins from ₦10,000 to ₦1,000,000</p>
              </div>
              <div className="bg-blue-50 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">3. Earn Profits</h3>
                <p className="text-gray-600">Hold your coins for 7, 14, or 21 days and sell with guaranteed profits</p>
              </div>
            </div>
          </div>
        </section>

        {/* Investment Plans */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900">Investment Plans</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">Choose the plan that works best for you</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-xl shadow-md overflow-hidden border border-blue-100 transition-transform hover:scale-105">
                <div className="p-6 bg-blue-600 text-white text-center">
                  <h3 className="text-2xl font-bold">7 Days Plan</h3>
                </div>
                <div className="p-6">
                  <div className="text-center mb-6">
                    <p className="text-5xl font-bold text-blue-600">35%</p>
                    <p className="text-gray-600 mt-2">Profit on Investment</p>
                  </div>
                  <ul className="space-y-3">
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Minimum: ₦10,000
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Maximum: ₦1,000,000
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Duration: 7 Days
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Instant Matching
                    </li>
                  </ul>
                </div>
                <div className="p-6 border-t border-gray-200">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Select Plan</Button>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-md overflow-hidden border border-orange-100 transition-transform hover:scale-105">
                <div className="p-6 bg-orange text-white text-center">
                  <h3 className="text-2xl font-bold">14 Days Plan</h3>
                </div>
                <div className="p-6">
                  <div className="text-center mb-6">
                    <p className="text-5xl font-bold text-orange">107%</p>
                    <p className="text-gray-600 mt-2">Profit on Investment</p>
                  </div>
                  <ul className="space-y-3">
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Minimum: ₦10,000
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Maximum: ₦1,000,000
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Duration: 14 Days
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Instant Matching
                    </li>
                  </ul>
                </div>
                <div className="p-6 border-t border-gray-200">
                  <Button className="w-full bg-orange hover:bg-orange/90">Select Plan</Button>
                </div>
              </div>
              <div className="bg-white rounded-xl shadow-md overflow-hidden border border-blue-100 transition-transform hover:scale-105">
                <div className="p-6 bg-blue-600 text-white text-center">
                  <h3 className="text-2xl font-bold">21 Days Plan</h3>
                </div>
                <div className="p-6">
                  <div className="text-center mb-6">
                    <p className="text-5xl font-bold text-blue-600">215%</p>
                    <p className="text-gray-600 mt-2">Profit on Investment</p>
                  </div>
                  <ul className="space-y-3">
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Minimum: ₦10,000
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Maximum: ₦1,000,000
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Duration: 21 Days
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="h-5 w-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Instant Matching
                    </li>
                  </ul>
                </div>
                <div className="p-6 border-t border-gray-200">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Select Plan</Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Referral Program */}
        <section className="py-16 bg-gradient-to-r from-orange to-orange-600 text-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold">Referral Program</h2>
              <p className="mt-4 text-lg max-w-2xl mx-auto">
                Earn bonuses by referring friends and family to LOCEXCOIN
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4">Referral Bonuses</h3>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <svg
                      className="h-5 w-5 text-white mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    ₦1,000 for each referral signup
                  </li>
                  <li className="flex items-center">
                    <svg
                      className="h-5 w-5 text-white mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    10% commission on first deposit
                  </li>
                  <li className="flex items-center">
                    <svg
                      className="h-5 w-5 text-white mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    Minimum withdrawal: ₦10,000
                  </li>
                </ul>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4">Weekly Bonuses</h3>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <svg
                      className="h-5 w-5 text-white mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    200 referrals: ₦100,000 bonus
                  </li>
                  <li className="flex items-center">
                    <svg
                      className="h-5 w-5 text-white mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    100 referrals: ₦50,000 bonus
                  </li>
                  <li className="flex items-center">
                    <svg
                      className="h-5 w-5 text-white mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    50 referrals: ₦25,000 bonus
                  </li>
                  <li className="flex items-center">
                    <svg
                      className="h-5 w-5 text-white mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    25 referrals: ₦10,000 bonus
                  </li>
                </ul>
              </div>
            </div>
            <div className="mt-8 text-center">
              <Button asChild size="lg" className="bg-white text-orange hover:bg-white/90">
                <Link href="/register">Start Referring Now</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="bg-blue-600 rounded-xl p-8 md:p-12 text-white text-center">
              <h2 className="text-3xl font-bold mb-4">Ready to Start Earning?</h2>
              <p className="text-xl mb-8 max-w-2xl mx-auto">
                Join LOCEXCOIN today and start your journey to financial growth
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="bg-orange hover:bg-orange/90">
                  <Link href="/register">Sign Up Free</Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="bg-white/10 text-white border-white hover:bg-white/20"
                >
                  <Link href="/login">Login</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
