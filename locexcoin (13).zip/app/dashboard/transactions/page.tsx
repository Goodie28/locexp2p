"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  ArrowUpRight,
  ArrowDownLeft,
  Search,
  Filter,
  Calendar,
  Download,
  Eye,
  Users,
  Coins,
  AlertCircle,
  CheckCircle,
  XCircle,
} from "lucide-react"
import { format } from "date-fns"

// Transaction type definition
interface Transaction {
  id: string
  type: "purchase" | "sale" | "referral" | "bonus" | "withdrawal"
  amount: number
  status: "completed" | "pending" | "failed" | "processing"
  date: Date
  description: string
  reference: string
  counterparty?: string
  plan?: string
  paymentMethod?: string
  paymentProof?: string
}

export default function TransactionsPage() {
  // Mock transaction data
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: "TRX-001",
      type: "purchase",
      amount: 100000,
      status: "completed",
      date: new Date(2025, 3, 20), // April 20, 2025
      description: "Coin purchase",
      reference: "COIN-7D-001",
      counterparty: "LOCEXCOIN",
      plan: "7-Day Plan",
      paymentMethod: "Bank Transfer",
    },
    {
      id: "TRX-002",
      type: "sale",
      amount: 135000,
      status: "completed",
      date: new Date(2025, 3, 18), // April 18, 2025
      description: "Coin sale - 7-Day Plan matured",
      reference: "COIN-7D-001",
      counterparty: "LOCEXCOIN",
      plan: "7-Day Plan",
    },
    {
      id: "TRX-003",
      type: "purchase",
      amount: 50000,
      status: "pending",
      date: new Date(2025, 3, 15), // April 15, 2025
      description: "Coin purchase - Payment pending",
      reference: "COIN-14D-002",
      counterparty: "LOCEXCOIN",
      plan: "14-Day Plan",
      paymentMethod: "Bank Transfer",
    },
    {
      id: "TRX-004",
      type: "referral",
      amount: 1000,
      status: "completed",
      date: new Date(2025, 3, 12), // April 12, 2025
      description: "Referral bonus - John Smith signed up",
      reference: "REF-001",
      counterparty: "John Smith",
    },
    {
      id: "TRX-005",
      type: "bonus",
      amount: 10000,
      status: "completed",
      date: new Date(2025, 3, 10), // April 10, 2025
      description: "Weekly referral bonus - 25 referrals",
      reference: "WKBONUS-001",
    },
    {
      id: "TRX-006",
      type: "withdrawal",
      amount: 50000,
      status: "processing",
      date: new Date(2025, 3, 8), // April 8, 2025
      description: "Withdrawal to bank account",
      reference: "WTH-001",
      paymentMethod: "Bank Transfer",
    },
    {
      id: "TRX-007",
      type: "purchase",
      amount: 75000,
      status: "failed",
      date: new Date(2025, 3, 5), // April 5, 2025
      description: "Coin purchase - Payment failed",
      reference: "COIN-7D-003",
      counterparty: "LOCEXCOIN",
      plan: "7-Day Plan",
      paymentMethod: "Bank Transfer",
    },
    {
      id: "TRX-008",
      type: "sale",
      amount: 103500,
      status: "completed",
      date: new Date(2025, 3, 3), // April 3, 2025
      description: "Coin sale - 14-Day Plan matured",
      reference: "COIN-14D-004",
      counterparty: "LOCEXCOIN",
      plan: "14-Day Plan",
    },
    {
      id: "TRX-009",
      type: "referral",
      amount: 5000,
      status: "completed",
      date: new Date(2025, 3, 1), // April 1, 2025
      description: "Referral commission - First deposit by Mary Johnson",
      reference: "REF-002",
      counterparty: "Mary Johnson",
    },
    {
      id: "TRX-010",
      type: "withdrawal",
      amount: 100000,
      status: "completed",
      date: new Date(2025, 2, 28), // March 28, 2025
      description: "Withdrawal to bank account",
      reference: "WTH-002",
      paymentMethod: "Bank Transfer",
    },
  ])

  // Filter states
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [dateFilter, setDateFilter] = useState<string>("all")
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)

  // Calculate date ranges for filtering
  const today = new Date()
  const lastWeek = new Date(today)
  lastWeek.setDate(today.getDate() - 7)
  const lastMonth = new Date(today)
  lastMonth.setMonth(today.getMonth() - 1)

  // Filter transactions based on selected filters
  const filteredTransactions = transactions.filter((transaction) => {
    // Search term filter
    const searchMatch =
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (transaction.counterparty && transaction.counterparty.toLowerCase().includes(searchTerm.toLowerCase()))

    // Type filter
    const typeMatch = typeFilter === "all" || transaction.type === typeFilter

    // Status filter
    const statusMatch = statusFilter === "all" || transaction.status === statusFilter

    // Date filter
    let dateMatch = true
    if (dateFilter === "today") {
      dateMatch = transaction.date.toDateString() === today.toDateString()
    } else if (dateFilter === "week") {
      dateMatch = transaction.date >= lastWeek
    } else if (dateFilter === "month") {
      dateMatch = transaction.date >= lastMonth
    }

    return searchMatch && typeMatch && statusMatch && dateMatch
  })

  // Calculate totals
  const totalIncome = transactions
    .filter((t) => (t.type === "sale" || t.type === "referral" || t.type === "bonus") && t.status === "completed")
    .reduce((sum, t) => sum + t.amount, 0)

  const totalExpense = transactions
    .filter((t) => (t.type === "purchase" || t.type === "withdrawal") && t.status === "completed")
    .reduce((sum, t) => sum + t.amount, 0)

  // View transaction details
  const viewTransactionDetails = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
  }

  // Helper function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="h-3 w-3 mr-1" /> Completed
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            <Clock className="h-3 w-3 mr-1" /> Pending
          </Badge>
        )
      case "processing":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <RefreshCw className="h-3 w-3 mr-1" /> Processing
          </Badge>
        )
      case "failed":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <XCircle className="h-3 w-3 mr-1" /> Failed
          </Badge>
        )
      default:
        return <Badge variant="outline">{status.charAt(0).toUpperCase() + status.slice(1)}</Badge>
    }
  }

  // Helper function to get transaction type badge
  const getTypeBadge = (type: string) => {
    switch (type) {
      case "purchase":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <ArrowDownLeft className="h-3 w-3 mr-1" /> Purchase
          </Badge>
        )
      case "sale":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <ArrowUpRight className="h-3 w-3 mr-1" /> Sale
          </Badge>
        )
      case "referral":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            <Users className="h-3 w-3 mr-1" /> Referral
          </Badge>
        )
      case "bonus":
        return (
          <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
            <Gift className="h-3 w-3 mr-1" /> Bonus
          </Badge>
        )
      case "withdrawal":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <ArrowUpRight className="h-3 w-3 mr-1" /> Withdrawal
          </Badge>
        )
      default:
        return <Badge variant="outline">{type.charAt(0).toUpperCase() + type.slice(1)}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Transactions</h1>
        <p className="text-muted-foreground">View and manage your transaction history</p>
      </div>

      {/* Transaction Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
            <ArrowUpRight className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">₦{totalIncome.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">From sales, referrals, and bonuses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expense</CardTitle>
            <ArrowDownLeft className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">₦{totalExpense.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">From purchases and withdrawals</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Balance</CardTitle>
            <Coins className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">₦{(totalIncome - totalExpense).toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Total income minus expenses</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search transactions by ID, description, or reference..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[130px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="purchase">Purchase</SelectItem>
              <SelectItem value="sale">Sale</SelectItem>
              <SelectItem value="referral">Referral</SelectItem>
              <SelectItem value="bonus">Bonus</SelectItem>
              <SelectItem value="withdrawal">Withdrawal</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px]">
              <AlertCircle className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="processing">Processing</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>

          <Select value={dateFilter} onValueChange={setDateFilter}>
            <SelectTrigger className="w-[130px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Date" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>
            {filteredTransactions.length} transaction{filteredTransactions.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredTransactions.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Transaction ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell>{format(transaction.date, "MMM dd, yyyy")}</TableCell>
                      <TableCell className="font-mono text-xs">{transaction.id}</TableCell>
                      <TableCell>{getTypeBadge(transaction.type)}</TableCell>
                      <TableCell className="max-w-[200px] truncate">{transaction.description}</TableCell>
                      <TableCell
                        className={
                          transaction.type === "purchase" || transaction.type === "withdrawal"
                            ? "text-red-600 font-medium"
                            : "text-green-600 font-medium"
                        }
                      >
                        {transaction.type === "purchase" || transaction.type === "withdrawal" ? "-" : "+"}₦
                        {transaction.amount.toLocaleString()}
                      </TableCell>
                      <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => viewTransactionDetails(transaction)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <div className="rounded-full bg-gray-100 p-3 mb-4">
                <AlertCircle className="h-6 w-6 text-gray-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">No transactions found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or search term to find what you're looking for.
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setTypeFilter("all")
                  setStatusFilter("all")
                  setDateFilter("all")
                }}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Details Dialog */}
      <Dialog open={!!selectedTransaction} onOpenChange={(open) => !open && setSelectedTransaction(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Transaction Details</DialogTitle>
            <DialogDescription>Detailed information about transaction {selectedTransaction?.id}</DialogDescription>
          </DialogHeader>

          {selectedTransaction && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-semibold text-lg">
                    {selectedTransaction.type.charAt(0).toUpperCase() + selectedTransaction.type.slice(1)}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {format(selectedTransaction.date, "MMMM dd, yyyy HH:mm")}
                  </p>
                </div>
                <div>{getStatusBadge(selectedTransaction.status)}</div>
              </div>

              <div className="border rounded-lg p-4 bg-gray-50">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Amount</p>
                  <p
                    className={`text-2xl font-bold ${
                      selectedTransaction.type === "purchase" || selectedTransaction.type === "withdrawal"
                        ? "text-red-600"
                        : "text-green-600"
                    }`}
                  >
                    {selectedTransaction.type === "purchase" || selectedTransaction.type === "withdrawal" ? "-" : "+"}₦
                    {selectedTransaction.amount.toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <p className="text-muted-foreground">Transaction ID:</p>
                  <p className="font-mono">{selectedTransaction.id}</p>

                  <p className="text-muted-foreground">Reference:</p>
                  <p className="font-mono">{selectedTransaction.reference}</p>

                  <p className="text-muted-foreground">Description:</p>
                  <p>{selectedTransaction.description}</p>

                  {selectedTransaction.counterparty && (
                    <>
                      <p className="text-muted-foreground">Counterparty:</p>
                      <p>{selectedTransaction.counterparty}</p>
                    </>
                  )}

                  {selectedTransaction.plan && (
                    <>
                      <p className="text-muted-foreground">Plan:</p>
                      <p>{selectedTransaction.plan}</p>
                    </>
                  )}

                  {selectedTransaction.paymentMethod && (
                    <>
                      <p className="text-muted-foreground">Payment Method:</p>
                      <p>{selectedTransaction.paymentMethod}</p>
                    </>
                  )}
                </div>
              </div>

              {selectedTransaction.paymentProof && (
                <div className="space-y-2">
                  <Label>Payment Proof</Label>
                  <div className="border rounded-md overflow-hidden">
                    <img
                      src={selectedTransaction.paymentProof || "/placeholder.svg"}
                      alt="Payment Proof"
                      className="w-full h-auto"
                    />
                  </div>
                </div>
              )}

              {selectedTransaction.status === "pending" && selectedTransaction.type === "purchase" && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 text-sm text-yellow-800">
                  <div className="flex items-start">
                    <AlertCircle className="h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
                    <p>
                      This transaction is pending payment confirmation. Please ensure you have made the payment to the
                      provided bank account.
                    </p>
                  </div>
                </div>
              )}

              {selectedTransaction.status === "failed" && (
                <div className="bg-red-50 border border-red-200 rounded-md p-3 text-sm text-red-800">
                  <div className="flex items-start">
                    <XCircle className="h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
                    <p>This transaction has failed. Please contact support if you believe this is an error.</p>
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setSelectedTransaction(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Missing icons
function Clock(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  )
}

function RefreshCw(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 2v6h6" />
      <path d="M21 12A9 9 0 0 0 6 5.3L3 8" />
      <path d="M21 22v-6h-6" />
      <path d="M3 12a9 9 0 0 0 15 6.7l3-2.7" />
    </svg>
  )
}

function Gift(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 12 20 22 4 22 4 12" />
      <rect x="2" y="7" width="20" height="5" />
      <line x1="12" y1="22" x2="12" y2="7" />
      <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z" />
      <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z" />
    </svg>
  )
}
