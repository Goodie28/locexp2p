"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Clock,
  CheckCircle,
  AlertCircle,
  DollarSign,
  Coins,
  ClipboardCheck,
  RefreshCw,
  AlertTriangle,
  Lock,
  PlusCircle,
  ArrowRight,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function InvestmentsPage() {
  const { toast } = useToast()
  const [activeInvestments, setActiveInvestments] = useState([
    {
      id: 1,
      plan: "7-Day Plan",
      amount: 100000,
      profit: 35000,
      total: 135000,
      startDate: "Apr 15, 2025",
      endDate: "Apr 22, 2025",
      progress: 71,
      daysLeft: 2,
      status: "active",
    },
    {
      id: 2,
      plan: "14-Day Plan",
      amount: 50000,
      profit: 53500,
      total: 103500,
      startDate: "Apr 10, 2025",
      endDate: "Apr 24, 2025",
      progress: 36,
      daysLeft: 9,
      status: "active",
    },
    {
      id: 3,
      plan: "21-Day Plan",
      amount: 100000,
      profit: 215000,
      total: 315000,
      startDate: "Apr 5, 2025",
      endDate: "Apr 26, 2025",
      progress: 24,
      daysLeft: 16,
      status: "active",
    },
    {
      id: 6,
      plan: "7-Day Plan",
      amount: 75000,
      profit: 26250,
      total: 101250,
      startDate: "Apr 15, 2025",
      endDate: "Apr 22, 2025",
      progress: 100,
      daysLeft: 0,
      status: "matured",
    },
  ])

  const [completedInvestments, setCompletedInvestments] = useState([
    {
      id: 4,
      plan: "7-Day Plan",
      amount: 50000,
      profit: 17500,
      total: 67500,
      startDate: "Apr 1, 2025",
      endDate: "Apr 8, 2025",
      status: "Sold",
    },
    {
      id: 5,
      plan: "14-Day Plan",
      amount: 25000,
      profit: 26750,
      total: 51750,
      startDate: "Mar 15, 2025",
      endDate: "Mar 29, 2025",
      status: "Sold",
    },
  ])

  // Track if the user has made a recommitment bid
  const [hasActiveRecommitmentBid, setHasActiveRecommitmentBid] = useState(false)

  const [selectedInvestment, setSelectedInvestment] = useState<any>(null)
  const [recommitDialogOpen, setRecommitDialogOpen] = useState(false)
  const [listForSaleDialogOpen, setListForSaleDialogOpen] = useState(false)
  const [withdrawDialogOpen, setWithdrawDialogOpen] = useState(false)
  const [salePrice, setSalePrice] = useState("")
  const [agreeToTerms, setAgreeToTerms] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState("7-day")
  const [recommitAmount, setRecommitAmount] = useState("")
  const [agreeToRecommitTerms, setAgreeToRecommitTerms] = useState(false)

  // Check if there are any matured coins
  const hasMaturedCoins = activeInvestments.some((investment) => investment.status === "matured")

  const handleMakeRecommitmentBid = () => {
    setRecommitDialogOpen(true)
    setRecommitAmount("50000") // Starting with a default amount
  }

  const handleManageMaturedCoin = (investment: any) => {
    setSelectedInvestment(investment)
    setWithdrawDialogOpen(true)
  }

  const confirmRecommitment = () => {
    if (!recommitAmount || Number.parseFloat(recommitAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount for your recommitment bid.",
        variant: "destructive",
      })
      return
    }

    if (!agreeToRecommitTerms) {
      toast({
        title: "Terms Required",
        description: "You must agree to the terms and conditions to make a recommitment bid.",
        variant: "destructive",
      })
      return
    }

    // Create a new investment for the recommitment bid
    const amount = Number.parseFloat(recommitAmount)
    const newInvestment = {
      id: Date.now(), // Generate a new ID
      amount: amount,
      startDate: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      progress: 0,
      status: "active",
      isRecommitmentBid: true, // Mark this as a recommitment bid
    } as any

    // Set plan-specific details
    if (selectedPlan === "7-day") {
      newInvestment.plan = "7-Day Plan"
      newInvestment.profit = amount * 0.35
      newInvestment.daysLeft = 7
      const endDate = new Date()
      endDate.setDate(endDate.getDate() + 7)
      newInvestment.endDate = endDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    } else if (selectedPlan === "14-day") {
      newInvestment.plan = "14-Day Plan"
      newInvestment.profit = amount * 1.07
      newInvestment.daysLeft = 14
      const endDate = new Date()
      endDate.setDate(endDate.getDate() + 14)
      newInvestment.endDate = endDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    } else if (selectedPlan === "21-day") {
      newInvestment.plan = "21-Day Plan"
      newInvestment.profit = amount * 2.15
      newInvestment.daysLeft = 21
      const endDate = new Date()
      endDate.setDate(endDate.getDate() + 21)
      newInvestment.endDate = endDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    }

    newInvestment.total = newInvestment.amount + newInvestment.profit

    // Add the new investment to active investments
    setActiveInvestments([...activeInvestments, newInvestment])

    // Set that the user has made a recommitment bid
    setHasActiveRecommitmentBid(true)

    setRecommitDialogOpen(false)
    setRecommitAmount("")
    setAgreeToRecommitTerms(false)

    toast({
      title: "Recommitment Bid Successful",
      description: `Your recommitment bid of ₦${amount.toLocaleString()} has been placed. Your matured coins are now unlocked for withdrawal or sale.`,
      variant: "success",
    })
  }

  const handleWithdrawOptions = () => {
    setWithdrawDialogOpen(false)
    setListForSaleDialogOpen(true)
  }

  const confirmListForSale = () => {
    if (!salePrice || Number.parseFloat(salePrice) < selectedInvestment.total) {
      toast({
        title: "Invalid Price",
        description: "Sale price must be at least equal to the total value of the investment.",
        variant: "destructive",
      })
      return
    }

    if (!agreeToTerms) {
      toast({
        title: "Terms Required",
        description: "You must agree to the terms and conditions to list your coin for sale.",
        variant: "destructive",
      })
      return
    }

    // In a real app, this would call an API to list the coin for sale
    const updatedActiveInvestments = activeInvestments.filter((investment) => investment.id !== selectedInvestment.id)

    const newCompletedInvestment = {
      id: selectedInvestment.id,
      plan: selectedInvestment.plan,
      amount: selectedInvestment.amount,
      profit: selectedInvestment.profit,
      total: selectedInvestment.total,
      startDate: selectedInvestment.startDate,
      endDate: selectedInvestment.endDate,
      status: "Pending Approval",
      salePrice: Number.parseFloat(salePrice),
    }

    setCompletedInvestments([newCompletedInvestment, ...completedInvestments])
    setActiveInvestments(updatedActiveInvestments)
    setListForSaleDialogOpen(false)
    setSalePrice("")
    setAgreeToTerms(false)

    toast({
      title: "Coin Submitted for Approval",
      description: `Your coin has been submitted to admin for verification and approval at ₦${Number.parseFloat(
        salePrice,
      ).toLocaleString()}.`,
      variant: "success",
    })
  }

  const handleWithdraw = () => {
    // In a real app, this would call an API to process the withdrawal
    const updatedActiveInvestments = activeInvestments.filter((investment) => investment.id !== selectedInvestment.id)

    const newCompletedInvestment = {
      id: selectedInvestment.id,
      plan: selectedInvestment.plan,
      amount: selectedInvestment.amount,
      profit: selectedInvestment.profit,
      total: selectedInvestment.total,
      startDate: selectedInvestment.startDate,
      endDate: selectedInvestment.endDate,
      status: "Withdrawn",
    }

    setCompletedInvestments([newCompletedInvestment, ...completedInvestments])
    setActiveInvestments(updatedActiveInvestments)
    setWithdrawDialogOpen(false)

    toast({
      title: "Withdrawal Successful",
      description: `Your coin has been successfully withdrawn. The amount of ₦${selectedInvestment.total.toLocaleString()} will be credited to your wallet.`,
      variant: "success",
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My Investments</h1>
        <p className="text-muted-foreground">Track your active and completed investments</p>
      </div>

      {/* Global recommitment notification */}
      {hasMaturedCoins && !hasActiveRecommitmentBid && (
        <Alert variant="warning" className="bg-amber-50 border-amber-200 text-amber-800">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Matured Coins Locked</AlertTitle>
          <AlertDescription className="flex flex-col gap-4">
            <p>
              You have matured coins that are currently locked. To unlock them for withdrawal or sale, you must make a
              fresh recommitment bid.
            </p>
            <Button onClick={handleMakeRecommitmentBid} className="w-fit bg-amber-600 hover:bg-amber-700">
              <PlusCircle className="h-4 w-4 mr-2" />
              Make Recommitment Bid
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Success notification when recommitment is made */}
      {hasMaturedCoins && hasActiveRecommitmentBid && (
        <Alert variant="success" className="bg-green-50 border-green-200 text-green-800">
          <CheckCircle className="h-4 w-4" />
          <AlertTitle>Matured Coins Unlocked</AlertTitle>
          <AlertDescription>
            You have an active recommitment bid. Your matured coins are now unlocked and available for withdrawal or
            sale.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active">Active Investments</TabsTrigger>
          <TabsTrigger value="completed">Completed Investments</TabsTrigger>
        </TabsList>
        <TabsContent value="active" className="space-y-4">
          {activeInvestments.length > 0 ? (
            activeInvestments.map((investment) => (
              <Card key={investment.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>
                        {investment.plan}
                        {investment.isRecommitmentBid && <Badge className="ml-2 bg-purple-600">Recommitment Bid</Badge>}
                      </CardTitle>
                      <CardDescription>Started on {investment.startDate}</CardDescription>
                    </div>
                    <Badge className={investment.status === "matured" ? "bg-green-600" : "bg-blue-600"}>
                      {investment.status === "matured" ? "Matured" : "Active"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Investment Amount</p>
                      <p className="text-lg font-semibold">₦{investment.amount.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Expected Profit</p>
                      <p className="text-lg font-semibold text-green-600">₦{investment.profit.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Maturity Date</p>
                      <p className="text-lg font-semibold">{investment.endDate}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Total Return</p>
                      <p className="text-lg font-semibold text-green-600">₦{investment.total.toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        {investment.status === "matured" ? (
                          <>
                            <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                            <span className="text-sm font-medium">Investment has matured</span>
                          </>
                        ) : (
                          <>
                            <Clock className="h-4 w-4 text-blue-600 mr-2" />
                            <span className="text-sm font-medium">{investment.daysLeft} days left until maturity</span>
                          </>
                        )}
                      </div>
                      <span className="text-sm font-medium">{investment.progress}%</span>
                    </div>
                    <Progress value={investment.progress} className="h-2" />
                  </div>
                  {investment.status === "matured" && !hasActiveRecommitmentBid && (
                    <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-amber-800 text-sm">
                      <p className="flex items-center">
                        <Lock className="h-4 w-4 mr-2 flex-shrink-0" />
                        <span>
                          This matured coin is locked. Make a fresh recommitment bid using the button at the top of the
                          page to unlock it.
                        </span>
                      </p>
                    </div>
                  )}
                  {investment.status === "matured" && hasActiveRecommitmentBid && (
                    <div className="bg-green-50 border border-green-200 rounded-md p-3 text-green-800 text-sm">
                      <p className="flex items-center">
                        <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                        <span>This matured coin is unlocked and available for withdrawal or sale.</span>
                      </p>
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  {investment.status === "matured" ? (
                    <Button
                      className="w-full bg-green-600 hover:bg-green-700"
                      onClick={() => handleManageMaturedCoin(investment)}
                      disabled={!hasActiveRecommitmentBid}
                    >
                      <Coins className="h-4 w-4 mr-2" />
                      {hasActiveRecommitmentBid ? "Withdraw Matured Coin" : "Locked - Make Recommitment Bid First"}
                    </Button>
                  ) : (
                    <Button variant="outline" className="w-full" disabled>
                      Matures in {investment.daysLeft} days
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>No Active Investments</CardTitle>
                <CardDescription>You don&apos;t have any active investments at the moment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-blue-100 p-3 mb-4">
                    <AlertCircle className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No investments found</h3>
                  <p className="text-muted-foreground mb-4">
                    Participate in auctions to start investing and earning profits
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                  <a href="/dashboard/auctions">Go to Auctions</a>
                </Button>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
        <TabsContent value="completed" className="space-y-4">
          {completedInvestments.length > 0 ? (
            completedInvestments.map((investment) => (
              <Card key={investment.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{investment.plan}</CardTitle>
                      <CardDescription>
                        {investment.startDate} - {investment.endDate}
                      </CardDescription>
                    </div>
                    <Badge
                      className={
                        investment.status === "Pending Approval"
                          ? "bg-amber-600"
                          : investment.status === "Listed for Sale"
                            ? "bg-blue-600"
                            : investment.status === "Withdrawn"
                              ? "bg-purple-600"
                              : "bg-green-600"
                      }
                    >
                      {investment.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Investment Amount</p>
                      <p className="text-lg font-semibold">₦{investment.amount.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Profit Earned</p>
                      <p className="text-lg font-semibold text-green-600">₦{investment.profit.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Status</p>
                      <p className="text-lg font-semibold flex items-center">
                        {investment.status === "Pending Approval" ? (
                          <>
                            <ClipboardCheck className="h-4 w-4 text-amber-600 mr-2" />
                            Awaiting Admin Approval
                          </>
                        ) : investment.status === "Withdrawn" ? (
                          <>
                            <CheckCircle className="h-4 w-4 text-purple-600 mr-2" />
                            Withdrawn to Wallet
                          </>
                        ) : (
                          <>
                            <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                            {investment.status}
                          </>
                        )}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Total Return</p>
                      <p className="text-lg font-semibold text-green-600">₦{investment.total.toLocaleString()}</p>
                    </div>
                    {(investment.status === "Listed for Sale" || investment.status === "Pending Approval") && (
                      <div className="space-y-1 col-span-2">
                        <p className="text-sm text-muted-foreground">Listed Sale Price</p>
                        <p className="text-lg font-semibold text-amber-600">
                          ₦{investment.salePrice?.toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                  {investment.status === "Pending Approval" && (
                    <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-amber-800 text-sm">
                      <p className="flex items-center">
                        <ClipboardCheck className="h-4 w-4 mr-2" />
                        Your coin listing is currently under review by the admin. This process typically takes 1-24
                        hours.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>No Completed Investments</CardTitle>
                <CardDescription>You don&apos;t have any completed investments yet</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="rounded-full bg-blue-100 p-3 mb-4">
                    <AlertCircle className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No completed investments found</h3>
                  <p className="text-muted-foreground mb-4">
                    Your completed investments will appear here after they mature
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                  <a href="/dashboard/auctions">Go to Auctions</a>
                </Button>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Recommitment Bid Dialog */}
      <Dialog open={recommitDialogOpen} onOpenChange={setRecommitDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Make a Recommitment Bid</DialogTitle>
            <DialogDescription>
              You must make a fresh recommitment bid before you can withdraw or list your matured coins for sale.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-amber-800 text-sm mb-4">
              <p className="flex items-center">
                <AlertTriangle className="h-4 w-4 mr-2 flex-shrink-0" />
                <span>
                  System Policy: You must make a fresh recommitment bid before you can withdraw or list your matured
                  coins for sale.
                </span>
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="investment-plan">Select Investment Plan</Label>
              <Select value={selectedPlan} onValueChange={setSelectedPlan}>
                <SelectTrigger id="investment-plan">
                  <SelectValue placeholder="Select investment plan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7-day">7-Day Plan (35% ROI)</SelectItem>
                  <SelectItem value="14-day">14-Day Plan (107% ROI)</SelectItem>
                  <SelectItem value="21-day">21-Day Plan (215% ROI)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="recommit-amount">Bid Amount (₦)</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                <Input
                  id="recommit-amount"
                  type="number"
                  value={recommitAmount}
                  onChange={(e) => setRecommitAmount(e.target.value)}
                  className="pl-10"
                  placeholder="Enter amount for your new bid"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Enter the amount you wish to invest in your new recommitment bid.
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-md p-3 text-blue-800 text-sm">
              <p className="flex items-center">
                <RefreshCw className="h-4 w-4 mr-2 flex-shrink-0" />
                <span>
                  This is a fresh investment separate from your matured coins. After making this recommitment bid,
                  you'll be able to withdraw or sell your matured coins.
                </span>
              </p>
            </div>

            <div className="flex items-start space-x-2 pt-2">
              <Checkbox
                id="recommit-terms"
                checked={agreeToRecommitTerms}
                onCheckedChange={(checked) => setAgreeToRecommitTerms(checked === true)}
              />
              <Label htmlFor="recommit-terms" className="text-sm leading-tight">
                I understand that I am making a new investment commitment, and that this bid will be locked for the
                selected investment period.
              </Label>
            </div>
          </div>

          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button
              onClick={confirmRecommitment}
              className="sm:w-auto w-full bg-green-600 hover:bg-green-700"
              disabled={!recommitAmount || !agreeToRecommitTerms}
            >
              <PlusCircle className="h-4 w-4 mr-2" />
              Confirm Recommitment Bid
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Withdraw Dialog */}
      <Dialog open={withdrawDialogOpen} onOpenChange={setWithdrawDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Withdraw Matured Coin</DialogTitle>
            <DialogDescription>Choose how you would like to manage your matured coin.</DialogDescription>
          </DialogHeader>

          {selectedInvestment && (
            <div className="space-y-4 py-2">
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Investment Plan:</span>
                  <span className="text-sm">{selectedInvestment.plan}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Total Value:</span>
                  <span className="text-sm font-bold text-green-600">₦{selectedInvestment.total.toLocaleString()}</span>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-md p-3 text-green-800 text-sm mb-4">
                <p className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span>
                    This matured coin is unlocked because you have an active recommitment bid. You can now withdraw it
                    to your wallet or list it for sale.
                  </span>
                </p>
              </div>

              <div className="flex flex-col space-y-2">
                <Button onClick={handleWithdraw} className="w-full bg-green-600 hover:bg-green-700">
                  <ArrowRight className="h-4 w-4 mr-2" />
                  Withdraw to Wallet
                </Button>
                <Button onClick={handleWithdrawOptions} className="w-full bg-amber-600 hover:bg-amber-700">
                  <Coins className="h-4 w-4 mr-2" />
                  List for Sale
                </Button>
              </div>
            </div>
          )}

          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setWithdrawDialogOpen(false)} className="sm:w-auto w-full">
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* List for Sale Dialog */}
      <Dialog open={listForSaleDialogOpen} onOpenChange={setListForSaleDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>List Coins for Sale</DialogTitle>
            <DialogDescription>
              Set your desired sale price for listing your coins on the marketplace.
            </DialogDescription>
          </DialogHeader>

          {selectedInvestment && (
            <div className="space-y-4 py-2">
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Coin ID:</span>
                  <span className="text-sm">COIN-{selectedInvestment.id.toString().padStart(3, "0")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Total Value:</span>
                  <span className="text-sm font-bold text-green-600">₦{selectedInvestment.total.toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="sale-price">Sale Price (₦)</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    id="sale-price"
                    type="number"
                    value={salePrice}
                    onChange={(e) => setSalePrice(e.target.value)}
                    className="pl-10"
                    placeholder="Enter your desired sale price"
                    min={selectedInvestment.total}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Minimum sale price: ₦{selectedInvestment.total.toLocaleString()}
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-md p-3 text-blue-800 text-sm mb-2">
                <p className="flex items-center">
                  <ClipboardCheck className="h-4 w-4 mr-2" />
                  Your coin listing will be submitted to admin for verification and approval before it appears in the
                  marketplace. This process typically takes 1-24 hours.
                </p>
              </div>

              <div className="flex items-start space-x-2 pt-2">
                <Checkbox
                  id="terms"
                  checked={agreeToTerms}
                  onCheckedChange={(checked) => setAgreeToTerms(checked === true)}
                />
                <Label htmlFor="terms" className="text-sm leading-tight">
                  I understand that once listed and approved by admin, my coins will be available for purchase by other
                  members.
                </Label>
              </div>
            </div>
          )}

          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setListForSaleDialogOpen(false)
                setWithdrawDialogOpen(true)
              }}
              className="sm:w-auto w-full"
            >
              Back
            </Button>
            <Button
              onClick={confirmListForSale}
              className="sm:w-auto w-full bg-amber-600 hover:bg-amber-700"
              disabled={!salePrice || !agreeToTerms}
            >
              <Coins className="h-4 w-4 mr-2" />
              Submit for Approval
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
