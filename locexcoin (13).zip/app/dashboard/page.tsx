"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowRight, ArrowUpRight, Coins, DollarSign, TrendingUp, Users } from "lucide-react"

export default function DashboardPage() {
  // User data state
  const [userData, setUserData] = useState({
    fullName: "John Doe",
    email: "john@example.com",
    phone: "+2348012345678",
    joinDate: "Apr 15, 2025",
  })

  const [countdown, setCountdown] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0,
  })
  const [isAuctionLive, setIsAuctionLive] = useState(false)
  const [auctionTimeRemaining, setAuctionTimeRemaining] = useState(300) // 5 minutes in seconds

  // Function to check if auction is live based on West Central Africa Time (UTC+01:00)
  const checkIfAuctionIsLive = () => {
    // Get current time in West Central Africa Time (UTC+01:00)
    const now = new Date()
    const options = { timeZone: "Africa/Lagos" }
    const wcatTime = new Date(now.toLocaleString("en-US", options))

    const hours = wcatTime.getHours()
    const minutes = wcatTime.getMinutes()
    const day = wcatTime.getDay() // 0 is Sunday, 1 is Monday, etc.

    // Auction times: 9:00 AM and 6:30 PM on weekdays, 6:30 PM on Sunday
    const isWeekday = day >= 1 && day <= 6 // Monday to Saturday
    const isSunday = day === 0

    // Check if current time matches auction times
    const isMorningAuction = isWeekday && hours === 9 && minutes >= 0 && minutes < 30
    const isEveningAuction = (isWeekday || isSunday) && hours === 18 && minutes >= 30 && minutes < 59

    return isMorningAuction || isEveningAuction
  }

  // Function to calculate time until next auction
  const calculateTimeUntilNextAuction = () => {
    // Get current time in West Central Africa Time (UTC+01:00)
    const now = new Date()
    const options = { timeZone: "Africa/Lagos" }
    const wcatTime = new Date(now.toLocaleString("en-US", options))

    const hours = wcatTime.getHours()
    const minutes = wcatTime.getMinutes()
    const day = wcatTime.getDay() // 0 is Sunday, 1 is Monday, etc.

    const nextAuctionTime = new Date(wcatTime)

    // Set next auction time based on current time
    if (day === 0) {
      // Sunday
      if (hours < 18 || (hours === 18 && minutes < 30)) {
        // Next auction is today at 6:30 PM
        nextAuctionTime.setHours(18, 30, 0, 0)
      } else {
        // Next auction is Monday at 9:00 AM
        nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
        nextAuctionTime.setHours(9, 0, 0, 0)
      }
    } else if (day >= 1 && day <= 5) {
      // Monday to Friday
      if (hours < 9) {
        // Next auction is today at 9:00 AM
        nextAuctionTime.setHours(9, 0, 0, 0)
      } else if ((hours === 9 && minutes >= 30) || hours > 9) {
        if (hours < 18 || (hours === 18 && minutes < 30)) {
          // Next auction is today at 6:30 PM
          nextAuctionTime.setHours(18, 30, 0, 0)
        } else {
          // Next auction is tomorrow at 9:00 AM
          nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
          nextAuctionTime.setHours(9, 0, 0, 0)
        }
      }
    } else if (day === 6) {
      // Saturday
      if (hours < 9) {
        // Next auction is today at 9:00 AM
        nextAuctionTime.setHours(9, 0, 0, 0)
      } else if ((hours === 9 && minutes >= 30) || hours > 9) {
        if (hours < 18 || (hours === 18 && minutes < 30)) {
          // Next auction is today at 6:30 PM
          nextAuctionTime.setHours(18, 30, 0, 0)
        } else {
          // Next auction is Sunday at 6:30 PM
          nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
          nextAuctionTime.setHours(18, 30, 0, 0)
        }
      }
    }

    // Calculate time difference in milliseconds
    const timeDiff = nextAuctionTime.getTime() - wcatTime.getTime()

    // Convert to hours, minutes, seconds
    const hoursUntil = Math.floor(timeDiff / (1000 * 60 * 60))
    const minutesUntil = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60))
    const secondsUntil = Math.floor((timeDiff % (1000 * 60)) / 1000)

    return {
      hours: hoursUntil,
      minutes: minutesUntil,
      seconds: secondsUntil,
    }
  }

  // Simulate countdown timer
  useEffect(() => {
    // Check if auction is currently live
    const auctionLiveStatus = checkIfAuctionIsLive()

    // If auction just became live, set the start time
    if (auctionLiveStatus && !isAuctionLive) {
      setAuctionTimeRemaining(300) // Reset to 5 minutes (300 seconds)
    }

    setIsAuctionLive(auctionLiveStatus)

    // If auction is not live, start countdown to next auction
    if (!auctionLiveStatus) {
      const timeUntilNextAuction = calculateTimeUntilNextAuction()
      setCountdown(timeUntilNextAuction)
    }

    const interval = setInterval(() => {
      // Check if auction is live
      const auctionLiveStatus = checkIfAuctionIsLive()

      // If auction is live, count down the 5-minute window
      if (auctionLiveStatus) {
        if (auctionTimeRemaining > 0) {
          setAuctionTimeRemaining((prev) => prev - 1)
        } else {
          // Auction has ended after 5 minutes or countdown reached zero
          setIsAuctionLive(false)
          const timeUntilNextAuction = calculateTimeUntilNextAuction()
          setCountdown(timeUntilNextAuction)
        }
      } else {
        // If auction is not live, update countdown to next auction
        setCountdown((prev) => {
          if (prev.seconds > 0) {
            return { ...prev, seconds: prev.seconds - 1 }
          } else if (prev.minutes > 0) {
            return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
          } else if (prev.hours > 0) {
            return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
          } else {
            // Time's up, check if auction is now live
            const isNowLive = checkIfAuctionIsLive()
            if (isNowLive) {
              setIsAuctionLive(true)
              setAuctionTimeRemaining(300) // 5 minutes in seconds
              return prev
            } else {
              // Recalculate time until next auction
              return calculateTimeUntilNextAuction()
            }
          }
        })
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [isAuctionLive, auctionTimeRemaining])

  // Get first name for personalized greeting
  const getFirstName = () => {
    return userData.fullName.split(" ")[0]
  }

  // Get greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Good morning"
    if (hour < 18) return "Good afternoon"
    return "Good evening"
  }

  // Format auction time remaining
  const formatAuctionTimeRemaining = () => {
    if (auctionTimeRemaining <= 0) {
      return "00:00"
    }
    const minutes = Math.floor(auctionTimeRemaining / 60)
    const seconds = auctionTimeRemaining % 60
    return `${minutes}:${String(seconds).padStart(2, "0")}`
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            {getGreeting()}, {getFirstName()}!
          </h1>
          <p className="text-muted-foreground">Welcome to your dashboard. Here's an overview of your account.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/dashboard/auctions">
              View Auctions
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>

      {/* Next Auction Card */}
      <Card className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <CardHeader>
          <CardTitle className="text-white">Next Auction</CardTitle>
          <CardDescription className="text-blue-100">
            {isAuctionLive
              ? "Auction is now live! Click the button below to participate."
              : "Get ready for the next auction. Make sure you have funds ready."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isAuctionLive ? (
            <div className="flex flex-col items-center justify-center py-6">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">Auction is LIVE!</h3>
                <p className="text-blue-100">First come, first served. Act quickly!</p>
                <p className="text-xl font-bold mt-2">
                  {auctionTimeRemaining <= 0 ? "Auction Closed" : `Closes in: ${formatAuctionTimeRemaining()}`}
                </p>
              </div>
              <Button
                asChild
                size="lg"
                className={`${auctionTimeRemaining <= 0 ? "bg-gray-500 hover:bg-gray-600" : "bg-orange hover:bg-orange/90"} text-white`}
                disabled={auctionTimeRemaining <= 0}
              >
                <Link href="/dashboard/auctions">
                  {auctionTimeRemaining <= 0 ? "Auction Closed" : "Join Auction Now"}
                </Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-white/10 rounded-lg p-4 text-center">
                <span className="text-3xl font-bold">{String(countdown.hours).padStart(2, "0")}</span>
                <p className="text-xs text-blue-100 mt-1">Hours</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4 text-center">
                <span className="text-3xl font-bold">{String(countdown.minutes).padStart(2, "0")}</span>
                <p className="text-xs text-blue-100 mt-1">Minutes</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4 text-center">
                <span className="text-3xl font-bold">{String(countdown.seconds).padStart(2, "0")}</span>
                <p className="text-xs text-blue-100 mt-1">Seconds</p>
              </div>
              <div className="bg-orange/20 rounded-lg p-4 text-center">
                <span className="text-3xl font-bold text-orange">35%</span>
                <p className="text-xs text-blue-100 mt-1">Profit</p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <p className="text-sm text-blue-100">
            {isAuctionLive
              ? "Remember to make payment within 7 hours to avoid penalties."
              : "Auction opens at 9:00 AM and 6:30 PM on weekdays, 6:30 PM on Sunday."}
          </p>
        </CardFooter>
      </Card>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Investments</CardTitle>
            <Coins className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₦250,000</div>
            <p className="text-xs text-muted-foreground">+20.1% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Investments</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">2 maturing this week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₦87,500</div>
            <p className="text-xs text-muted-foreground">+35% from investments</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Referral Earnings</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₦12,000</div>
            <p className="text-xs text-muted-foreground">12 active referrals</p>
          </CardContent>
        </Card>
      </div>

      {/* Active Investments */}
      <Card>
        <CardHeader>
          <CardTitle>Active Investments</CardTitle>
          <CardDescription>Your current investments and their maturity status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">7-Day Investment</p>
                  <p className="text-sm text-muted-foreground">₦100,000 • 35% Profit</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-green-600">₦135,000</p>
                  <p className="text-sm text-muted-foreground">Matures in 2 days</p>
                </div>
              </div>
              <Progress value={71} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">14-Day Investment</p>
                  <p className="text-sm text-muted-foreground">₦50,000 • 107% Profit</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-green-600">₦103,500</p>
                  <p className="text-sm text-muted-foreground">Matures in 9 days</p>
                </div>
              </div>
              <Progress value={36} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">21-Day Investment</p>
                  <p className="text-sm text-muted-foreground">₦100,000 • 215% Profit</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-green-600">₦315,000</p>
                  <p className="text-sm text-muted-foreground">Matures in 16 days</p>
                </div>
              </div>
              <Progress value={24} className="h-2" />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full">
            <Link href="/dashboard/investments">View All Investments</Link>
          </Button>
        </CardFooter>
      </Card>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Your recent payment activities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-green-100 p-2 rounded-full">
                  <ArrowUpRight className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="font-medium">Investment Matured</p>
                  <p className="text-sm text-muted-foreground">7-Day Plan</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">+₦35,000</p>
                <p className="text-sm text-muted-foreground">Apr 18, 2025</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Coins className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">Bought Coins</p>
                  <p className="text-sm text-muted-foreground">14-Day Plan</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-red-600">-₦50,000</p>
                <p className="text-sm text-muted-foreground">Apr 15, 2025</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-orange-100 p-2 rounded-full">
                  <Users className="h-4 w-4 text-orange" />
                </div>
                <div>
                  <p className="font-medium">Referral Bonus</p>
                  <p className="text-sm text-muted-foreground">New signup</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">+₦1,000</p>
                <p className="text-sm text-muted-foreground">Apr 12, 2025</p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full">
            <Link href="/dashboard/transactions">View All Transactions</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
