"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Coins, ArrowUpRight, ArrowDownLeft, Clock, CheckCircle, AlertCircle, Eye } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"

export default function WalletPage() {
  const [selectedCoin, setSelectedCoin] = useState<any>(null)
  const [showCoinDetails, setShowCoinDetails] = useState(false)

  // Mock data for wallet
  const walletSummary = {
    totalCoins: 3,
    activeCoinValue: 250000,
    soldCoinsValue: 135000,
    totalProfit: 47500,
    pendingProfit: 82500,
  }

  // Mock data for active coins
  const activeCoins = [
    {
      id: "COIN-001",
      amount: 100000,
      plan: "7-Day Plan",
      purchaseDate: "Apr 15, 2025",
      maturityDate: "Apr 22, 2025",
      expectedProfit: 35000,
      progress: 71,
      daysLeft: 2,
      status: "active",
    },
    {
      id: "COIN-002",
      amount: 50000,
      plan: "14-Day Plan",
      purchaseDate: "Apr 10, 2025",
      maturityDate: "Apr 24, 2025",
      expectedProfit: 53500,
      progress: 36,
      daysLeft: 9,
      status: "active",
    },
    {
      id: "COIN-003",
      amount: 100000,
      plan: "21-Day Plan",
      purchaseDate: "Apr 5, 2025",
      maturityDate: "Apr 26, 2025",
      expectedProfit: 215000,
      progress: 24,
      daysLeft: 16,
      status: "active",
    },
  ]

  // Mock data for sold coins
  const soldCoins = [
    {
      id: "COIN-004",
      amount: 50000,
      plan: "7-Day Plan",
      purchaseDate: "Apr 1, 2025",
      soldDate: "Apr 8, 2025",
      profit: 17500,
      status: "sold",
    },
    {
      id: "COIN-005",
      amount: 25000,
      plan: "14-Day Plan",
      purchaseDate: "Mar 15, 2025",
      soldDate: "Mar 29, 2025",
      profit: 26750,
      status: "sold",
    },
    {
      id: "COIN-006",
      amount: 60000,
      plan: "7-Day Plan",
      purchaseDate: "Mar 10, 2025",
      soldDate: "Mar 17, 2025",
      profit: 21000,
      status: "sold",
    },
  ]

  // View coin details
  const viewCoinDetails = (coin: any) => {
    setSelectedCoin(coin)
    setShowCoinDetails(true)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My Wallet</h1>
        <p className="text-muted-foreground">Manage your coins and track your investments</p>
      </div>

      {/* Wallet Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-blue-50 border-blue-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-700">Total Coins</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Coins className="h-5 w-5 text-blue-600 mr-2" />
              <div className="text-2xl font-bold text-blue-700">{walletSummary.totalCoins}</div>
            </div>
            <p className="text-xs text-blue-600 mt-1">Active coins in your wallet</p>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Active Coin Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <ArrowUpRight className="h-5 w-5 text-green-600 mr-2" />
              <div className="text-2xl font-bold text-green-700">₦{walletSummary.activeCoinValue.toLocaleString()}</div>
            </div>
            <p className="text-xs text-green-600 mt-1">Total value of active coins</p>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 border-purple-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">Sold Coins Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <ArrowDownLeft className="h-5 w-5 text-purple-600 mr-2" />
              <div className="text-2xl font-bold text-purple-700">₦{walletSummary.soldCoinsValue.toLocaleString()}</div>
            </div>
            <p className="text-xs text-purple-600 mt-1">Total value of sold coins</p>
          </CardContent>
        </Card>

        <Card className="bg-orange-50 border-orange-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-orange-700">Total Profit</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-orange-600 mr-2" />
              <div className="text-2xl font-bold text-orange-700">₦{walletSummary.totalProfit.toLocaleString()}</div>
            </div>
            <p className="text-xs text-orange-600 mt-1">
              ₦{walletSummary.pendingProfit.toLocaleString()} pending profit
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Coins Tabs */}
      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active">Active Coins</TabsTrigger>
          <TabsTrigger value="sold">Sold Coins</TabsTrigger>
        </TabsList>

        {/* Active Coins Tab */}
        <TabsContent value="active" className="space-y-4">
          {activeCoins.length > 0 ? (
            activeCoins.map((coin) => (
              <Card key={coin.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center">
                        <Coins className="h-5 w-5 text-blue-600 mr-2" />
                        {coin.plan} - {coin.id}
                      </CardTitle>
                      <CardDescription>Purchased on {coin.purchaseDate}</CardDescription>
                    </div>
                    <Badge className="bg-blue-600">Active</Badge>
                  </div>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Investment Amount</p>
                      <p className="text-lg font-semibold">₦{coin.amount.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Expected Profit</p>
                      <p className="text-lg font-semibold text-green-600">₦{coin.expectedProfit.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Maturity Date</p>
                      <p className="text-lg font-semibold">{coin.maturityDate}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Total Return</p>
                      <p className="text-lg font-semibold text-green-600">
                        ₦{(coin.amount + coin.expectedProfit).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 text-blue-600 mr-2" />
                        <span className="text-sm font-medium">{coin.daysLeft} days left until maturity</span>
                      </div>
                      <span className="text-sm font-medium">{coin.progress}%</span>
                    </div>
                    <Progress value={coin.progress} className="h-2" />
                  </div>
                </CardContent>
                <CardFooter className="bg-gray-50 border-t px-6 py-3">
                  <Button variant="outline" className="ml-auto" onClick={() => viewCoinDetails(coin)}>
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </CardFooter>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-10 text-center">
                <div className="rounded-full bg-blue-100 p-3 mb-4">
                  <Coins className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">No Active Coins</h3>
                <p className="text-muted-foreground mb-4">You don't have any active coins in your wallet</p>
                <Button asChild className="bg-blue-600 hover:bg-blue-700">
                  <a href="/dashboard/auctions">Buy Coins</a>
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Sold Coins Tab */}
        <TabsContent value="sold" className="space-y-4">
          {soldCoins.length > 0 ? (
            soldCoins.map((coin) => (
              <Card key={coin.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center">
                        <Coins className="h-5 w-5 text-green-600 mr-2" />
                        {coin.plan} - {coin.id}
                      </CardTitle>
                      <CardDescription>
                        Purchased on {coin.purchaseDate} • Sold on {coin.soldDate}
                      </CardDescription>
                    </div>
                    <Badge className="bg-green-600">Sold</Badge>
                  </div>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Investment Amount</p>
                      <p className="text-lg font-semibold">₦{coin.amount.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Profit Earned</p>
                      <p className="text-lg font-semibold text-green-600">₦{coin.profit.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Total Return</p>
                      <p className="text-lg font-semibold text-green-600">
                        ₦{(coin.amount + coin.profit).toLocaleString()}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">ROI</p>
                      <p className="text-lg font-semibold text-green-600">
                        {Math.round((coin.profit / coin.amount) * 100)}%
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-gray-50 border-t px-6 py-3">
                  <Button variant="outline" className="ml-auto" onClick={() => viewCoinDetails(coin)}>
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </CardFooter>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-10 text-center">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <AlertCircle className="h-6 w-6 text-gray-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">No Sold Coins</h3>
                <p className="text-muted-foreground mb-4">You haven't sold any coins yet</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Coin Details Dialog */}
      <Dialog open={showCoinDetails} onOpenChange={setShowCoinDetails}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Coin Details</DialogTitle>
            <DialogDescription>
              {selectedCoin?.status === "active"
                ? "Details about your active coin investment"
                : "Details about your sold coin"}
            </DialogDescription>
          </DialogHeader>

          {selectedCoin && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold">{selectedCoin.id}</h3>
                  <Badge className={selectedCoin.status === "active" ? "bg-blue-600" : "bg-green-600"}>
                    {selectedCoin.status === "active" ? "Active" : "Sold"}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{selectedCoin.plan}</p>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <p className="text-muted-foreground">Purchase Date:</p>
                  <p className="font-medium">{selectedCoin.purchaseDate}</p>

                  {selectedCoin.status === "active" ? (
                    <>
                      <p className="text-muted-foreground">Maturity Date:</p>
                      <p className="font-medium">{selectedCoin.maturityDate}</p>

                      <p className="text-muted-foreground">Days Left:</p>
                      <p className="font-medium">{selectedCoin.daysLeft} days</p>
                    </>
                  ) : (
                    <>
                      <p className="text-muted-foreground">Sold Date:</p>
                      <p className="font-medium">{selectedCoin.soldDate}</p>

                      <p className="text-muted-foreground">Holding Period:</p>
                      <p className="font-medium">{selectedCoin.plan.split("-")[0].trim()} days</p>
                    </>
                  )}

                  <p className="text-muted-foreground">Investment Amount:</p>
                  <p className="font-medium">₦{selectedCoin.amount.toLocaleString()}</p>

                  {selectedCoin.status === "active" ? (
                    <>
                      <p className="text-muted-foreground">Expected Profit:</p>
                      <p className="font-medium text-green-600">₦{selectedCoin.expectedProfit.toLocaleString()}</p>

                      <p className="text-muted-foreground">Expected Return:</p>
                      <p className="font-medium text-green-600">
                        ₦{(selectedCoin.amount + selectedCoin.expectedProfit).toLocaleString()}
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-muted-foreground">Profit Earned:</p>
                      <p className="font-medium text-green-600">₦{selectedCoin.profit.toLocaleString()}</p>

                      <p className="text-muted-foreground">Total Return:</p>
                      <p className="font-medium text-green-600">
                        ₦{(selectedCoin.amount + selectedCoin.profit).toLocaleString()}
                      </p>

                      <p className="text-muted-foreground">ROI:</p>
                      <p className="font-medium text-green-600">
                        {Math.round((selectedCoin.profit / selectedCoin.amount) * 100)}%
                      </p>
                    </>
                  )}
                </div>

                {selectedCoin.status === "active" && (
                  <div className="pt-2">
                    <p className="text-sm font-medium mb-1">Maturity Progress</p>
                    <Progress value={selectedCoin.progress} className="h-2 mb-1" />
                    <p className="text-xs text-right text-muted-foreground">{selectedCoin.progress}% complete</p>
                  </div>
                )}
              </div>

              {selectedCoin.status === "active" && (
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <div className="flex items-start">
                    <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5 mr-2" />
                    <p className="text-sm text-blue-700">
                      This coin will mature on {selectedCoin.maturityDate}. After maturity, you can sell it to earn your
                      profit.
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setShowCoinDetails(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
