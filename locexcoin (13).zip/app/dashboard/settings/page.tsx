"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { User, Lock, Bell, Shield, CreditCard, Phone, Save, Edit } from "lucide-react"

// Nigerian banks list including mobile money operators
const nigerianBanks = [
  // Commercial Banks
  "Access Bank",
  "Citibank",
  "Ecobank",
  "Fidelity Bank",
  "First Bank of Nigeria",
  "First City Monument Bank",
  "Guaranty Trust Bank",
  "Heritage Bank",
  "Keystone Bank",
  "Polaris Bank",
  "Stanbic IBTC Bank",
  "Standard Chartered Bank",
  "Sterling Bank",
  "Union Bank of Nigeria",
  "United Bank for Africa",
  "Unity Bank",
  "Wema Bank",
  "Zenith Bank",

  // Microfinance Banks
  "AB Microfinance Bank",
  "Accion Microfinance Bank",
  "Addosser Microfinance Bank",
  "Advans La Fayette Microfinance Bank",
  "Baobab Microfinance Bank",
  "Boctrust Microfinance Bank",
  "Busack Microfinance Bank",
  "CEMCS Microfinance Bank",
  "Credit Afrique Microfinance Bank",
  "Daylight Microfinance Bank",
  "Empire Trust Microfinance Bank",
  "FAST Microfinance Bank",
  "Fina Trust Microfinance Bank",
  "Finca Microfinance Bank",
  "FIMS Microfinance Bank",
  "Fortis Microfinance Bank",
  "Fullrange Microfinance Bank",
  "Gashua Microfinance Bank",
  "Hasal Microfinance Bank",
  "Infinity Microfinance Bank",
  "Lapo Microfinance Bank",
  "Lovonus Microfinance Bank",
  "Mainstreet Microfinance Bank",
  "Mutual Trust Microfinance Bank",
  "NPF Microfinance Bank",
  "Page Microfinance Bank",
  "Parallex Microfinance Bank",
  "Petra Microfinance Bank",
  "Seed Capital Microfinance Bank",
  "Sparkle Microfinance Bank",
  "Trustfund Microfinance Bank",
  "VFD Microfinance Bank",

  // Mobile Money Operators
  "9Mobile 9Pay",
  "Airtel Money",
  "Carbon",
  "Chipper Cash",
  "Flutterwave",
  "Globus Bank Mobile Money",
  "Glo Mobile Money",
  "Kuda Bank",
  "Moniepoint",
  "MTN MoMo PSB",
  "OPay",
  "PalmPay",
  "Paga",
  "Paycom (OPay)",
  "Pocket Moni",
  "Sparkle",
  "TeasyMobile",
  "VFD Microfinance Bank",
  "Wallet Africa",
]

export default function SettingsPage() {
  const { toast } = useToast()

  // Mock user data
  const [userData, setUserData] = useState({
    fullName: "John Doe",
    email: "john@example.com",
    phone: "+2348012345678",
    address: "123 Main Street, Lagos, Nigeria",
    bankName: "Guaranty Trust Bank",
    accountNumber: "0123456789",
    accountName: "John Doe",
    referralCode: "JOHN123",
  })

  // State for editing sections
  const [isEditingPersonal, setIsEditingPersonal] = useState(false)
  const [isEditingContact, setIsEditingContact] = useState(false)
  const [isEditingBank, setIsEditingBank] = useState(false)

  // Form data states
  const [personalInfo, setPersonalInfo] = useState({
    fullName: userData.fullName,
    address: userData.address,
  })

  const [contactInfo, setContactInfo] = useState({
    email: userData.email,
    phone: userData.phone,
  })

  const [bankInfo, setBankInfo] = useState({
    bankName: userData.bankName,
    accountNumber: userData.accountNumber,
    accountName: userData.accountName,
  })

  // Password change state
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: true,
    auctionAlerts: true,
    investmentUpdates: true,
    marketingEmails: false,
  })

  // Handle form changes
  const handlePersonalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPersonalInfo((prev) => ({ ...prev, [name]: value }))
  }

  const handleContactChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setContactInfo((prev) => ({ ...prev, [name]: value }))
  }

  const handleBankChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setBankInfo((prev) => ({ ...prev, [name]: value }))
  }

  const handleBankNameChange = (value: string) => {
    setBankInfo((prev) => ({ ...prev, bankName: value }))
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPasswordData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNotificationChange = (name: string, checked: boolean) => {
    setNotificationSettings((prev) => ({ ...prev, [name]: checked }))
  }

  // Save functions
  const savePersonalInfo = () => {
    setUserData((prev) => ({
      ...prev,
      fullName: personalInfo.fullName,
      address: personalInfo.address,
    }))
    setIsEditingPersonal(false)
    toast({
      title: "Success",
      description: "Personal information updated successfully",
    })
  }

  const saveContactInfo = () => {
    setUserData((prev) => ({
      ...prev,
      email: contactInfo.email,
      phone: contactInfo.phone,
    }))
    setIsEditingContact(false)
    toast({
      title: "Success",
      description: "Contact information updated successfully",
    })
  }

  const saveBankInfo = () => {
    setUserData((prev) => ({
      ...prev,
      bankName: bankInfo.bankName,
      accountNumber: bankInfo.accountNumber,
      accountName: bankInfo.accountName,
    }))
    setIsEditingBank(false)
    toast({
      title: "Success",
      description: "Bank information updated successfully",
    })
  }

  const savePassword = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate password
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "Please fill all password fields",
        variant: "destructive",
      })
      return
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match",
        variant: "destructive",
      })
      return
    }

    // Reset password fields
    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })

    toast({
      title: "Success",
      description: "Password changed successfully",
    })
  }

  const saveNotificationSettings = () => {
    toast({
      title: "Success",
      description: "Notification preferences updated successfully",
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences</p>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-4">
          {/* Personal Information */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 text-blue-600 mr-2" />
                  Personal Information
                </CardTitle>
                <CardDescription>Update your personal details</CardDescription>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  if (isEditingPersonal) {
                    savePersonalInfo()
                  } else {
                    setIsEditingPersonal(true)
                  }
                }}
              >
                {isEditingPersonal ? <Save className="h-4 w-4" /> : <Edit className="h-4 w-4" />}
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  name="fullName"
                  value={isEditingPersonal ? personalInfo.fullName : userData.fullName}
                  onChange={handlePersonalChange}
                  readOnly={!isEditingPersonal}
                  className={!isEditingPersonal ? "bg-gray-50" : ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  name="address"
                  value={isEditingPersonal ? personalInfo.address : userData.address}
                  onChange={handlePersonalChange}
                  readOnly={!isEditingPersonal}
                  className={!isEditingPersonal ? "bg-gray-50" : ""}
                />
              </div>
            </CardContent>
            {isEditingPersonal && (
              <CardFooter>
                <div className="flex gap-2 ml-auto">
                  <Button variant="outline" onClick={() => setIsEditingPersonal(false)}>
                    Cancel
                  </Button>
                  <Button onClick={savePersonalInfo} className="bg-blue-600 hover:bg-blue-700">
                    Save Changes
                  </Button>
                </div>
              </CardFooter>
            )}
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="flex items-center">
                  <Phone className="h-5 w-5 text-blue-600 mr-2" />
                  Contact Information
                </CardTitle>
                <CardDescription>Update your contact details</CardDescription>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  if (isEditingContact) {
                    saveContactInfo()
                  } else {
                    setIsEditingContact(true)
                  }
                }}
              >
                {isEditingContact ? <Save className="h-4 w-4" /> : <Edit className="h-4 w-4" />}
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={isEditingContact ? contactInfo.email : userData.email}
                  onChange={handleContactChange}
                  readOnly={!isEditingContact}
                  className={!isEditingContact ? "bg-gray-50" : ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={isEditingContact ? contactInfo.phone : userData.phone}
                  onChange={handleContactChange}
                  readOnly={!isEditingContact}
                  className={!isEditingContact ? "bg-gray-50" : ""}
                />
              </div>
            </CardContent>
            {isEditingContact && (
              <CardFooter>
                <div className="flex gap-2 ml-auto">
                  <Button variant="outline" onClick={() => setIsEditingContact(false)}>
                    Cancel
                  </Button>
                  <Button onClick={saveContactInfo} className="bg-blue-600 hover:bg-blue-700">
                    Save Changes
                  </Button>
                </div>
              </CardFooter>
            )}
          </Card>

          {/* Bank Information */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="flex items-center">
                  <CreditCard className="h-5 w-5 text-blue-600 mr-2" />
                  Bank Information
                </CardTitle>
                <CardDescription>Update your bank account details</CardDescription>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  if (isEditingBank) {
                    saveBankInfo()
                  } else {
                    setIsEditingBank(true)
                  }
                }}
              >
                {isEditingBank ? <Save className="h-4 w-4" /> : <Edit className="h-4 w-4" />}
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="bankName">Bank Name or Mobile Money Operator</Label>
                {isEditingBank ? (
                  <Select value={bankInfo.bankName} onValueChange={handleBankNameChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your bank or mobile money operator" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="category-header-commercial" disabled>
                        --- Commercial Banks ---
                      </SelectItem>
                      {nigerianBanks.slice(0, 18).map((bank) => (
                        <SelectItem key={bank} value={bank}>
                          {bank}
                        </SelectItem>
                      ))}

                      <SelectItem value="category-header-microfinance" disabled>
                        --- Microfinance Banks ---
                      </SelectItem>
                      {nigerianBanks.slice(18, 50).map((bank) => (
                        <SelectItem key={bank} value={bank}>
                          {bank}
                        </SelectItem>
                      ))}

                      <SelectItem value="category-header-mobile" disabled>
                        --- Mobile Money Operators ---
                      </SelectItem>
                      {nigerianBanks.slice(50).map((bank) => (
                        <SelectItem key={bank} value={bank}>
                          {bank}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input value={userData.bankName} readOnly className="bg-gray-50" />
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountNumber">Account Number</Label>
                <Input
                  id="accountNumber"
                  name="accountNumber"
                  value={isEditingBank ? bankInfo.accountNumber : userData.accountNumber}
                  onChange={handleBankChange}
                  readOnly={!isEditingBank}
                  className={!isEditingBank ? "bg-gray-50" : ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountName">Account Name</Label>
                <Input
                  id="accountName"
                  name="accountName"
                  value={isEditingBank ? bankInfo.accountName : userData.accountName}
                  onChange={handleBankChange}
                  readOnly={!isEditingBank}
                  className={!isEditingBank ? "bg-gray-50" : ""}
                />
              </div>
            </CardContent>
            {isEditingBank && (
              <CardFooter>
                <div className="flex gap-2 ml-auto">
                  <Button variant="outline" onClick={() => setIsEditingBank(false)}>
                    Cancel
                  </Button>
                  <Button onClick={saveBankInfo} className="bg-blue-600 hover:bg-blue-700">
                    Save Changes
                  </Button>
                </div>
              </CardFooter>
            )}
          </Card>
        </TabsContent>

        {/* Account Tab */}
        <TabsContent value="account" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 text-blue-600 mr-2" />
                Account Information
              </CardTitle>
              <CardDescription>View your account details and referral code</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Referral Code</Label>
                <div className="flex">
                  <Input value={userData.referralCode} readOnly className="bg-gray-50" />
                  <Button
                    variant="outline"
                    className="ml-2"
                    onClick={() => {
                      navigator.clipboard.writeText(userData.referralCode)
                      toast({
                        title: "Copied!",
                        description: "Referral code copied to clipboard",
                      })
                    }}
                  >
                    Copy
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">Share this code with friends to earn referral bonuses</p>
              </div>

              <div className="space-y-2">
                <Label>Referral Link</Label>
                <div className="flex">
                  <Input
                    value={`https://locexcoin.com/register?ref=${userData.referralCode}`}
                    readOnly
                    className="bg-gray-50"
                  />
                  <Button
                    variant="outline"
                    className="ml-2"
                    onClick={() => {
                      navigator.clipboard.writeText(`https://locexcoin.com/register?ref=${userData.referralCode}`)
                      toast({
                        title: "Copied!",
                        description: "Referral link copied to clipboard",
                      })
                    }}
                  >
                    Copy
                  </Button>
                </div>
              </div>

              <div className="pt-4">
                <h3 className="font-medium mb-2">Account Status</h3>
                <div className="bg-green-50 p-3 rounded-lg border border-green-100">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-green-600 mr-2" />
                    <div>
                      <p className="font-medium text-green-700">Your account is in good standing</p>
                      <p className="text-sm text-green-600">Email verified • Phone verified • KYC completed</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-red-600 flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Danger Zone
              </CardTitle>
              <CardDescription>Irreversible account actions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border border-red-200 rounded-lg p-4">
                <h3 className="font-medium text-red-600 mb-2">Deactivate Account</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Temporarily deactivate your account. You can reactivate it at any time by logging in.
                </p>
                <Button variant="outline" className="text-red-600 border-red-200 hover:bg-red-50">
                  Deactivate Account
                </Button>
              </div>

              <div className="border border-red-200 rounded-lg p-4">
                <h3 className="font-medium text-red-600 mb-2">Delete Account</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Permanently delete your account and all associated data. This action cannot be undone.
                </p>
                <Button variant="destructive">Delete Account</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="h-5 w-5 text-blue-600 mr-2" />
                Notification Preferences
              </CardTitle>
              <CardDescription>Manage how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="emailNotifications">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                  </div>
                  <Switch
                    id="emailNotifications"
                    checked={notificationSettings.emailNotifications}
                    onCheckedChange={(checked) => handleNotificationChange("emailNotifications", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="smsNotifications">SMS Notifications</Label>
                    <p className="text-sm text-muted-foreground">Receive notifications via SMS</p>
                  </div>
                  <Switch
                    id="smsNotifications"
                    checked={notificationSettings.smsNotifications}
                    onCheckedChange={(checked) => handleNotificationChange("smsNotifications", checked)}
                  />
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="text-sm font-medium mb-3">Notification Types</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="auctionAlerts">Auction Alerts</Label>
                      <p className="text-sm text-muted-foreground">Get notified when auctions are about to start</p>
                    </div>
                    <Switch
                      id="auctionAlerts"
                      checked={notificationSettings.auctionAlerts}
                      onCheckedChange={(checked) => handleNotificationChange("auctionAlerts", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="investmentUpdates">Investment Updates</Label>
                      <p className="text-sm text-muted-foreground">Get notified about your investment status</p>
                    </div>
                    <Switch
                      id="investmentUpdates"
                      checked={notificationSettings.investmentUpdates}
                      onCheckedChange={(checked) => handleNotificationChange("investmentUpdates", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="marketingEmails">Marketing Emails</Label>
                      <p className="text-sm text-muted-foreground">Receive promotional offers and updates</p>
                    </div>
                    <Switch
                      id="marketingEmails"
                      checked={notificationSettings.marketingEmails}
                      onCheckedChange={(checked) => handleNotificationChange("marketingEmails", checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveNotificationSettings} className="ml-auto bg-blue-600 hover:bg-blue-700">
                Save Preferences
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lock className="h-5 w-5 text-blue-600 mr-2" />
                Change Password
              </CardTitle>
              <CardDescription>Update your password to keep your account secure</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={savePassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Current Password</Label>
                  <Input
                    id="currentPassword"
                    name="currentPassword"
                    type="password"
                    value={passwordData.currentPassword}
                    onChange={handlePasswordChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input
                    id="newPassword"
                    name="newPassword"
                    type="password"
                    value={passwordData.newPassword}
                    onChange={handlePasswordChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={handlePasswordChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                  <Lock className="mr-2 h-4 w-4" />
                  Change Password
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 text-blue-600 mr-2" />
                Security Settings
              </CardTitle>
              <CardDescription>Additional security settings for your account</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="text-sm font-medium">Two-Factor Authentication</h4>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                </div>
                <Button variant="outline">Enable</Button>
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="text-sm font-medium">Login Notifications</h4>
                  <p className="text-sm text-muted-foreground">Get notified when someone logs into your account</p>
                </div>
                <Button variant="outline">Enable</Button>
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="text-sm font-medium">Transaction PIN</h4>
                  <p className="text-sm text-muted-foreground">Set a PIN for authorizing transactions</p>
                </div>
                <Button variant="outline">Set PIN</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
