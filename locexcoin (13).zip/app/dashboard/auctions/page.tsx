"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { Clock, Coins, AlertTriangle, Timer, Upload, Eye } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function AuctionsPage() {
  const { toast } = useToast()
  const [countdown, setCountdown] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0,
  })
  const [isAuctionLive, setIsAuctionLive] = useState(false)
  const [auctionTimeRemaining, setAuctionTimeRemaining] = useState(300) // 5 minutes in seconds
  const [selectedPlan, setSelectedPlan] = useState("7")
  const [investmentAmount, setInvestmentAmount] = useState("")
  const [profitAmount, setProfitAmount] = useState(0)
  const [auctionStartTime, setAuctionStartTime] = useState<Date | null>(null)
  const [isMatched, setIsMatched] = useState(false)
  const [sellerDetails, setSellerDetails] = useState<{
    bankName: string
    accountNumber: string
    accountName: string
    phoneNumber: string
    amountToPay: number
  } | null>(null)

  const [isUploading, setIsUploading] = useState(false)
  const [proofUploaded, setProofUploaded] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [proofImageUrl, setProofImageUrl] = useState<string | null>(null)

  // Calculate profit based on selected plan and investment amount
  useEffect(() => {
    const amount = Number.parseFloat(investmentAmount) || 0
    let profit = 0

    if (selectedPlan === "7") {
      profit = amount * 0.35
    } else if (selectedPlan === "14") {
      profit = amount * 1.07
    } else if (selectedPlan === "21") {
      profit = amount * 2.15
    }

    setProfitAmount(profit)
  }, [selectedPlan, investmentAmount])

  // Function to check if auction is live based on West Central Africa Time (UTC+01:00)
  const checkIfAuctionIsLive = () => {
    // Get current time in West Central Africa Time (UTC+01:00)
    const now = new Date()
    const options = { timeZone: "Africa/Lagos" }
    const wcatTime = new Date(now.toLocaleString("en-US", options))

    const hours = wcatTime.getHours()
    const minutes = wcatTime.getMinutes()
    const day = wcatTime.getDay() // 0 is Sunday, 1 is Monday, etc.

    // Auction times: 9:00 AM and 6:30 PM on weekdays, 6:30 PM on Sunday
    const isWeekday = day >= 1 && day <= 6 // Monday to Saturday
    const isSunday = day === 0

    // Check if current time matches auction times
    const isMorningAuction = isWeekday && hours === 9 && minutes >= 0 && minutes < 30
    const isEveningAuction = (isWeekday || isSunday) && hours === 18 && minutes >= 30 && minutes < 59

    return isMorningAuction || isEveningAuction
  }

  // Function to calculate time until next auction
  const calculateTimeUntilNextAuction = () => {
    // Get current time in West Central Africa Time (UTC+01:00)
    const now = new Date()
    const options = { timeZone: "Africa/Lagos" }
    const wcatTime = new Date(now.toLocaleString("en-US", options))

    const hours = wcatTime.getHours()
    const minutes = wcatTime.getMinutes()
    const day = wcatTime.getDay() // 0 is Sunday, 1 is Monday, etc.

    const nextAuctionTime = new Date(wcatTime)

    // Set next auction time based on current time
    if (day === 0) {
      // Sunday
      if (hours < 18 || (hours === 18 && minutes < 30)) {
        // Next auction is today at 6:30 PM
        nextAuctionTime.setHours(18, 30, 0, 0)
      } else {
        // Next auction is Monday at 9:00 AM
        nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
        nextAuctionTime.setHours(9, 0, 0, 0)
      }
    } else if (day >= 1 && day <= 5) {
      // Monday to Friday
      if (hours < 9) {
        // Next auction is today at 9:00 AM
        nextAuctionTime.setHours(9, 0, 0, 0)
      } else if ((hours === 9 && minutes >= 30) || hours > 9) {
        if (hours < 18 || (hours === 18 && minutes < 30)) {
          // Next auction is today at 6:30 PM
          nextAuctionTime.setHours(18, 30, 0, 0)
        } else {
          // Next auction is tomorrow at 9:00 AM
          nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
          nextAuctionTime.setHours(9, 0, 0, 0)
        }
      }
    } else if (day === 6) {
      // Saturday
      if (hours < 9) {
        // Next auction is today at 9:00 AM
        nextAuctionTime.setHours(9, 0, 0, 0)
      } else if ((hours === 9 && minutes >= 30) || hours > 9) {
        if (hours < 18 || (hours === 18 && minutes < 30)) {
          // Next auction is today at 6:30 PM
          nextAuctionTime.setHours(18, 30, 0, 0)
        } else {
          // Next auction is Sunday at 6:30 PM
          nextAuctionTime.setDate(nextAuctionTime.getDate() + 1)
          nextAuctionTime.setHours(18, 30, 0, 0)
        }
      }
    }

    // Calculate time difference in milliseconds
    const timeDiff = nextAuctionTime.getTime() - wcatTime.getTime()

    // Convert to hours, minutes, seconds
    const hoursUntil = Math.floor(timeDiff / (1000 * 60 * 60))
    const minutesUntil = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60))
    const secondsUntil = Math.floor((timeDiff % (1000 * 60)) / 1000)

    return {
      hours: hoursUntil,
      minutes: minutesUntil,
      seconds: secondsUntil,
    }
  }

  // Simulate countdown timer
  useEffect(() => {
    // Check if auction is currently live
    const auctionLiveStatus = checkIfAuctionIsLive()

    // If auction just became live, set the start time
    if (auctionLiveStatus && !isAuctionLive) {
      setAuctionStartTime(new Date())
      setAuctionTimeRemaining(300) // Reset to 5 minutes (300 seconds)
    }

    setIsAuctionLive(auctionLiveStatus)

    // If auction is not live, start countdown to next auction
    if (!auctionLiveStatus) {
      const timeUntilNextAuction = calculateTimeUntilNextAuction()
      setCountdown(timeUntilNextAuction)
    }

    const interval = setInterval(() => {
      // Check if auction is live
      const auctionLiveStatus = checkIfAuctionIsLive()

      // If auction is live, count down the 5-minute window
      if (auctionLiveStatus) {
        if (auctionTimeRemaining > 0) {
          setAuctionTimeRemaining((prev) => prev - 1)
        } else {
          // Auction has ended after 5 minutes or countdown reached zero
          setIsAuctionLive(false)
          setAuctionStartTime(null)
          const timeUntilNextAuction = calculateTimeUntilNextAuction()
          setCountdown(timeUntilNextAuction)

          toast({
            title: "Auction Closed",
            description: "The auction has closed. Next auction will open at the scheduled time.",
          })
        }
      } else {
        // If auction is not live, update countdown to next auction
        setCountdown((prev) => {
          if (prev.seconds > 0) {
            return { ...prev, seconds: prev.seconds - 1 }
          } else if (prev.minutes > 0) {
            return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
          } else if (prev.hours > 0) {
            return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
          } else {
            // Time's up, check if auction is now live
            const isNowLive = checkIfAuctionIsLive()
            if (isNowLive) {
              setIsAuctionLive(true)
              setAuctionStartTime(new Date())
              setAuctionTimeRemaining(300) // 5 minutes in seconds

              toast({
                title: "Auction Now Live!",
                description: "The auction is now open. You have 5 minutes to participate.",
              })

              return prev
            } else {
              // Recalculate time until next auction
              return calculateTimeUntilNextAuction()
            }
          }
        })
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [isAuctionLive, auctionTimeRemaining, toast])

  const handleSubmitRequest = () => {
    const amount = Number.parseFloat(investmentAmount)

    if (!amount) {
      toast({
        title: "Error",
        description: "Please enter a valid investment amount",
        variant: "destructive",
      })
      return
    }

    if (amount < 10000) {
      toast({
        title: "Error",
        description: "Minimum investment amount is ₦10,000",
        variant: "destructive",
      })
      return
    }

    if (amount > 1000000) {
      toast({
        title: "Error",
        description: "Maximum investment amount is ₦1,000,000",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Success",
      description: "Your auction request has been submitted successfully!",
    })
  }

  const formatAuctionTimeRemaining = () => {
    if (auctionTimeRemaining <= 0) {
      return "00:00"
    }
    const minutes = Math.floor(auctionTimeRemaining / 60)
    const seconds = auctionTimeRemaining % 60
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`
  }

  const handleJoinAuction = () => {
    toast({
      title: "Success",
      description: "You have joined the auction. Please select a plan and amount to invest.",
    })
  }

  const handleBuyNow = () => {
    const amount = Number.parseFloat(investmentAmount)

    if (!amount) {
      toast({
        title: "Error",
        description: "Please enter a valid investment amount",
        variant: "destructive",
      })
      return
    }

    if (amount < 10000) {
      toast({
        title: "Error",
        description: "Minimum investment amount is ₦10,000",
        variant: "destructive",
      })
      return
    }

    if (amount > 1000000) {
      toast({
        title: "Error",
        description: "Maximum investment amount is ₦1,000,000",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Matching...",
      description: "Finding a seller for your investment...",
    })

    // Simulate matching after 2 seconds
    setTimeout(() => {
      // Mock seller details - in a real app, this would come from your backend
      setSellerDetails({
        bankName: "Guaranty Trust Bank",
        accountNumber: "0123456789",
        accountName: "John Doe",
        phoneNumber: "+234 801 234 5678",
        amountToPay: amount,
      })
      setIsMatched(true)

      toast({
        title: "Matched!",
        description: "You have been matched with a seller. Please make payment within 7 hours.",
      })
    }, 2000)
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])

      // Create a preview URL for the selected file
      const fileUrl = URL.createObjectURL(e.target.files[0])
      setProofImageUrl(fileUrl)
    }
  }

  // Add this function to handle proof upload
  const handleUploadProof = () => {
    if (!selectedFile) {
      toast({
        title: "Error",
        description: "Please select a file to upload",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    // Simulate upload process
    setTimeout(() => {
      setIsUploading(false)
      setProofUploaded(true)

      toast({
        title: "Success",
        description: "Payment proof uploaded successfully!",
      })
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Auctions</h1>
        <p className="text-muted-foreground">Participate in auctions to buy and sell coins</p>
      </div>

      <Tabs defaultValue="buy" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="buy">Buy Coins</TabsTrigger>
          <TabsTrigger value="sell">Sell Coins</TabsTrigger>
        </TabsList>
        <TabsContent value="buy" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Auction Status Card */}
            <Card className={isAuctionLive ? "bg-green-50 border-green-200" : "bg-blue-50 border-blue-200"}>
              <CardHeader>
                <CardTitle className={isAuctionLive ? "text-green-700" : "text-blue-700"}>
                  {isAuctionLive ? "Auction is LIVE!" : "Next Auction"}
                </CardTitle>
                <CardDescription className={isAuctionLive ? "text-green-600" : "text-blue-600"}>
                  {isAuctionLive ? "Auction closes in 5 minutes. Join now!" : "Countdown to the next auction"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isAuctionLive ? (
                  <div className="flex flex-col items-center justify-center py-4">
                    <div className="bg-green-100 p-4 rounded-full mb-4">
                      <Coins className="h-10 w-10 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold text-green-700 mb-2">Auction is now LIVE!</h3>

                    {/* Auction closing countdown */}
                    <div className="flex items-center justify-center mb-4 bg-white rounded-lg px-4 py-2">
                      <Timer className="h-5 w-5 text-red-500 mr-2" />
                      <span
                        className={`text-lg font-bold ${auctionTimeRemaining <= 0 ? "text-gray-500" : "text-red-500"}`}
                      >
                        {auctionTimeRemaining <= 0 ? "Auction Closed" : `Closes in: ${formatAuctionTimeRemaining()}`}
                      </span>
                    </div>

                    <p className="text-green-600 text-center mb-6">
                      First come, first served. Join now to get matched with sellers.
                    </p>
                    <Button
                      onClick={handleJoinAuction}
                      size="lg"
                      disabled={auctionTimeRemaining <= 0}
                      className={`${auctionTimeRemaining <= 0 ? "bg-gray-400" : "bg-green-600 hover:bg-green-700"} text-white`}
                    >
                      {auctionTimeRemaining <= 0 ? "Auction Closed" : "Join Auction Now"}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-3 gap-2">
                      <div className="bg-white rounded-lg p-3 text-center">
                        <span className="text-2xl font-bold text-blue-700">
                          {String(countdown.hours).padStart(2, "0")}
                        </span>
                        <p className="text-xs text-blue-600 mt-1">Hours</p>
                      </div>
                      <div className="bg-white rounded-lg p-3 text-center">
                        <span className="text-2xl font-bold text-blue-700">
                          {String(countdown.minutes).padStart(2, "0")}
                        </span>
                        <p className="text-xs text-blue-600 mt-1">Minutes</p>
                      </div>
                      <div className="bg-white rounded-lg p-3 text-center">
                        <span className="text-2xl font-bold text-blue-700">
                          {String(countdown.seconds).padStart(2, "0")}
                        </span>
                        <p className="text-xs text-blue-600 mt-1">Seconds</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-center">
                      <Clock className="h-5 w-5 text-blue-600 mr-2" />
                      <p className="text-blue-600">Auction opens at 9:00 AM and 6:30 PM (WAT)</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Investment Plan Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Select Investment Plan</CardTitle>
                <CardDescription>Choose a plan and enter the amount you want to invest</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <RadioGroup
                  defaultValue="7"
                  value={selectedPlan}
                  onValueChange={setSelectedPlan}
                  className="grid grid-cols-1 gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="7" id="plan-7" />
                    <Label htmlFor="plan-7" className="flex flex-1 justify-between">
                      <span>7 Days Plan</span>
                      <span className="font-semibold text-green-600">35% Profit</span>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="14" id="plan-14" />
                    <Label htmlFor="plan-14" className="flex flex-1 justify-between">
                      <span>14 Days Plan</span>
                      <span className="font-semibold text-green-600">107% Profit</span>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="21" id="plan-21" />
                    <Label htmlFor="plan-21" className="flex flex-1 justify-between">
                      <span>21 Days Plan</span>
                      <span className="font-semibold text-green-600">215% Profit</span>
                    </Label>
                  </div>
                </RadioGroup>

                <div className="space-y-2">
                  <Label htmlFor="amount">Investment Amount (₦)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter amount (₦10,000 - ₦1,000,000)"
                    value={investmentAmount}
                    onChange={(e) => setInvestmentAmount(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Min: ₦10,000 | Max: ₦1,000,000</p>
                </div>

                {investmentAmount && (
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-medium text-blue-700 mb-2">Investment Summary</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <p className="text-muted-foreground">Investment:</p>
                      <p className="font-medium text-right">₦{Number.parseFloat(investmentAmount).toLocaleString()}</p>

                      <p className="text-muted-foreground">Duration:</p>
                      <p className="font-medium text-right">{selectedPlan} days</p>

                      <p className="text-muted-foreground">Profit:</p>
                      <p className="font-medium text-green-600 text-right">₦{profitAmount.toLocaleString()}</p>

                      <p className="text-muted-foreground">Total Return:</p>
                      <p className="font-medium text-green-600 text-right">
                        ₦{(Number.parseFloat(investmentAmount) + profitAmount).toLocaleString()}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button
                  onClick={isAuctionLive ? handleBuyNow : handleSubmitRequest}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={
                    !isAuctionLive && countdown.hours === 0 && countdown.minutes === 0 && countdown.seconds === 0
                  }
                >
                  {isAuctionLive ? "Buy Now" : "Submit Auction Request"}
                </Button>
              </CardFooter>
            </Card>
            {isMatched && sellerDetails && (
              <Card className="mt-4 border-green-200 bg-green-50">
                <CardHeader>
                  <CardTitle className="text-green-700">Payment Details</CardTitle>
                  <CardDescription className="text-green-600">
                    Make payment to the following account within 7 hours
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-white p-4 rounded-lg space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <p className="text-sm font-medium text-gray-500">Bank Name:</p>
                      <p className="text-sm font-semibold">{sellerDetails.bankName}</p>

                      <p className="text-sm font-medium text-gray-500">Account Number:</p>
                      <p className="text-sm font-semibold">{sellerDetails.accountNumber}</p>

                      <p className="text-sm font-medium text-gray-500">Account Name:</p>
                      <p className="text-sm font-semibold">{sellerDetails.accountName}</p>

                      <p className="text-sm font-medium text-gray-500">Phone Number:</p>
                      <p className="text-sm font-semibold">{sellerDetails.phoneNumber}</p>

                      <p className="text-sm font-medium text-gray-500">Amount to Pay:</p>
                      <p className="text-sm font-semibold text-green-600">
                        ₦{sellerDetails.amountToPay.toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                    <div className="flex items-start">
                      <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-amber-800">Important:</p>
                        <p className="text-sm text-amber-700">
                          After making payment, upload your payment proof in the Transactions section. The seller will
                          confirm your payment and release your coins.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col space-y-3">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        className="w-full bg-blue-600 hover:bg-blue-700 flex items-center"
                        disabled={proofUploaded}
                      >
                        <Upload className="mr-2 h-4 w-4" />
                        {proofUploaded ? "Proof Uploaded ✓" : "Upload Proof of Payment"}
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Upload Payment Proof</DialogTitle>
                        <DialogDescription>
                          Upload a screenshot or receipt of your bank transfer as proof of payment.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="grid w-full max-w-sm items-center gap-1.5">
                          <Label htmlFor="payment-proof">Payment Receipt</Label>
                          <Input id="payment-proof" type="file" accept="image/*" onChange={handleFileSelect} />
                          <p className="text-xs text-muted-foreground">Accepted formats: JPG, PNG, PDF (Max: 5MB)</p>
                        </div>
                        {selectedFile && (
                          <div className="bg-blue-50 p-2 rounded text-sm">Selected file: {selectedFile.name}</div>
                        )}
                      </div>
                      <DialogFooter>
                        <Button
                          onClick={handleUploadProof}
                          disabled={!selectedFile || isUploading}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          {isUploading ? "Uploading..." : "Upload Proof"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  {/* View Payment Proof Button */}
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        className="w-full bg-amber-600 hover:bg-amber-700 flex items-center"
                        disabled={!proofUploaded}
                      >
                        <Eye className="mr-2 h-4 w-4" />
                        View Payment Proof
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Payment Proof</DialogTitle>
                        <DialogDescription>Review the uploaded payment proof.</DialogDescription>
                      </DialogHeader>
                      <div className="py-4">
                        {proofImageUrl ? (
                          <div className="flex flex-col items-center">
                            <img
                              src={proofImageUrl || "/placeholder.svg"}
                              alt="Payment Proof"
                              className="max-w-full max-h-[400px] object-contain border rounded-md"
                            />
                            <p className="text-sm text-muted-foreground mt-2">
                              Uploaded on {new Date().toLocaleString()}
                            </p>
                          </div>
                        ) : (
                          <div className="text-center p-8 bg-gray-100 rounded-md">
                            <AlertTriangle className="h-10 w-10 text-amber-500 mx-auto mb-2" />
                            <p>No payment proof has been uploaded yet.</p>
                          </div>
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button
                    onClick={() => (window.location.href = "/dashboard/transactions")}
                    className={`w-full ${proofUploaded ? "bg-green-600 hover:bg-green-700" : "bg-gray-400"}`}
                    disabled={!proofUploaded}
                  >
                    {proofUploaded ? "Go to Transactions" : "Upload Proof First"}
                  </Button>
                </CardFooter>
              </Card>
            )}
          </div>

          {/* Auction Rules */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-orange mr-2" />
                Auction Rules
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                    1
                  </span>
                  <span>Auction opens twice daily from Monday to Saturday at 9:00 AM and 6:30 PM (WAT).</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                    2
                  </span>
                  <span>Auction opens once on Sunday at 6:30 PM (WAT) only.</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                    3
                  </span>
                  <span>Each auction session lasts for 5 minutes only.</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                    4
                  </span>
                  <span>Minimum investment amount is ₦10,000 and maximum is ₦1,000,000 per auction.</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                    5
                  </span>
                  <span>Buyers must make payment within 7 hours of matching or face a 2% penalty.</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                    6
                  </span>
                  <span>
                    Members must make 100% recurring/recommitment bids on each coin bought before they can withdraw and
                    sell.
                  </span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="sell" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sell Your Coins</CardTitle>
              <CardDescription>List your matured coins for sale in the auction</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <h3 className="font-medium text-amber-800 flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2" />
                  No Matured Coins Available
                </h3>
                <p className="text-amber-700 text-sm mt-2">
                  You don&apos;t have any matured coins to sell at the moment. Coins will appear here when your
                  investments mature.
                </p>
              </div>

              <div className="border rounded-lg divide-y">
                <div className="p-4">
                  <h3 className="font-medium">Selling Process</h3>
                  <ul className="mt-2 space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                        1
                      </span>
                      <span>Wait for your investment to mature based on the selected plan.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                        2
                      </span>
                      <span>Submit your matured coins for sale from this page.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                        3
                      </span>
                      <span>Wait for admin approval before your coins are listed in the auction.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                        4
                      </span>
                      <span>Once approved, your coins will be matched with buyers during auction times.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                        5
                      </span>
                      <span>Confirm payment from buyers to complete the transaction.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button disabled className="w-full">
                No Coins Available to Sell
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
