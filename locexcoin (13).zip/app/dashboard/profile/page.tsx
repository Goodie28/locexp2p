"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { User, Lock, Copy, Edit, Save } from "lucide-react"

// Import the bank list from the registration page
const nigerianBanks = [
  // Commercial Banks
  "Access Bank",
  "Citibank",
  "Ecobank",
  "Fidelity Bank",
  "First Bank of Nigeria",
  "First City Monument Bank",
  "Guaranty Trust Bank",
  "Heritage Bank",
  "Keystone Bank",
  "Polaris Bank",
  "Stanbic IBTC Bank",
  "Standard Chartered Bank",
  "Sterling Bank",
  "Union Bank of Nigeria",
  "United Bank for Africa",
  "Unity Bank",
  "Wema Bank",
  "Zenith Bank",

  // Microfinance Banks
  "AB Microfinance Bank",
  "Accion Microfinance Bank",
  "Addosser Microfinance Bank",
  "Advans La Fayette Microfinance Bank",
  "Baobab Microfinance Bank",
  "Boctrust Microfinance Bank",
  "Busack Microfinance Bank",
  "CEMCS Microfinance Bank",
  "Credit Afrique Microfinance Bank",
  "Daylight Microfinance Bank",
  "Empire Trust Microfinance Bank",
  "FAST Microfinance Bank",
  "Fina Trust Microfinance Bank",
  "Finca Microfinance Bank",
  "FIMS Microfinance Bank",
  "Fortis Microfinance Bank",
  "Fullrange Microfinance Bank",
  "Gashua Microfinance Bank",
  "Hasal Microfinance Bank",
  "Infinity Microfinance Bank",
  "Lapo Microfinance Bank",
  "Lovonus Microfinance Bank",
  "Mainstreet Microfinance Bank",
  "Mutual Trust Microfinance Bank",
  "NPF Microfinance Bank",
  "Page Microfinance Bank",
  "Parallex Microfinance Bank",
  "Petra Microfinance Bank",
  "Seed Capital Microfinance Bank",
  "Sparkle Microfinance Bank",
  "Trustfund Microfinance Bank",
  "VFD Microfinance Bank",
]

export default function ProfilePage() {
  const { toast } = useToast()

  // Mock user data - in a real app, this would come from an API or context
  const [userData, setUserData] = useState({
    fullName: "John Doe",
    email: "john@example.com",
    phone: "+2348012345678",
    bankName: "Guaranty Trust Bank",
    accountNumber: "0123456789",
    accountName: "John Doe",
    referralCode: "JOHN123",
    referralLink: "https://locexcoin.com/register?ref=JOHN123",
    joinedDate: "April 15, 2025",
    totalInvestments: 3,
    totalEarnings: "₦87,500",
  })

  // State for editing personal information
  const [isEditingPersonal, setIsEditingPersonal] = useState(false)
  const [personalInfo, setPersonalInfo] = useState({
    fullName: userData.fullName,
    email: userData.email,
    phone: userData.phone,
  })

  // State for editing bank information
  const [isEditingBank, setIsEditingBank] = useState(false)
  const [bankInfo, setBankInfo] = useState({
    bankName: userData.bankName,
    accountNumber: userData.accountNumber,
    accountName: userData.accountName,
  })

  // State for changing password
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  // Handle personal info changes
  const handlePersonalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPersonalInfo((prev) => ({ ...prev, [name]: value }))
  }

  // Handle bank info changes
  const handleBankChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setBankInfo((prev) => ({ ...prev, [name]: value }))
  }

  // Handle bank name selection
  const handleBankNameChange = (value: string) => {
    setBankInfo((prev) => ({ ...prev, bankName: value }))
  }

  // Handle password changes
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPasswordData((prev) => ({ ...prev, [name]: value }))
  }

  // Save personal information
  const savePersonalInfo = () => {
    setUserData((prev) => ({
      ...prev,
      fullName: personalInfo.fullName,
      email: personalInfo.email,
      phone: personalInfo.phone,
    }))
    setIsEditingPersonal(false)
    toast({
      title: "Success",
      description: "Personal information updated successfully",
    })
  }

  // Save bank information
  const saveBankInfo = () => {
    setUserData((prev) => ({
      ...prev,
      bankName: bankInfo.bankName,
      accountNumber: bankInfo.accountNumber,
      accountName: bankInfo.accountName,
    }))
    setIsEditingBank(false)
    toast({
      title: "Success",
      description: "Bank information updated successfully",
    })
  }

  // Change password
  const changePassword = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate password
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "Please fill all password fields",
        variant: "destructive",
      })
      return
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match",
        variant: "destructive",
      })
      return
    }

    // Reset password fields
    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })

    toast({
      title: "Success",
      description: "Password changed successfully",
    })
  }

  // Copy referral link
  const copyReferralLink = () => {
    navigator.clipboard.writeText(userData.referralLink)
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My Profile</h1>
        <p className="text-muted-foreground">View and manage your account information</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Summary Card */}
        <Card>
          <CardHeader>
            <CardTitle>Profile Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center">
              <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <User className="h-12 w-12 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold">{userData.fullName}</h2>
              <p className="text-muted-foreground">Member since {userData.joinedDate}</p>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Investments:</span>
                <span className="font-medium">{userData.totalInvestments}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Earnings:</span>
                <span className="font-medium text-green-600">{userData.totalEarnings}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Referral Code:</span>
                <span className="font-medium">{userData.referralCode}</span>
              </div>
            </div>

            <div className="pt-2">
              <div className="relative">
                <Input value={userData.referralLink} readOnly className="pr-10" />
                <Button size="icon" variant="ghost" className="absolute right-0 top-0" onClick={copyReferralLink}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Share this link to earn referral bonuses</p>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="md:col-span-2">
          <Tabs defaultValue="personal" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="personal">Personal Info</TabsTrigger>
              <TabsTrigger value="bank">Bank Details</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
            </TabsList>

            {/* Personal Information Tab */}
            <TabsContent value="personal" className="space-y-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0">
                  <div>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>Manage your personal details</CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      if (isEditingPersonal) {
                        savePersonalInfo()
                      } else {
                        setIsEditingPersonal(true)
                      }
                    }}
                  >
                    {isEditingPersonal ? <Save className="h-4 w-4" /> : <Edit className="h-4 w-4" />}
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={isEditingPersonal ? personalInfo.fullName : userData.fullName}
                      onChange={handlePersonalChange}
                      readOnly={!isEditingPersonal}
                      className={!isEditingPersonal ? "bg-gray-50" : ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={isEditingPersonal ? personalInfo.email : userData.email}
                      onChange={handlePersonalChange}
                      readOnly={!isEditingPersonal}
                      className={!isEditingPersonal ? "bg-gray-50" : ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number (WhatsApp)</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={isEditingPersonal ? personalInfo.phone : userData.phone}
                      onChange={handlePersonalChange}
                      readOnly={!isEditingPersonal}
                      className={!isEditingPersonal ? "bg-gray-50" : ""}
                    />
                  </div>
                </CardContent>
                {isEditingPersonal && (
                  <CardFooter>
                    <div className="flex gap-2 ml-auto">
                      <Button variant="outline" onClick={() => setIsEditingPersonal(false)}>
                        Cancel
                      </Button>
                      <Button onClick={savePersonalInfo} className="bg-blue-600 hover:bg-blue-700">
                        Save Changes
                      </Button>
                    </div>
                  </CardFooter>
                )}
              </Card>
            </TabsContent>

            {/* Bank Details Tab */}
            <TabsContent value="bank" className="space-y-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0">
                  <div>
                    <CardTitle>Bank Details</CardTitle>
                    <CardDescription>Manage your bank account information</CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      if (isEditingBank) {
                        saveBankInfo()
                      } else {
                        setIsEditingBank(true)
                      }
                    }}
                  >
                    {isEditingBank ? <Save className="h-4 w-4" /> : <Edit className="h-4 w-4" />}
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name</Label>
                    {isEditingBank ? (
                      <Select value={bankInfo.bankName} onValueChange={handleBankNameChange}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your bank" />
                        </SelectTrigger>
                        <SelectContent>
                          {nigerianBanks.map((bank) => (
                            <SelectItem key={bank} value={bank}>
                              {bank}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input id="bankName" value={userData.bankName} readOnly className="bg-gray-50" />
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number</Label>
                    <Input
                      id="accountNumber"
                      name="accountNumber"
                      value={isEditingBank ? bankInfo.accountNumber : userData.accountNumber}
                      onChange={handleBankChange}
                      readOnly={!isEditingBank}
                      className={!isEditingBank ? "bg-gray-50" : ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountName">Account Name</Label>
                    <Input
                      id="accountName"
                      name="accountName"
                      value={isEditingBank ? bankInfo.accountName : userData.accountName}
                      onChange={handleBankChange}
                      readOnly={!isEditingBank}
                      className={!isEditingBank ? "bg-gray-50" : ""}
                    />
                  </div>
                </CardContent>
                {isEditingBank && (
                  <CardFooter>
                    <div className="flex gap-2 ml-auto">
                      <Button variant="outline" onClick={() => setIsEditingBank(false)}>
                        Cancel
                      </Button>
                      <Button onClick={saveBankInfo} className="bg-blue-600 hover:bg-blue-700">
                        Save Changes
                      </Button>
                    </div>
                  </CardFooter>
                )}
              </Card>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Change Password</CardTitle>
                  <CardDescription>Update your password to keep your account secure</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={changePassword} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword">Current Password</Label>
                      <Input
                        id="currentPassword"
                        name="currentPassword"
                        type="password"
                        value={passwordData.currentPassword}
                        onChange={handlePasswordChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input
                        id="newPassword"
                        name="newPassword"
                        type="password"
                        value={passwordData.newPassword}
                        onChange={handlePasswordChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={handlePasswordChange}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      <Lock className="mr-2 h-4 w-4" />
                      Change Password
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Account Security</CardTitle>
                  <CardDescription>Additional security settings for your account</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <h4 className="text-sm font-medium">Two-Factor Authentication</h4>
                      <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                    </div>
                    <Button variant="outline">Enable</Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <h4 className="text-sm font-medium">Login Notifications</h4>
                      <p className="text-sm text-muted-foreground">Get notified when someone logs into your account</p>
                    </div>
                    <Button variant="outline">Enable</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
