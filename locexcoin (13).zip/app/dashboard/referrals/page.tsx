"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { Copy, Share2, Users, AlertTriangle, Download } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ReferralsPage() {
  const { toast } = useToast()
  const [referralCode] = useState("REF123456")
  const [referralLink, setReferralLink] = useState(() => {
    // Generate referral link based on current domain
    const baseUrl = typeof window !== "undefined" ? window.location.origin : ""
    return `${baseUrl}/register?ref=${referralCode}`
  })
  const [isWithdrawalDialogOpen, setIsWithdrawalDialogOpen] = useState(false)
  const [withdrawalAmount, setWithdrawalAmount] = useState("0")
  const [withdrawalMethod, setWithdrawalMethod] = useState("")

  // Sample earnings data
  const earningsData = [
    { id: 1, type: "Sign-up Bonus", user: "John Doe", amount: "₦1,000", date: "2023-04-15", status: "Paid" },
    { id: 2, type: "Commission", user: "Sarah Smith", amount: "₦2,500", date: "2023-04-18", status: "Paid" },
    { id: 3, type: "Weekly Bonus", user: "System", amount: "₦5,000", date: "2023-04-20", status: "Paid" },
    { id: 4, type: "Sign-up Bonus", user: "Michael Johnson", amount: "₦1,000", date: "2023-04-22", status: "Pending" },
    { id: 5, type: "Commission", user: "Emily Brown", amount: "₦3,200", date: "2023-04-25", status: "Pending" },
  ]

  // Summary data
  const summaryData = {
    signupBonuses: "₦2,000",
    commissions: "₦5,700",
    weeklyBonuses: "₦5,000",
    totalEarned: "₦12,700",
    available: "₦9,200",
    pending: "₦4,200",
    withdrawn: "₦3,500",
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(
      () => {
        toast({
          title: "Copied!",
          description: "Referral link copied to clipboard",
        })
      },
      (err) => {
        console.error("Could not copy text: ", err)
        toast({
          title: "Error",
          description: "Failed to copy. Please try again.",
          variant: "destructive",
        })
      },
    )
  }

  const shareReferralLink = async () => {
    try {
      // Check if Web Share API is supported and we're in a secure context
      if (navigator.share && window.isSecureContext) {
        try {
          await navigator.share({
            title: "Join LOCEXCOIN",
            text: "Join LOCEXCOIN and earn profits on your investments. Use my referral link:",
            url: referralLink,
          })
          toast({
            title: "Shared!",
            description: "Your referral link has been shared",
          })
        } catch (shareError: any) {
          console.error("Share error:", shareError)

          // If permission denied or other share error, fall back to clipboard
          if (
            shareError.name === "NotAllowedError" ||
            shareError.message.includes("permission") ||
            shareError.message.includes("denied")
          ) {
            fallbackToCopy()
          } else {
            // For other errors, also fall back to clipboard
            fallbackToCopy()
          }
        }
      } else {
        // Web Share API not supported, use clipboard fallback
        fallbackToCopy()
      }
    } catch (error) {
      console.error("Error in share function:", error)
      fallbackToCopy()
    }
  }

  // Add this new fallback function
  const fallbackToCopy = () => {
    copyToClipboard(referralLink)
    toast({
      title: "Copied to clipboard",
      description: "Your referral link has been copied. You can now share it manually.",
    })
  }

  const handleWithdrawalSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate withdrawal amount
    const amount = Number.parseFloat(withdrawalAmount.replace(/[^0-9.]/g, ""))
    if (isNaN(amount) || amount < 10000) {
      toast({
        title: "Invalid amount",
        description: "Minimum withdrawal amount is ₦10,000",
        variant: "destructive",
      })
      return
    }

    // Validate withdrawal method
    if (!withdrawalMethod) {
      toast({
        title: "Missing information",
        description: "Please select a withdrawal method",
        variant: "destructive",
      })
      return
    }

    // Process withdrawal
    toast({
      title: "Withdrawal requested",
      description: `Your withdrawal request for ${withdrawalAmount} has been submitted and is being processed.`,
    })

    setIsWithdrawalDialogOpen(false)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Referrals</h1>
        <p className="text-muted-foreground">Invite friends and earn commissions</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Referral Link</CardTitle>
          <CardDescription>Share this link with friends to earn referral bonuses</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <Input value={referralLink} readOnly className="flex-1" />
            <Button variant="outline" size="icon" onClick={() => copyToClipboard(referralLink)}>
              <Copy className="h-4 w-4" />
            </Button>
            <Button variant="default" onClick={shareReferralLink}>
              <Share2 className="h-4 w-4 mr-2" /> Share
            </Button>
          </div>
          <div className="bg-blue-50 p-4 rounded-md">
            <h3 className="font-medium text-blue-700 mb-2">Referral Rewards</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                  1
                </span>
                <span>₦1,000 for each referral that signs up</span>
              </li>
              <li className="flex items-start">
                <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                  2
                </span>
                <span>10% commission on their first investment</span>
              </li>
              <li className="flex items-start">
                <span className="bg-blue-100 text-blue-600 rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">
                  3
                </span>
                <span>Weekly bonuses for top referrers</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="referrals" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="referrals">My Referrals</TabsTrigger>
          <TabsTrigger value="earnings">Earnings</TabsTrigger>
        </TabsList>
        <TabsContent value="referrals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Your Referrals</CardTitle>
              <CardDescription>People who have signed up using your referral link</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <Users className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium">No Referrals Yet</h3>
                <p className="text-sm text-muted-foreground max-w-md mt-2">
                  Share your referral link with friends and family to start earning referral bonuses.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="earnings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Referral Earnings</CardTitle>
              <CardDescription>Your earnings from referral commissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Earnings Summary Cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-sm font-medium text-muted-foreground">Total Earned</h3>
                        <p className="text-2xl font-bold mt-2">{summaryData.totalEarned}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-sm font-medium text-muted-foreground">Available</h3>
                        <p className="text-2xl font-bold mt-2">{summaryData.available}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-sm font-medium text-muted-foreground">Pending</h3>
                        <p className="text-2xl font-bold mt-2">{summaryData.pending}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <h3 className="text-sm font-medium text-muted-foreground">Withdrawn</h3>
                        <p className="text-2xl font-bold mt-2">{summaryData.withdrawn}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Earnings Breakdown */}
                <div>
                  <h3 className="text-lg font-medium mb-3">Earnings Breakdown</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <Card className="bg-green-50">
                      <CardContent className="pt-6">
                        <div className="text-center">
                          <h3 className="text-sm font-medium text-green-700">Sign-up Bonuses</h3>
                          <p className="text-xl font-bold mt-2 text-green-800">{summaryData.signupBonuses}</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="bg-blue-50">
                      <CardContent className="pt-6">
                        <div className="text-center">
                          <h3 className="text-sm font-medium text-blue-700">Commissions</h3>
                          <p className="text-xl font-bold mt-2 text-blue-800">{summaryData.commissions}</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="bg-purple-50">
                      <CardContent className="pt-6">
                        <div className="text-center">
                          <h3 className="text-sm font-medium text-purple-700">Weekly Bonuses</h3>
                          <p className="text-xl font-bold mt-2 text-purple-800">{summaryData.weeklyBonuses}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Earnings Table */}
                <div>
                  <h3 className="text-lg font-medium mb-3">Recent Earnings</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Type</TableHead>
                          <TableHead>From</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {earningsData.map((earning) => (
                          <TableRow key={earning.id}>
                            <TableCell>
                              <span
                                className={
                                  earning.type === "Sign-up Bonus"
                                    ? "text-green-600"
                                    : earning.type === "Commission"
                                      ? "text-blue-600"
                                      : "text-purple-600"
                                }
                              >
                                {earning.type}
                              </span>
                            </TableCell>
                            <TableCell>{earning.user}</TableCell>
                            <TableCell>{earning.amount}</TableCell>
                            <TableCell>{new Date(earning.date).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 rounded-full text-xs ${
                                  earning.status === "Paid"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-amber-100 text-amber-800"
                                }`}
                              >
                                {earning.status}
                              </span>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex justify-center mt-4">
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" /> Export Earnings
                    </Button>
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-amber-800">Withdrawal Information</h3>
                      <p className="text-sm text-amber-700 mt-1">
                        Minimum withdrawal amount is ₦10,000. Withdrawals are processed within 24 hours.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Dialog open={isWithdrawalDialogOpen} onOpenChange={setIsWithdrawalDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    className="w-full"
                    disabled={Number.parseFloat(summaryData.available.replace(/[^0-9.]/g, "")) < 10000}
                  >
                    Request Withdrawal (Minimum ₦10,000)
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Request Withdrawal</DialogTitle>
                    <DialogDescription>
                      Enter the amount you want to withdraw and select your preferred payment method.
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleWithdrawalSubmit}>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="amount" className="text-right">
                          Amount
                        </Label>
                        <Input
                          id="amount"
                          placeholder="₦10,000"
                          className="col-span-3"
                          value={withdrawalAmount}
                          onChange={(e) => setWithdrawalAmount(e.target.value)}
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="method" className="text-right">
                          Method
                        </Label>
                        <Select onValueChange={setWithdrawalMethod}>
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select payment method" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="bank">Bank Transfer</SelectItem>
                            <SelectItem value="mobile">Mobile Money</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="bg-blue-50 p-3 rounded-md text-sm text-blue-700 mt-2">
                        <p>Available balance: {summaryData.available}</p>
                        <p>Processing time: 24 hours</p>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit">Submit Withdrawal Request</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
