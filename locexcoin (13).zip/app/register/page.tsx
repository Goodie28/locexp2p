"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

// Updated Nigerian banks list including mobile money operators
const nigerianBanks = [
  // Commercial Banks
  "Access Bank",
  "Citibank",
  "Ecobank",
  "Fidelity Bank",
  "First Bank of Nigeria",
  "First City Monument Bank",
  "Guaranty Trust Bank",
  "Heritage Bank",
  "Keystone Bank",
  "Polaris Bank",
  "Stanbic IBTC Bank",
  "Standard Chartered Bank",
  "Sterling Bank",
  "Union Bank of Nigeria",
  "United Bank for Africa",
  "Unity Bank",
  "Wema Bank",
  "Zenith Bank",

  // Microfinance Banks
  "AB Microfinance Bank",
  "Accion Microfinance Bank",
  "Addosser Microfinance Bank",
  "Advans La Fayette Microfinance Bank",
  "Baobab Microfinance Bank",
  "Boctrust Microfinance Bank",
  "Busack Microfinance Bank",
  "CEMCS Microfinance Bank",
  "Credit Afrique Microfinance Bank",
  "Daylight Microfinance Bank",
  "Empire Trust Microfinance Bank",
  "FAST Microfinance Bank",
  "Fina Trust Microfinance Bank",
  "Finca Microfinance Bank",
  "FIMS Microfinance Bank",
  "Fortis Microfinance Bank",
  "Fullrange Microfinance Bank",
  "Gashua Microfinance Bank",
  "Hasal Microfinance Bank",
  "Infinity Microfinance Bank",
  "Lapo Microfinance Bank",
  "Lovonus Microfinance Bank",
  "Mainstreet Microfinance Bank",
  "Mutual Trust Microfinance Bank",
  "NPF Microfinance Bank",
  "Page Microfinance Bank",
  "Parallex Microfinance Bank",
  "Petra Microfinance Bank",
  "Seed Capital Microfinance Bank",
  "Sparkle Microfinance Bank",
  "Trustfund Microfinance Bank",
  "VFD Microfinance Bank",

  // Mobile Money Operators
  "9Mobile 9Pay",
  "Airtel Money",
  "Carbon",
  "Chipper Cash",
  "Flutterwave",
  "Globus Bank Mobile Money",
  "Glo Mobile Money",
  "Kuda Bank",
  "Moniepoint",
  "MTN MoMo PSB",
  "OPay",
  "PalmPay",
  "Paga",
  "Paycom (OPay)",
  "Pocket Moni",
  "Sparkle",
  "TeasyMobile",
  "VFD Microfinance Bank",
  "Wallet Africa",
]

export default function RegisterPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    bankName: "",
    accountNumber: "",
    accountName: "",
    referralCode: "",
  })
  const [step, setStep] = useState(1)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleBankChange = (value: string) => {
    setFormData((prev) => ({ ...prev, bankName: value }))
  }

  const handleSubmitStep1 = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.fullName || !formData.email || !formData.phone || !formData.password || !formData.confirmPassword) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Error",
        description: "Passwords do not match",
        variant: "destructive",
      })
      return
    }

    // Move to step 2
    setStep(2)
  }

  const handleSubmitStep2 = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.bankName || !formData.accountNumber || !formData.accountName) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    // Submit registration
    toast({
      title: "Success",
      description: "Your account has been created successfully!",
    })

    // Redirect to dashboard
    setTimeout(() => {
      router.push("/dashboard")
    }, 2000)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow py-12 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle>Create an Account</CardTitle>
              <CardDescription>Join LOCEXCOIN and start earning profits today</CardDescription>
            </CardHeader>
            <CardContent>
              {step === 1 ? (
                <form onSubmit={handleSubmitStep1} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      placeholder="John Doe"
                      value={formData.fullName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="john@example.com"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number (WhatsApp)</Label>
                    <Input
                      id="phone"
                      name="phone"
                      placeholder="+234..."
                      value={formData.phone}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      value={formData.password}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="referralCode">Referral Code (Optional)</Label>
                    <Input
                      id="referralCode"
                      name="referralCode"
                      placeholder="Enter referral code"
                      value={formData.referralCode}
                      onChange={handleChange}
                    />
                  </div>
                  <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                    Continue
                  </Button>
                </form>
              ) : (
                <form onSubmit={handleSubmitStep2} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name or Mobile Money Operator</Label>
                    <Select onValueChange={handleBankChange} value={formData.bankName}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your bank or mobile money operator" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="category-header-commercial" disabled>
                          --- Commercial Banks ---
                        </SelectItem>
                        {nigerianBanks.slice(0, 18).map((bank) => (
                          <SelectItem key={bank} value={bank}>
                            {bank}
                          </SelectItem>
                        ))}

                        <SelectItem value="category-header-microfinance" disabled>
                          --- Microfinance Banks ---
                        </SelectItem>
                        {nigerianBanks.slice(18, 50).map((bank) => (
                          <SelectItem key={bank} value={bank}>
                            {bank}
                          </SelectItem>
                        ))}

                        <SelectItem value="category-header-mobile" disabled>
                          --- Mobile Money Operators ---
                        </SelectItem>
                        {nigerianBanks.slice(50).map((bank) => (
                          <SelectItem key={bank} value={bank}>
                            {bank}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number</Label>
                    <Input
                      id="accountNumber"
                      name="accountNumber"
                      placeholder="0123456789"
                      value={formData.accountNumber}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountName">Account Name</Label>
                    <Input
                      id="accountName"
                      name="accountName"
                      placeholder="John Doe"
                      value={formData.accountName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                      Back
                    </Button>
                    <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700">
                      Complete Registration
                    </Button>
                  </div>
                </form>
              )}
            </CardContent>
            <CardFooter className="flex justify-center">
              <p className="text-sm text-gray-500">
                Already have an account?{" "}
                <Link href="/login" className="text-blue-600 hover:underline">
                  Login
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}
