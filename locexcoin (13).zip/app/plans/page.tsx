import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, ArrowRight, Clock, Percent, Shield, Coins } from "lucide-react"

export default function PlansPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Investment Plans</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Choose from our range of investment plans with guaranteed returns
        </p>
      </div>

      {/* Featured Plans Section */}
      <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
        {/* 7-Day Plan */}
        <Card className="border-2 relative overflow-hidden transition-all duration-300 hover:shadow-lg">
          <div className="absolute top-0 right-0 bg-blue-100 text-blue-800 px-3 py-1 text-xs font-medium">
            QUICK RETURNS
          </div>
          <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100">
            <div className="flex items-center justify-center mb-2">
              <Clock className="h-8 w-8 text-blue-600" />
            </div>
            <CardTitle className="text-center text-xl">7-Day Plan</CardTitle>
            <CardDescription className="text-center">
              <span className="text-3xl font-bold text-blue-600">35%</span>
              <span className="text-sm text-muted-foreground"> profit</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <p className="text-center text-sm text-muted-foreground mb-6">
              Perfect for beginners and those who prefer quick returns
            </p>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Shortest duration (7 days)</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">35% guaranteed profit</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Minimum investment: ₦10,000</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Ideal for testing the platform</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Quick capital turnover</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <Link href="/register">Get Started</Link>
            </Button>
          </CardFooter>
        </Card>

        {/* 14-Day Plan */}
        <Card className="border-2 border-orange relative overflow-hidden transition-all duration-300 hover:shadow-lg scale-105 z-10">
          <div className="absolute top-0 right-0 bg-orange text-white px-3 py-1 text-xs font-medium">MOST POPULAR</div>
          <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
            <div className="flex items-center justify-center mb-2">
              <Percent className="h-8 w-8 text-orange" />
            </div>
            <CardTitle className="text-center text-xl">14-Day Plan</CardTitle>
            <CardDescription className="text-center">
              <span className="text-3xl font-bold text-orange">107%</span>
              <span className="text-sm text-muted-foreground"> profit</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <p className="text-center text-sm text-muted-foreground mb-6">
              Our most popular plan with balanced duration and returns
            </p>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Medium duration (14 days)</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">107% guaranteed profit</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Minimum investment: ₦10,000</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Balanced risk/reward ratio</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Most chosen by investors</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-orange hover:bg-orange-600">
              <Link href="/register">Get Started</Link>
            </Button>
          </CardFooter>
        </Card>

        {/* 21-Day Plan */}
        <Card className="border-2 relative overflow-hidden transition-all duration-300 hover:shadow-lg">
          <div className="absolute top-0 right-0 bg-green-100 text-green-800 px-3 py-1 text-xs font-medium">
            HIGHEST RETURNS
          </div>
          <CardHeader className="bg-gradient-to-r from-green-50 to-green-100">
            <div className="flex items-center justify-center mb-2">
              <Shield className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-center text-xl">21-Day Plan</CardTitle>
            <CardDescription className="text-center">
              <span className="text-3xl font-bold text-green-600">215%</span>
              <span className="text-sm text-muted-foreground"> profit</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <p className="text-center text-sm text-muted-foreground mb-6">
              Maximum returns for investors who prefer long-term growth
            </p>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Longest duration (21 days)</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">215% guaranteed profit</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Minimum investment: ₦10,000</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Highest return on investment</span>
              </li>
              <li className="flex items-start">
                <Check className="mr-2 h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm">Best for experienced investors</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-green-600 hover:bg-green-700">
              <Link href="/register">Get Started</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* How It Works Section */}
      <div className="mt-16 max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-center mb-8">How Our Investment Plans Work</h2>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <Coins className="mr-2 h-5 w-5 text-blue-600" />
                Auction System
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    1
                  </div>
                  <span>Auctions are held twice daily at 9:00 AM and 6:30 PM on weekdays</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    2
                  </div>
                  <span>Limited coins are available on a first-come, first-served basis</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    3
                  </div>
                  <span>Select your preferred plan during the auction</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    4
                  </div>
                  <span>Complete payment within 7 hours to secure your investment</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <Percent className="mr-2 h-5 w-5 text-blue-600" />
                Returns & Maturity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    1
                  </div>
                  <span>Your investment is activated once payment is verified</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    2
                  </div>
                  <span>Track your investment progress in your dashboard</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    3
                  </div>
                  <span>Receive your principal plus profit at maturity</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-200 text-blue-800 rounded-full h-5 w-5 flex items-center justify-center mr-2 flex-shrink-0">
                    4
                  </div>
                  <span>Reinvest or withdraw your funds as desired</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Call to Action */}
      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Start Investing?</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Join thousands of investors who are already growing their wealth with LOCEXCOIN's guaranteed profit system.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/register">
              Create Account
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/login">Login to Your Account</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
