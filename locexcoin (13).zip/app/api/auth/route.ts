import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"

// Mock admin credentials - in a real app, these would be in a database
const ADMIN_EMAIL = "admin@locexcoin.com"
const ADMIN_PASSWORD = "admin123"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, isAdmin } = body

    // This is a simplified mock authentication
    // In a real app, you would verify credentials against a database

    if (isAdmin) {
      // Admin login attempt
      if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
        // Set admin cookies
        cookies().set({
          name: "auth_token",
          value: "admin_token_" + Date.now(),
          httpOnly: true,
          path: "/",
          secure: process.env.NODE_ENV === "production",
          maxAge: 60 * 60 * 24 * 7, // 1 week
        })

        cookies().set({
          name: "user_role",
          value: "admin",
          httpOnly: true,
          path: "/",
          secure: process.env.NODE_ENV === "production",
          maxAge: 60 * 60 * 24 * 7, // 1 week
        })

        return NextResponse.json({
          success: true,
          message: "Admin login successful",
          redirect: "/admin",
        })
      } else {
        return NextResponse.json({ success: false, message: "Invalid admin credentials" }, { status: 401 })
      }
    } else {
      // Regular user login
      // In a real app, you would verify against user records in a database

      // For demo purposes, we'll accept any non-empty email/password
      if (email && password) {
        // Set user cookies
        cookies().set({
          name: "auth_token",
          value: "user_token_" + Date.now(),
          httpOnly: true,
          path: "/",
          secure: process.env.NODE_ENV === "production",
          maxAge: 60 * 60 * 24 * 7, // 1 week
        })

        cookies().set({
          name: "user_role",
          value: "user",
          httpOnly: true,
          path: "/",
          secure: process.env.NODE_ENV === "production",
          maxAge: 60 * 60 * 24 * 7, // 1 week
        })

        return NextResponse.json({
          success: true,
          message: "Login successful",
          redirect: "/dashboard",
        })
      } else {
        return NextResponse.json({ success: false, message: "Invalid credentials" }, { status: 401 })
      }
    }
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ success: false, message: "An error occurred during login" }, { status: 500 })
  }
}

export async function DELETE() {
  // Logout - clear cookies
  cookies().delete("auth_token")
  cookies().delete("user_role")

  return NextResponse.json({ success: true, message: "Logged out successfully" })
}
