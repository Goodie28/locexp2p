import { Pool } from "pg"
import { drizzle } from "drizzle-orm/node-postgres"
import { sql } from "@vercel/postgres"

// For local development
let pool: Pool | null = null

// Initialize database connection
export function getDb() {
  // If we're on Vercel, use the Vercel Postgres SDK
  if (process.env.VERCEL) {
    return drizzle(sql)
  }

  // For local development, use a connection pool
  if (!pool) {
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    })
  }

  return drizzle(pool)
}

// Export the database instance
export const db = getDb()
